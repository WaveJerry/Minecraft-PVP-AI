package local.pvpbot.appearance;

import com.destroystokyo.paper.profile.PlayerProfile;
import com.destroystokyo.paper.profile.ProfileProperty;
import io.github.hello09x.fakeplayer.core.Main;
import io.github.hello09x.fakeplayer.core.manager.FakeplayerManager;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.UUID;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.plugin.java.JavaPlugin;

/** Applies the signed skin made from 白雪公主.png to the real fake-player profile. */
public final class PvPBotAppearance extends JavaPlugin implements Listener {
    private FakeplayerManager fakeplayers;
    private String skinValue;
    private String skinSignature;

    @Override
    public void onEnable() {
        Properties properties = new Properties();
        try (InputStream stream = getResource("bot-skin.properties")) {
            if (stream == null) {
                throw new IOException("bot-skin.properties is missing");
            }
            properties.load(stream);
        } catch (IOException error) {
            getLogger().log(Level.SEVERE, "Could not load signed bot skin", error);
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }
        skinValue = properties.getProperty("value");
        skinSignature = properties.getProperty("signature");
        if (skinValue == null || skinSignature == null) {
            getLogger().severe("Signed bot skin is incomplete");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }
        fakeplayers = Main.getInjector().getInstance(FakeplayerManager.class);
        Bukkit.getPluginManager().registerEvents(this, this);
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (namedBot(player)) {
                applyLater(player.getUniqueId(), 20L);
            }
        }
        getLogger().info("Signed PNG skin handler ready");
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        if (namedBot(event.getPlayer())) {
            applyLater(event.getPlayer().getUniqueId(), 20L);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onRespawn(PlayerRespawnEvent event) {
        if (namedBot(event.getPlayer())) {
            applyLater(event.getPlayer().getUniqueId(), 10L);
        }
    }

    private boolean namedBot(Player player){
        return player.getName().equalsIgnoreCase("WaveDog")||player.getName().equalsIgnoreCase("WaveDog2");
    }

    private void applyLater(UUID uuid, long delayTicks) {
        Bukkit.getScheduler().runTaskLater(this, () -> {
            Player bot = Bukkit.getPlayer(uuid);
            if (bot == null || bot.isDead() || !namedBot(bot) || !fakeplayers.isFake(bot)) {
                return;
            }
            try {
                PlayerProfile profile = bot.getPlayerProfile();
                profile.setProperty(new ProfileProperty("textures", skinValue, skinSignature));
                bot.setPlayerProfile(profile);
                boolean applied = bot.getPlayerProfile().getProperties().stream()
                        .anyMatch(property -> property.getName().equals("textures")
                                && property.getValue().equals(skinValue));
                if (applied) {
                    getLogger().info("Signed PNG skin applied and broadcast to "+bot.getName());
                } else {
                    getLogger().warning(bot.getName()+" profile did not retain the signed PNG skin");
                }
            } catch (RuntimeException error) {
                getLogger().log(Level.SEVERE, "Could not apply PNG skin to "+bot.getName(), error);
            }
        }, delayTicks);
    }
}

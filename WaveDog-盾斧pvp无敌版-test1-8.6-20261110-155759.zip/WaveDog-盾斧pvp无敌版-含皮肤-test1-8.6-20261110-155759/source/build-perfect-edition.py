"""Build only the distribution facade over an already validated core JAR."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,zipfile

b=Path(__file__).resolve().parent
server=Path(os.environ.get('WAVEDOG_BUILD_SERVER',r'D:\Walt Disney\Minecraft-1.21.1-Server'))
core=Path(sys.argv[1]);out=Path(sys.argv[2]);classes=b/'edition-classes';classes.mkdir(exist_ok=True)
java=server/'runtime/java21/bin'
asm=next((server/'libraries/org/ow2/asm/asm').rglob('*.jar'))
tree=next((server/'libraries/org/ow2/asm/asm-tree').rglob('*.jar'))
cp=os.pathsep.join(map(str,[classes,asm,tree]))
compiler=b/'InMemoryCompile.java'
subprocess.run([java/'javac.exe','-encoding','UTF-8','--release','21','-cp',os.pathsep.join(map(str,[asm,tree])),'-d',classes,compiler,b/'PerfectEditionPatch.java'],check=True)
deps=[p for p in (server/'libraries').rglob('*.jar') if any(k in p.name for k in ('paper-mojangapi','adventure-api','adventure-key','examination-api','examination-string','annotations','bungeecord-chat'))]
dependency_list=b/'edition-dependencies.txt';dependency_list.write_text('\n'.join(map(str,deps)),encoding='utf-8')
subprocess.run([java/'java.exe','-Xmx192m','-cp',cp,'InMemoryCompile',core,classes,'--dependencies',dependency_list,b/'PerfectEditionSupport.java',b/'DuelPlayerCommands.java'],check=True)
with zipfile.ZipFile(core) as jar:payload={n:jar.read(n) for n in jar.namelist() if not n.endswith('/')}
main='local/pvpbot/ai/PvPArenaAI.class';before=b/'entry-before.class';after=b/'entry-edition.class';before.write_bytes(payload[main])
subprocess.run([java/'java.exe','-Xmx96m','-cp',cp,'PerfectEditionPatch',before,after],check=True)
payload[main]=after.read_bytes();support='local/pvpbot/ai/PerfectEditionSupport.class';payload[support]=(classes/support).read_bytes()
for p in (classes/'local/pvpbot/ai').glob('DuelPlayerCommands*.class'):payload[p.relative_to(classes).as_posix()]=p.read_bytes()
metadata=payload['plugin.yml'].decode('utf-8').replace('version: 0.10.11-ground.8.6-duel.1','version: 0.10.11-ground.8.6-duel.1-axe-test1-skin')
metadata=metadata.replace('    usage: /pvpai help','    usage: /wavedog help\n    aliases: [wavedog]')
metadata=metadata.replace('Controls the two fair-play axe-kit PvP bots.','WaveDog 盾斧pvp无敌版 / test1')
payload['plugin.yml']=metadata.encode('utf-8')
payload['config.yml']=b'owner-name: WaveJerry\ncontroller-profile: initial-0.10.0\nlearning-enabled: false\ntactical-policy-mode: frozen\ntactical-learning-enabled: false\nambient-enabled: false\n'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as jar:
    for name,data in payload.items():jar.writestr(name,data)
with zipfile.ZipFile(core) as original:
    unchanged=[n for n in original.namelist() if n.endswith('.class') and n!=main and not n.startswith('local/pvpbot/ai/DuelPlayerCommands')]
    assert all(payload[n]==original.read(n) for n in unchanged)
record={'core_sha256':hashlib.sha256(core.read_bytes()).hexdigest(),'edition_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
        'unchanged_core_classes':unchanged,'unchanged_core_class_count':len(unchanged),
        'modified_classes':[main,'local/pvpbot/ai/DuelPlayerCommands.class'],'added_classes':[support],'scope':'command facade and configurable player identity only'}
(out.parent/'edition-preservation.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
print('PASS:',len(unchanged),'core class entries unchanged; edition compiled:',out)

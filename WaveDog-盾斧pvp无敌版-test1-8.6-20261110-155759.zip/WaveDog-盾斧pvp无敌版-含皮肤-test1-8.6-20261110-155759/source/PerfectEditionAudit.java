import java.nio.file.*;import java.util.*;import java.util.zip.*;
import org.objectweb.asm.*;import org.objectweb.asm.tree.*;

/** Verify the facade changes ONLY owner lookup, metadata and command routing. */
public final class PerfectEditionAudit {
    static final String MAIN="local/pvpbot/ai/PvPArenaAI",SUPPORT="local/pvpbot/ai/PerfectEditionSupport";
    static ClassNode type(ZipFile zip,String path)throws Exception {
        var n=new ClassNode();new ClassReader(zip.getInputStream(zip.getEntry(path)).readAllBytes()).accept(n,0);return n;
    }
    static byte[] method(ClassNode n,MethodNode m) {
        var w=new ClassWriter(0);w.visit(n.version,n.access,n.name,n.signature,n.superName,null);m.accept(w);w.visitEnd();return w.toByteArray();
    }
    public static void main(String[] args)throws Exception {
        try(var old=new ZipFile(args[0]);var edition=new ZipFile(args[1])) {
            int unchanged=0;
            for(var entries=old.entries();entries.hasMoreElements();) {
                var e=entries.nextElement();if(!e.getName().endsWith(".class")||e.getName().equals(MAIN+".class")||e.getName().startsWith("local/pvpbot/ai/DuelPlayerCommands"))continue;
                if(!Arrays.equals(old.getInputStream(e).readAllBytes(),edition.getInputStream(edition.getEntry(e.getName())).readAllBytes()))throw new AssertionError(e.getName());unchanged++;
            }
            var a=type(old,MAIN+".class");var b=type(edition,MAIN+".class");int methods=0,owners=0;
            for(var m:a.methods) {
                String lookup=m.name.equals("onCommand")?"editionBaseCommand":m.name;
                var target=b.methods.stream().filter(n->n.name.equals(lookup)&&n.desc.equals(m.desc)).findFirst().orElseThrow();
                target.name=m.name;
                for(var insn:target.instructions.toArray())if(insn instanceof MethodInsnNode call&&call.owner.equals(SPORT())&&call.name.equals("owner")) {
                    var previous=call.getPrevious();
                    if(!(previous instanceof VarInsnNode v)||v.getOpcode()!=Opcodes.ALOAD||v.var!=0)throw new AssertionError("Unexpected owner adapter");
                    target.instructions.remove(previous);target.instructions.set(call,new LdcInsnNode("WaveJerry"));owners++;
                }
                // New instructions change maxStack only; normalize that metadata.
                target.maxStack=m.maxStack;
                if(!Arrays.equals(method(a,m),method(b,target)))throw new AssertionError("Unrelated original method changed: "+m.name);methods++;
            }
            System.out.println("PASS: "+unchanged+" core classes byte-identical; "+methods+" original entry methods unchanged after normalizing "+owners+" configurable-owner reads and onCommand facade rename");
        }
    }
    static String SPORT(){return SUPPORT;}
}

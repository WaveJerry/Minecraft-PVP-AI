/** Verify the actual exported entry and added command class against the actual APIs. */
public final class PerfectEditionLoadCheck {
    public static void main(String[] args)throws Exception {
        var a=new RestartCheck.Archive(java.nio.file.Path.of(args[0]),null);
        for(String name:java.util.List.of("PvPArenaAI","PerfectEditionSupport","AirborneObservation")) {
            var c=a.type(name);if(c.getDeclaredMethods().length==0)throw new AssertionError(name);
        }
        System.out.println("PASS: exported entry/facade/airborne adapter JVM-verified under Paper 1.21.1 dependencies");
    }
}

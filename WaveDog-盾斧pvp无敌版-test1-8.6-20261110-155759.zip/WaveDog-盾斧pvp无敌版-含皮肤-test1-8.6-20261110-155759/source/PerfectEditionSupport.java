package local.pvpbot.ai;

import java.util.Locale;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

/** Distribution commands only; no combat, physics, observation or learning changes. */
final class PerfectEditionSupport {
    static String owner(JavaPlugin plugin) {
        String name=plugin.getConfig().getString("owner-name","WaveJerry");
        if(!name.matches("[A-Za-z0-9_]{3,16}"))throw new IllegalArgumentException("Invalid owner-name");
        return name;
    }

    static String[] route(JavaPlugin plugin,CommandSender sender,String[] args) {
        if(sender instanceof Player p && !p.getName().equalsIgnoreCase(owner(plugin))) {
            sender.sendMessage("只有 "+owner(plugin)+" 可以控制 WaveDog 盾斧pvp无敌版。");return null;
        }
        String sub=args.length==0?"help":args[0].toLowerCase(Locale.ROOT);
        if(sub.equals("help")) {
            sender.sendMessage("WaveDog 盾斧pvp无敌版 / test1：/wavedog setup create | kit | duel | stop | idle | roam | status | learn on/off/initial | review");return null;
        }
        if(sub.equals("setup")) {
            if(args.length!=2 || !args[1].equalsIgnoreCase("create")) {
                sender.sendMessage("首次创建场地：/wavedog setup create（覆盖 world 固定竞技场区域）");return null;
            }
            var world=Bukkit.getWorld("world");
            if(world==null){sender.sendMessage("需要名称为 world 的世界。");return null;}
            Bukkit.dispatchCommand(sender,"pvpai idle");
            for(int x=991;x<=1038;x++)for(int z=991;z<=1038;z++) {
                world.getBlockAt(x,220,z).setType(Material.SMOOTH_STONE,false);
                for(int y=221;y<=230;y++)world.getBlockAt(x,y,z).setType(
                    (x==991||x==1038||z==991||z==1038)&&y<=226?Material.BEDROCK:Material.AIR,false);
            }
            world.setSpawnLocation(1005,221,1014);
            var player=Bukkit.getPlayerExact(owner(plugin));
            if(player!=null) {
                player.teleport(new Location(world,1005.5,221,1014.5,-90,0));
                player.setGameMode(GameMode.SURVIVAL);
                Bukkit.dispatchCommand(player,"pvpai kit");
            }
            sender.sendMessage("竞技场已创建；玩家在线时已入场并装备。/wavedog duel 开始与 test1 循环决斗。");return null;
        }
        if(!Set.of("kit","duel","stop","idle","roam","status","learn","review","collisioncheck").contains(sub)) {
            sender.sendMessage("本作品使用 WaveDog / test1。/wavedog help 查看指令；双 AI 对练使用研究版。");return null;
        }
        if(sub.equals("duel")) {
            if(args.length>2 || args.length==2&&!args[1].equalsIgnoreCase("test1")) {
                sender.sendMessage("本作品固定 test1：/wavedog duel");return null;
            }
            return new String[]{"duel","test1",owner(plugin)};
        }
        return args;
    }
}

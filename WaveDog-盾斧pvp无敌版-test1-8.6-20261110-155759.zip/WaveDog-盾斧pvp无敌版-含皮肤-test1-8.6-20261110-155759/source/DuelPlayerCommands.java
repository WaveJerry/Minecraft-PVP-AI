package local.pvpbot.ai;

import java.lang.reflect.*;
import java.util.*;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

/** Participant selection only. Combat policies, physical inputs and learners are untouched. */
final class DuelPlayerCommands {
    private static String owner(JavaPlugin plugin) { return PerfectEditionSupport.owner(plugin); }
    private static final Map<JavaPlugin, Selection> selected = new WeakHashMap<>();
    private record Selection(String name, UUID uuid) {}

    static String participant(JavaPlugin plugin) {
        Selection s = selected.get(plugin);
        return s == null ? owner(plugin) : s.name();
    }

    static String layoutPath(JavaPlugin plugin, String suffix) {
        Selection s = selected.get(plugin);
        return (s == null || s.name().equalsIgnoreCase(owner(plugin))
            ? "human-layout" : "duel-layouts." + s.uuid()) + "." + suffix;
    }

    static boolean authenticated(Player player) {
        Plugin auth = Bukkit.getPluginManager().getPlugin("AuthMe");
        if (auth == null || !auth.isEnabled()) {
            // Standalone online-mode servers already authenticate players. A local offline
            // server may explicitly allow loopback players; no private AuthMe data is shipped.
            JavaPlugin plugin=JavaPlugin.getProvidingPlugin(DuelPlayerCommands.class);
            return Bukkit.getOnlineMode() || plugin.getConfig().getBoolean("allow-offline-local",true)
                && player.getAddress()!=null && player.getAddress().getAddress().isLoopbackAddress();
        }
        try {
            Class<?> api = Class.forName("fr.xephi.authme.api.v3.AuthMeApi", true, auth.getClass().getClassLoader());
            Object instance = api.getMethod("getInstance").invoke(null);
            return Boolean.TRUE.equals(api.getMethod("isAuthenticated", Player.class).invoke(instance, player));
        } catch (ReflectiveOperationException | LinkageError failure) {
            return false;
        }
    }

    static boolean controller(CommandSender sender) {
        return sender instanceof ConsoleCommandSender || sender instanceof RemoteConsoleCommandSender
            || sender instanceof Player p && p.getName().equalsIgnoreCase(owner(JavaPlugin.getProvidingPlugin(DuelPlayerCommands.class))) && authenticated(p);
    }

    static String[] route(JavaPlugin plugin, CommandSender sender, String[] args) {
        if (!controller(sender)) {
            sender.sendMessage("只有配置的对战玩家或服务器控制台可以安排对战。");
            return null;
        }
        String sub = args.length == 0 ? "help" : args[0].toLowerCase(Locale.ROOT);
        try {
            if (sub.equals("duel")) {
                if (args.length < 2 || args.length > 3 || DuelModels.profile(args[1]) == null) {
                    sender.sendMessage("用法：/pvpai duel <test1|test2|uhc1|uhc2> [在线玩家名]；模型必须填写。");
                    return null;
                }
                String name = args.length == 3 ? args[2] : owner(plugin);
                Player target = Bukkit.getPlayerExact(name);
                if (target == null || !target.isOnline()) {
                    sender.sendMessage("找不到在线玩家：" + name);
                    return null;
                }
                if (fake(plugin, target) || Set.of("wavedog", "wavedog2", "pvpbot", "pvpbot2")
                    .contains(target.getName().toLowerCase(Locale.ROOT))) {
                    sender.sendMessage("这里必须填写真实玩家的名字；机器人互打请用 /pvpai spar。");
                    return null;
                }
                if (!authenticated(target)) {
                    sender.sendMessage("该玩家尚未完成 /login，不能安排对战。");
                    return null;
                }
                if (target.getGameMode() != GameMode.SURVIVAL || target.isDead()) {
                    sender.sendMessage("目标玩家需要存活并处于生存模式。");
                    return null;
                }
                if (get(plugin, "speedTrial") != null || Boolean.TRUE.equals(get(plugin, "diagnosticActive"))) {
                    sender.sendMessage("请先等待当前机制测试结束。");
                    return null;
                }
                if (invoke(plugin, "arenaWorld", new Class<?>[0]) == null) {
                    sender.sendMessage("找不到竞技场世界，未更改当前对局。");
                    return null;
                }
                Player bot = Bukkit.getPlayerExact("WaveDog");
                if (bot != null && !fake(plugin, bot)) {
                    sender.sendMessage("WaveDog 名字被真实玩家占用，无法开始。");
                    return null;
                }
                invoke(plugin, "stopRound", new Class<?>[0]); // Cancels previous spawn/next-round callbacks.
                DuelModels.activate(plugin, args[1]);
                select(plugin, target);
                if (!Boolean.TRUE.equals(invoke(plugin, "hasRequiredKit", new Class<?>[]{Player.class}, target))) {
                    invoke(plugin, "giveKit", new Class<?>[]{Player.class}, target);
                    invoke(plugin, "saveHumanLayout", new Class<?>[0]);
                }
                sender.sendMessage("已安排 WaveDog（" + DuelModels.active(plugin) + "）对战 " + target.getName() + "；每局准备 5 秒，自动下一局，/pvpai stop 停止。");
                target.sendMessage("你将与 WaveDog（" + DuelModels.active(plugin) + "）循环对战；竞技套装会沿用你的背包布局，每局有 5 秒调整时间。");
                if (DuelModels.active(plugin).startsWith("uhc")) target.sendMessage("此包的 UHC1/UHC2 是独立训练数据的盾斧基础入口；水、岩浆等 UHC 扩展动作尚未启用，原 UHC 存档未改动。");
                return new String[]{"duel"};
            }
            if (sub.equals("spar")) { invoke(plugin, "stopRound", new Class<?>[0]); DuelModels.activate(plugin, "test1"); }
            // The original kit command equips its sender; never save that layout under a guest's UUID.
            if (sub.equals("kit") && sender instanceof Player p) {
                if (!String.valueOf(get(plugin, "mode")).equals("STOPPED")) {
                    sender.sendMessage("请先 /pvpai stop 停止对战，再领取装备。");
                    return null;
                }
                select(plugin, p);
            }
            if (sub.equals("help")) {
                sender.sendMessage("对战：/pvpai duel <test1|test2|uhc1|uhc2> [玩家名]；停止：/pvpai stop。目标需已登录且为生存模式；入场使用竞技套装。");
            }
            if (sub.equals("status")) sender.sendMessage("当前人机对战玩家：" + participant(plugin) + "；机器人：WaveDog / " + DuelModels.active(plugin) + "。");
            return args;
        } catch (RuntimeException failure) {
            plugin.getLogger().log(java.util.logging.Level.SEVERE, "Duel participant command failed", failure);
            try { invoke(plugin, "stopRound", new Class<?>[0]); } catch (RuntimeException ignored) {}
            sender.sendMessage("对战设置失败，已停止安排；请查看服务器控制台。");
            return null;
        }
    }

    private static void select(JavaPlugin plugin, Player target) {
        invoke(plugin, "saveHumanLayout", new Class<?>[0]);
        selected.put(plugin, new Selection(target.getName(), target.getUniqueId()));
        List<String> rows = plugin.getConfig().getStringList(layoutPath(plugin, "rows"));
        KitLayout layout = null;
        if (!rows.isEmpty()) try {
            layout = KitLayout.parse(rows, plugin.getConfig().getInt(layoutPath(plugin, "held-slot"), 0));
        } catch (IllegalArgumentException invalid) {
            plugin.getLogger().warning("Ignoring invalid duel layout for " + target.getName());
        }
        if (layout == null) try {
            layout = (KitLayout) invoke(plugin, "captureLayout", new Class<?>[]{Player.class}, target);
        } catch (RuntimeException missingKit) { /* Canonical kit is supplied below. */ }
        if (layout == null) layout = KitLayout.canonical();
        set(plugin, "humanLayout", layout);
    }

    /** Checked before round preparation, each active tick, and automatic next round. */
    static boolean ready(JavaPlugin plugin) {
        if (!String.valueOf(get(plugin, "mode")).equals("DUEL")) return true;
        Selection s = selected.get(plugin);
        Player player = Bukkit.getPlayerExact(participant(plugin));
        boolean valid = player != null && player.isOnline() && !fake(plugin, player)
            && (s == null || player.getUniqueId().equals(s.uuid()))
            && player.getGameMode() == GameMode.SURVIVAL && authenticated(player);
        if (valid) return true;
        invoke(plugin, "stopRound", new Class<?>[0]);
        plugin.getLogger().info("Duel stopped: selected player is offline, unauthenticated or no longer in survival mode.");
        return false;
    }

    static List<String> complete(JavaPlugin plugin, CommandSender sender, String[] args) {
        if (!controller(sender)) return List.of();
        if (args.length==0) return List.of("duel","help","stop","status");
        if (args.length == 1) return List.of("help", "duel", "kit", "stop", "status", "spar", "learn", "idle", "roam", "review")
            .stream().filter(s -> s.startsWith(args[0].toLowerCase(Locale.ROOT))).toList();
        if (!args[0].equalsIgnoreCase("duel")) return List.of();
        if (args.length == 2) return List.of("test1","test2","uhc1","uhc2").stream().filter(x -> x.startsWith(args[1].toLowerCase(Locale.ROOT))).toList();
        if (args.length != 3 || DuelModels.profile(args[1]) == null) return List.of();
        String prefix = args[2].toLowerCase(Locale.ROOT);
        return Bukkit.getOnlinePlayers().stream().filter(p -> p.getName().toLowerCase(Locale.ROOT).startsWith(prefix))
            .filter(p -> !fake(plugin, p) && authenticated(p) && p.getGameMode() == GameMode.SURVIVAL)
            .map(Player::getName).sorted(String.CASE_INSENSITIVE_ORDER).toList();
    }

    private static boolean fake(JavaPlugin plugin, Player p) {
        Object manager = get(plugin, "fakeplayers");
        if (manager == null) return true; // Fail closed before the fake-player manager is ready.
        try { return Boolean.TRUE.equals(manager.getClass().getMethod("isFake", Player.class).invoke(manager, p)); }
        catch (ReflectiveOperationException failure) { throw new IllegalStateException(failure); }
    }
    private static Field field(JavaPlugin plugin, String name) throws NoSuchFieldException {
        for (Class<?> c = plugin.getClass(); c != null; c = c.getSuperclass()) try {
            Field f = c.getDeclaredField(name); f.setAccessible(true); return f;
        } catch (NoSuchFieldException next) {}
        throw new NoSuchFieldException(name);
    }
    private static Object get(JavaPlugin plugin, String name) {
        try { return field(plugin, name).get(plugin); }
        catch (ReflectiveOperationException failure) { throw new IllegalStateException(failure); }
    }
    private static void set(JavaPlugin plugin, String name, Object value) {
        try { field(plugin, name).set(plugin, value); }
        catch (ReflectiveOperationException failure) { throw new IllegalStateException(failure); }
    }
    private static Object invoke(JavaPlugin plugin, String name, Class<?>[] types, Object... args) {
        try {
            for (Class<?> c = plugin.getClass(); c != null; c = c.getSuperclass()) try {
                Method m = c.getDeclaredMethod(name, types); m.setAccessible(true); return m.invoke(plugin, args);
            } catch (NoSuchMethodException next) {}
            throw new NoSuchMethodException(name);
        } catch (InvocationTargetException failure) {
            throw new IllegalStateException(name, failure.getCause());
        } catch (ReflectiveOperationException failure) { throw new IllegalStateException(name, failure); }
    }
}

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$sourceRoot = 'C:\Users\WaveJ\Documents\Codex\2026-11-07\ban'
$targetRoot = 'D:\CodexWorkspace\ban'
$sourceRoot = [IO.Path]::GetFullPath($sourceRoot).TrimEnd('\')
$targetRoot = [IO.Path]::GetFullPath($targetRoot).TrimEnd('\')
function Get-MigrationHash([string]$LiteralPath) {
    $stream = [IO.File]::OpenRead($LiteralPath)
    $algorithm = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($algorithm.ComputeHash($stream)).Replace('-', '') }
    finally { $algorithm.Dispose(); $stream.Dispose() }
}
if ($sourceRoot -ne 'C:\Users\WaveJ\Documents\Codex\2026-11-07\ban' -or $targetRoot -ne 'D:\CodexWorkspace\ban') { throw 'Unexpected migration roots' }
Set-Location -LiteralPath $env:TEMP
$mutex = New-Object Threading.Mutex($false, 'Local\WaveDog-Workspace-Migration')
if (-not $mutex.WaitOne(0)) { throw 'Another migration is already running' }
try {
    $beforeFree = (Get-PSDrive -Name C).Free
    New-Item -ItemType Directory -Path $targetRoot -Force | Out-Null
    $marker = Join-Path $targetRoot '.wavedog-workspace-migration.json'
    if (Test-Path -LiteralPath $marker) {
        $state = Get-Content -LiteralPath $marker -Raw | ConvertFrom-Json
        if ($state.source -ne $sourceRoot -or $state.target -ne $targetRoot) { throw 'Destination belongs to another migration' }
    } else {
        if (@(Get-ChildItem -LiteralPath $targetRoot -Force).Count -gt 0) { throw 'Destination is not empty; nothing overwritten or removed' }
        @{source=$sourceRoot;target=$targetRoot;started=(Get-Date).ToString('o')} | ConvertTo-Json | Set-Content -LiteralPath $marker -Encoding UTF8
    }
    $entries = @(Get-ChildItem -LiteralPath $sourceRoot -Force)
    $pending = @()
    foreach ($entry in $entries) {
        $src = [IO.Path]::GetFullPath($entry.FullName)
        $dst = [IO.Path]::GetFullPath((Join-Path $targetRoot $entry.Name))
        if (-not $src.StartsWith($sourceRoot+'\', [StringComparison]::OrdinalIgnoreCase) -or -not $dst.StartsWith($targetRoot+'\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Path escaped intended workspace' }
        if (($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            if (-not $entry.PSIsContainer -or $entry.LinkType -ne 'Junction' -or [IO.Path]::GetFullPath([string]$entry.Target[0]).TrimEnd('\') -ne $dst) { throw "Unexpected link: $src" }
            Write-Host "Already moved: $($entry.Name)"
            continue
        }
        if ($entry.PSIsContainer) {
            $links = @(Get-ChildItem -LiteralPath $src -Recurse -Force | Where-Object { ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 })
            if ($links.Count -gt 0) { throw "Nested filesystem link found in $src; nothing from this directory removed" }
            Write-Host "Copying $($entry.Name) ..."
            & robocopy.exe $src $dst /E /COPY:DAT /DCOPY:DAT /R:2 /W:1 /XJ /NP /NFL /NDL "/LOG+:$(Join-Path $targetRoot 'migration-copy.log')"
            if ($LASTEXITCODE -gt 7) { throw "Copy failed for $src (robocopy $LASTEXITCODE)" }
        } else { Copy-Item -LiteralPath $src -Destination $dst -Force }
        $pending += [PSCustomObject]@{Source=$src;Target=$dst;Directory=$entry.PSIsContainer}
    }
    $verified = New-Object 'System.Collections.Generic.List[object]'
    foreach ($item in $pending) {
        $files = if ($item.Directory) { @(Get-ChildItem -LiteralPath $item.Source -File -Recurse -Force) } else { @(Get-Item -LiteralPath $item.Source) }
        $index = 0
        foreach ($file in $files) {
            $relative = $file.FullName.Substring($sourceRoot.Length+1)
            $copy = [IO.Path]::GetFullPath((Join-Path $targetRoot $relative))
            if (-not $copy.StartsWith($targetRoot+'\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Invalid verification target' }
            if (-not (Test-Path -LiteralPath $copy -PathType Leaf)) { throw "Missing copied file: $relative" }
            if ($file.Length -ne (Get-Item -LiteralPath $copy).Length) { throw "Size mismatch: $relative" }
            $hash = Get-MigrationHash -LiteralPath $file.FullName
            if ($hash -ne (Get-MigrationHash -LiteralPath $copy)) { throw "Hash mismatch: $relative" }
            $verified.Add([PSCustomObject]@{path=$relative;bytes=$file.Length;sha256=$hash})
            $index++
            if ($index % 100 -eq 0) { Write-Progress -Activity "Verifying $($item.Source)" -Status "$index / $($files.Count) files" -PercentComplete (100*$index/[Math]::Max(1,$files.Count)) }
        }
        Write-Progress -Activity Verifying -Completed
    }
    if ($verified.Count -gt 0) { $verified | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $targetRoot 'migration-files.json') -Encoding UTF8 }
    foreach ($item in $pending) {
        # Resolve and check the exact deletion target again immediately before recursive removal.
        $resolved = (Resolve-Path -LiteralPath $item.Source).ProviderPath.TrimEnd('\')
        if ($resolved -ne $item.Source -or -not $resolved.StartsWith($sourceRoot+'\', [StringComparison]::OrdinalIgnoreCase) -or $resolved -eq $sourceRoot) { throw 'Unsafe removal target; verified D copy preserved' }
        if ($item.Directory) {
            Remove-Item -LiteralPath $resolved -Recurse -Force
            # A junction stores only a path, with no C-drive copy of the files.
            New-Item -ItemType Junction -Path $resolved -Target $item.Target | Out-Null
        } else { Remove-Item -LiteralPath $resolved -Force }
    }
    $released = ((Get-PSDrive -Name C).Free - $beforeFree) / 1GB
    Write-Host "DONE: Workspace is now $targetRoot"
    Write-Host ('C drive released approximately {0:N2} GiB. Old folder links use D storage only.' -f $released)
    Write-Host 'Open D:\CodexWorkspace\ban in Codex for future work. The Minecraft server directory was not moved.'
} catch {
    Write-Host ('FAILED: '+$_.Exception.Message) -ForegroundColor Red
    Write-Host 'Verified D files are preserved. Do not manually delete either location. Report the FAILED line.'
    exit 1
} finally { $mutex.ReleaseMutex(); $mutex.Dispose() }

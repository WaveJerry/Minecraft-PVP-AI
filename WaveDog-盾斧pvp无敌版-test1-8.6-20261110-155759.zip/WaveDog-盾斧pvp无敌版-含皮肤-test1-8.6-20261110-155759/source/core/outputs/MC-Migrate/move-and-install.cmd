@echo off
setlocal
cd /d "%TEMP%"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "D:\CodexWorkspace\ban\outputs\MC-Migrate\finish-all.ps1"
set "wavedog_final_exit=%errorlevel%"
pause
exit /b %wavedog_final_exit%

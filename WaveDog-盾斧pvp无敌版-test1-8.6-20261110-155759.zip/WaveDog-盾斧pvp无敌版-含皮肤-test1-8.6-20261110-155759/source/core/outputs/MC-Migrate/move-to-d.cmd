@echo off
setlocal
set "wavedog_migrate_script=%~dp0move-to-d.ps1"
cd /d "%TEMP%"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%wavedog_migrate_script%"
set "wavedog_migrate_exit=%errorlevel%"
pause
exit /b %wavedog_migrate_exit%

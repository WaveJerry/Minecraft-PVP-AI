public final class DuelPlayerLoadCheck {
    public static void main(String[] args)throws Exception {
        var archive=new RestartCheck.Archive(java.nio.file.Path.of(args[0]),null);
        for(String name:java.util.List.of("PvPArenaAI","DuelPlayerCommands","DuelPlayerCommands$Selection")) {
            var c=archive.type(name);if(c.getDeclaredMethods().length==0)throw new AssertionError(name);
        }
        Class<?> api=Class.forName("fr.xephi.authme.api.v3.AuthMeApi");
        api.getMethod("getInstance");api.getMethod("isAuthenticated",Class.forName("org.bukkit.entity.Player"));
        System.out.println("PASS: actual patched entry/helper JVM verified under Paper 1.21.1 and actual AuthMe API; reflection API signatures present");
    }
}

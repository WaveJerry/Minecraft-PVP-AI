package local.wavedog.probe;

import java.lang.reflect.*;
import java.util.*;
import io.github.hello09x.fakeplayer.api.spi.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

/** Real physics, real controller and the shipped instant-turn/native attack path. Test server only. */
final class NativeEscapeProbe implements Listener {
    private final JavaPlugin plugin;private final Object ai;private final Player own;
    private final List<String> log;private final Runnable finish;
    private Player target;private Object brain,memory,controller;private NMSBridge bridge;
    private long armed;private int frames,crits;private double startZ;private boolean descending;
    NativeEscapeProbe(JavaPlugin plugin,Object ai,Player own,List<String> log,Runnable finish) {
        this.plugin=plugin;this.ai=ai;this.own=own;this.log=log;this.finish=finish;
    }
    private Class<?> type(String n)throws Exception{return Class.forName("local.pvpbot.ai."+n,true,ai.getClass().getClassLoader());}
    private Object call(Object o,String n,Class<?>[] t,Object...a)throws Exception {var m=o.getClass().getDeclaredMethod(n,t);m.setAccessible(true);return m.invoke(o,a);}
    private Object helper(String c,String n,Class<?>[] t,Object...a)throws Exception {var m=type(c).getDeclaredMethod(n,t);m.setAccessible(true);return m.invoke(null,a);}
    private Object get(Object o,String n)throws Exception {var f=o.getClass().getDeclaredField(n);f.setAccessible(true);return f.get(o);}
    private void set(Object o,String n,Object a)throws Exception {var f=o.getClass().getDeclaredField(n);f.setAccessible(true);f.set(o,a);}
    private Object value(Object o,String n)throws Exception{return call(o,n,new Class<?>[]{});}
    private void check(boolean b,String text){if(!b)throw new IllegalStateException(text);log.add("PASS "+text);plugin.getLogger().info("PASS "+text);}
    private void fail(Throwable e){log.add("FAILED native escape "+e);e.printStackTrace();finish.run();}
    void start() {
        Bukkit.getPluginManager().registerEvents(this,plugin);
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(),"fp spawn ChaseProbe");
        // Wait out vanilla player spawn protection instead of clearing immunity.
        Bukkit.getScheduler().runTaskLater(plugin,()->{try{prepare();}catch(Throwable e){fail(e);}},70);
    }
    private void prepare()throws Exception {
        target=Bukkit.getPlayerExact("ChaseProbe");check(target!=null,"native escape pursuer spawned");
        for(var p:List.of(own,target)) {
            p.teleport(new Location(own.getWorld(),.5,101,p==own?.5:-1.8,0,0));
            p.setGameMode(GameMode.SURVIVAL);p.setHealth(20);p.setFoodLevel(20);
            p.setCooldown(Material.SHIELD,0);p.getInventory().clear();
            p.getInventory().setItemInMainHand(new ItemStack(Material.DIAMOND_SWORD));
            p.setVelocity(new org.bukkit.util.Vector());
        }
        bridge=(NMSBridge)get(ai,"bridge");
        brain=call(ai,"brainFor",new Class<?>[]{Player.class},own);memory=get(brain,"memory");
        var learner=get(brain,"learner");call(learner,"useInitialRules",new Class<?>[]{});
        controller=call(learner,"groundController",new Class<?>[]{});
        own.getInventory().setItemInOffHand(new ItemStack(Material.SHIELD));own.setCooldown(Material.SHIELD,150);
        call(ai,"cancelCombatUse",new Class<?>[]{Player.class,type("CombatMemory")},own,memory);
        helper("NativeUseSession","detachQueuedUse",new Class<?>[]{ai.getClass(),Player.class},ai,own);
        call(get(memory,"melee"),"requestWithdrawal",new Class<?>[]{});
        call(get(memory,"melee"),"useEscapeSword",new Class<?>[]{boolean.class},true);
        armed=(long)get(ai,"tick");call(controller,"confirmedCounterHop",new Class<?>[]{long.class},armed);
        startZ=own.getZ();
        for(var p:List.of(own,target)){p.setSprinting(true);bridge.fromPlayer(p).setZza(1);bridge.fromPlayer(p).setXxa(0);}
        // Production equips the sword in the confirmed axe-hit call; its one-JUMP
        // input runs in the next input frame. Preserve that genuine equip/tick order.
        Bukkit.getScheduler().runTaskLater(plugin,()->{try{launch();}catch(Throwable e){fail(e);}},2);
    }
    private void launch()throws Exception {
        log.add("escape launch native ground="+own.isOnGround()+" vy="+own.getVelocity().getY()+" charge="+own.getCooledAttackStrength(.5f));
        check((boolean)helper("NativeUseSession","jumpNow",new Class<?>[]{ai.getClass(),Player.class},ai,own),"escape uses the normal once-JUMP input");
        bridge.fromPlayer(target).jumpFromGround();call(controller,"jumpInputSubmitted",new Class<?>[]{long.class},armed);
        Bukkit.getScheduler().runTaskTimer(plugin,task->{
            try {
                frames++;long tick=(long)get(ai,"tick");
                if(frames>18)throw new IllegalStateException("No native critical before landing");
                if(own.isOnGround())return;
                double reach=(double)helper("CombatInputHooks","eyeBox",new Class<?>[]{Player.class,Player.class},own,target);
                var nativeState=helper("NativeCriticalState","read",new Class<?>[]{Player.class},own);
                boolean window=(boolean)value(nativeState,"afterSprintRelease");
                if(own.getVelocity().getY()<0&&own.getFallDistance()>0)descending=true;
                var ctor=type("NeuralLearner$Senses").getDeclaredConstructor();ctor.setAccessible(true);var senses=ctor.newInstance();
                for(var e:Map.<String,Object>ofEntries(Map.entry("onGround",own.isOnGround()),Map.entry("ownY",own.getVelocity().getY()),
                    Map.entry("ownWeapon",1),Map.entry("weaponInputReady",frames>=1),Map.entry("estimateAge",0.),
                    Map.entry("targetMotionFresh",true),Map.entry("ownReachDistance",reach),Map.entry("targetReachDistance",reach),
                    Map.entry("ownShieldCooldown",(double)own.getCooldown(Material.SHIELD)),Map.entry("withdrawing",true),
                    Map.entry("ownCriticalWindow",window),Map.entry("ownCriticalReady",false),Map.entry("counterAxeHitTick",armed)).entrySet())set(senses,e.getKey(),e.getValue());
                set(memory,"lastSeenAt",tick);set(memory,"lastSeenTarget",target.getLocation().toVector());
                set(memory,"lastSeenTargetEyeHeight",target.getEyeHeight());
                set(memory,"observedOwnVelocity",own.getVelocity());set(memory,"observedTargetVelocity",target.getVelocity());
                set(memory,"lastWeaponSwitch",armed-1);set(memory,"weaponReadyUntil",armed);
                call(controller,"hopCriticalObservation",new Class<?>[]{float.class,double.class},own.getCooledAttackStrength(.5f),own.getVelocity().getY());
                var view=makeView(tick,reach);
                var decision=call(controller,"decide",new Class<?>[]{type("CombatView"),type("NeuralLearner$Senses")},view,senses);
                String phase=(String)value(controller,"phaseName");
                log.add("escape frame="+frames+" vy="+own.getVelocity().getY()+" fall="+own.getFallDistance()+" charge="+own.getCooledAttackStrength(.5f)+" reach="+reach+" phase="+phase);
                if(phase.equals("HOP_CRIT")) {
                    var before=own.getVelocity();long begin=System.nanoTime();
                    log.add("pre attack active="+own.getActiveItem().getType()+" pendingOffhand="+get(memory,"pendingOffhandSlot")+" restoreMain="+get(memory,"restoreMainSlot")+" readyUntil="+get(memory,"weaponReadyUntil")+" switch="+get(memory,"lastWeaponSwitch")+" current="+tick+" canPrepare="+call(ai,"canPrepareCritical",new Class<?>[]{Player.class},own));
                    call(ai,"executeCombatFrame",new Class<?>[]{Player.class,Player.class,brain.getClass(),type("CombatView"),type("NeuralLearner$Senses"),type("CombatDecision")},own,target,brain,view,senses,decision);
                    log.add("post attack input="+get(memory,"lastAttackInput")+" crits="+crits+" native="+get(controller,"nativeOutcomeKnown")+" sprint="+own.isSprinting()+" yaw="+own.getLocation().getYaw()+" targetHealth="+target.getHealth());
                    check(crits==1,"shipped escape controller/instant-turn emitted a real critical damage event");
                    check(descending&&own.getFallDistance()>0,"real descending displacement populated native fallDistance");
                    check(own.isSprinting()&&Math.abs(own.getLocation().getYaw())<.01,"same-call attack restored sprint and original escape direction");
                    check(own.getVelocity().equals(before),"instant turn did not modify escape velocity");
                    check(own.getZ()-startZ>2,"one forward sprint jump travelled more than two blocks before the critical");
                    log.add("instant attack/restore elapsed_ms="+(System.nanoTime()-begin)/1e6);
                    task.cancel();shieldStart();
                }
            }catch(Throwable e){task.cancel();fail(e);}
        },1,1);
    }
    private Object makeView(long tick,double reach)throws Exception {
        var components=type("CombatView").getRecordComponents();var values=new Object[components.length];var types=new Class<?>[components.length];
        var data=Map.<String,Object>of("tick",tick,"distance",reach,"visible",true,"targetInReach",reach<=3,
            "ownAttackCharge",own.getCooledAttackStrength(0),"ownOffhand",Enum.valueOf(type("OffhandMode").asSubclass(Enum.class),"SHIELD"));
        for(int i=0;i<components.length;i++) {
            types[i]=components[i].getType();Object fallback=null;
            if(types[i]==boolean.class)fallback=false;
            else if(types[i]==double.class)fallback=0.;
            else if(types[i]==float.class)fallback=0f;
            else if(types[i]==int.class)fallback=0;
            else if(types[i]==long.class)fallback=0L;
            values[i]=data.getOrDefault(components[i].getName(),fallback);
        }
        var ctor=type("CombatView").getDeclaredConstructor(types);ctor.setAccessible(true);return ctor.newInstance(values);
    }
    private void shieldStart()throws Exception {
        for(var p:List.of(own,target)){bridge.fromPlayer(p).setZza(0);p.setSprinting(false);p.setVelocity(new org.bukkit.util.Vector());}
        own.teleport(new Location(own.getWorld(),.5,101,.5));target.teleport(new Location(own.getWorld(),.5,101,2.5,180,0));
        target.getInventory().setItemInOffHand(new ItemStack(Material.SHIELD));
        helper("NativeOffhandUse","use",new Class<?>[]{Player.class},target);
        check(target.hasActiveItem()&&!target.isBlocking()&&!effective(),"newly raised shield before native delay is not effective");
        Bukkit.getScheduler().runTaskLater(plugin,()->{try{
            check(target.isBlocking()&&effective(),"warmed front-facing shield is effective");
            target.setRotation(0,0);check(target.isBlocking()&&!effective(),"warmed shield facing away does not block the critical opportunity");
            target.setRotation(180,0);helper("VanillaUseRelease","release",new Class<?>[]{Object.class},target);
            check(!effective(),"lowered shield stops suppressing the critical opportunity");finish.run();
        }catch(Throwable e){fail(e);}},7);
    }
    private boolean effective()throws Exception{return (boolean)helper("CombatInputHooks","effectiveShield",new Class<?>[]{Player.class,Player.class},own,target);}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void damage(EntityDamageByEntityEvent event){if(event.getDamager().equals(own)&&event.getEntity().equals(target)&&event.isCritical()&&event.getFinalDamage()>0)crits++;}
}

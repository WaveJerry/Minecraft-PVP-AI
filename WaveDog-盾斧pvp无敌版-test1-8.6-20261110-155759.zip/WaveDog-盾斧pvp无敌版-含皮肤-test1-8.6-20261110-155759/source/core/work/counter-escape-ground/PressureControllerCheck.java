import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import java.util.function.BiPredicate;

/** Execute the packaged controller with RestartCheck fixtures; no server/model writes. */
public final class PressureControllerCheck {
    static int checks;
    static RestartCheck.Archive archive;

    static void check(boolean ok,String why) {
        checks++;
        if(!ok) throw new AssertionError(why);
    }
    static Object call(Object receiver,String name,Class<?>[] types,Object...args)throws Exception {
        Method method=receiver.getClass().getDeclaredMethod(name,types);
        method.setAccessible(true);return method.invoke(receiver,args);
    }
    static Object field(Object receiver,String name)throws Exception {
        Field f=receiver.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(receiver);
    }
    static boolean flag(Object receiver,String name)throws Exception {
        return (boolean)call(receiver,name,new Class<?>[]{});
    }
    static Object decision(RestartCheck.Controller controller)throws Exception {
        return field(controller.controller,"decision");
    }
    static String value(Object receiver,String name)throws Exception {
        return call(receiver,name,new Class<?>[]{}).toString();
    }
    static RestartCheck.Controller controller(int profile,long seed)throws Exception {
        return new RestartCheck.Controller(archive,profile,seed);
    }
    static Map<String,Object> entry(double distance) {
        var s=RestartCheck.senses(distance);
        s.put("opportunity","ENTRY");s.put("enteredReach",true);
        s.put("ownShieldCooldown",80.);
        return s;
    }
    static Object viewObject(Map<String,Object> v)throws Exception {
        var components=archive.type("CombatView").getRecordComponents();
        Class<?>[] types=new Class<?>[components.length];Object[] values=new Object[components.length];
        for(int i=0;i<components.length;i++) {
            types[i]=components[i].getType();Object raw=v.get(components[i].getName());
            values[i]=types[i].isEnum()?RestartCheck.enumValue(types[i],(String)raw):raw;
        }
        return archive.make("CombatView",types,values);
    }
    static Object sensesObject(Map<String,Object> s)throws Exception {
        Object result=archive.make("NeuralLearner$Senses",new Class<?>[]{});
        for(var e:s.entrySet()) {
            Field f=result.getClass().getDeclaredField(e.getKey());f.setAccessible(true);
            f.set(result,f.getType().isEnum()?RestartCheck.enumValue(f.getType(),(String)e.getValue()):e.getValue());
        }
        return result;
    }
    static Object groundHeading(RestartCheck.Controller c,Map<String,Object> v,Map<String,Object> s)throws Exception {
        Class<?> body=archive.type("PrecisionFootwork$Body");
        Object own=archive.make("PrecisionFootwork$Body",new Class<?>[]{double.class,double.class,double.class,double.class},0.,0.,0.,0.);
        Object target=archive.make("PrecisionFootwork$Body",new Class<?>[]{double.class,double.class,double.class,double.class},4.3,0.,0.,0.);
        return call(c.controller,"groundHeading",new Class<?>[]{body,body,boolean.class,double.class,double.class,double.class,double.class,
            BiPredicate.class,archive.type("CombatView"),archive.type("NeuralLearner$Senses")},
            own,target,true,-20.,20.,-20.,20.,(BiPredicate<Double,Double>)((x,z)->true),viewObject(v),sensesObject(s));
    }
    static void before(RestartCheck.Controller c,double dealt)throws Exception {
        call(c.controller,"beforeMelee",new Class<?>[]{double.class},dealt);
    }
    static void confirm(RestartCheck.Controller c,long tick,double dealt)throws Exception {
        call(c.controller,"confirmedPressureDamage",new Class<?>[]{long.class,double.class},tick,dealt);
    }
    static void requireStrike(RestartCheck.Controller c,String context)throws Exception {
        Object d=decision(c);
        check(c.phase().equals("PRESSURE_STRIKE"),context+": ground ENTRY bypassed full-charge pressure strike: "+d+"/"+c.phase());
        check(flag(d,"attack")&&flag(d,"sprint"),context+": pressure strike must attack while sprinting");
        check(value(d,"motion").equals("FORWARD"),context+": pressure strike must advance");
        check(value(d,"weapon").equals("AXE")&&value(d,"technique").equals("AXE_READY"),context+": pressure strike must use ready axe, never FALL_CRIT");
        for(String f:List.of("shield","jump","faceAway","sneak"))check(!flag(d,f),context+": forbidden "+f);
        check(flag(c.controller,"sprintKnockbackInput"),context+": native sprint knockback marker missing");
        check(!flag(c.controller,"pressureRecovering"),context+": attempt alone armed recovery");
    }
    static RestartCheck.Controller armed(int profile,long tick)throws Exception {
        var c=controller(profile,9000+tick);var v=RestartCheck.view(tick,2.6,false);var s=entry(2.6);
        s.put("ownCriticalReady",true);s.put("ownCriticalWindow",true);
        c.step(v,s);requireStrike(c,"profile="+profile+" tick="+tick);
        before(c,10.);confirm(c,tick,12.);
        check(flag(c.controller,"pressureRecovering"),"confirmed increased damage must arm recovery");
        check(!flag(c.controller,"controlAfterExit"),"same-hit recovery must permit original InstantTurn resume");
        return c;
    }
    static void requireRecharge(RestartCheck.Controller c,String context)throws Exception {
        Object d=decision(c);
        check(c.phase().equals("PRESSURE_RECHARGE"),context+": ENTRY or another loop branch stole recovery: "+d+"/"+c.phase());
        check(flag(d,"sprint")&&flag(d,"faceAway"),context+": recharge must turn and sprint away");
        check(value(d,"weapon").equals("AXE")&&value(d,"technique").equals("AXE_WAIT"),context+": recharge retains waiting axe");
        for(String f:List.of("attack","jump","shield","sneak"))check(!flag(d,f),context+": recharge requested "+f);
        check(flag(c.controller,"pressureRecovering"),context+": low charge prematurely released recovery");
    }
    static Object body(double x,double y,double vx,double vy,boolean ground)throws Exception {
        return archive.make("AirborneEnvelope$Body",new Class<?>[]{double.class,double.class,double.class,double.class,double.class,
            double.class,double.class,double.class,double.class,double.class,boolean.class},x,y,0.,vx,vy,0.,1.62,.3,.3,1.8,ground);
    }
    static Object threat(double x,double vx,double vy)throws Exception {
        Class<?> body=archive.type("AirborneEnvelope$Body");
        Method m=archive.type("AirborneEnvelope").getDeclaredMethod("forecast",body,body,double.class,double.class,
            boolean.class,boolean.class,double.class,double.class);m.setAccessible(true);
        Object result=m.invoke(null,body(0,0,0,0,true),body(x,.6,vx,vy,false),0.,.02548,true,true,1.,1.);
        check(flag(result,"valid")&&flag(result,"threat"),"air fixture must use a valid production melee threat");
        return result;
    }
    static Map<String,Object> air(double distance,double y,Object threat)throws Exception {
        var s=entry(distance);s.put("targetAirborne",true);s.put("targetCritThreat",true);s.put("targetCriticalPossible",true);
        s.put("targetY",y);s.put("targetCritEta",5.);s.put("targetKnockbackAge",1000.);s.put("airEnvelope",threat);
        s.put("risingPlan",archive.make("RisingIntercept$Plan",new Class<?>[]{boolean.class,int.class,double.class,double.class},true,0,2.6,4.));
        s.put("jumpSpace",archive.make("JumpThreatSpacing$Plan",new Class<?>[]{boolean.class,int.class,double.class,double.class,double.class,
            boolean.class,boolean.class},true,2,3.4,-1.,0.,true,true));
        return s;
    }
    static void cadence(int profile)throws Exception {
        var c=armed(profile,100);
        for(long tick=101;tick<=104;tick++) {
            var v=RestartCheck.view(tick,2.6,false);v.put("ownAttackCharge",tick==104?.998f:.1f);
            var s=entry(2.6);s.put("ownCriticalReady",true);s.put("ownCriticalWindow",true);
            c.step(v,s);
            if (tick==101) {
                check(c.phase().equals("RECHARGE_REPLY")&&flag(decision(c),"attack"),"close pursuer permits one low-charge reply");
                before(c,12.);call(c.controller,"meleeAttemptFinished",new Class<?>[]{long.class,double.class,boolean.class},tick,12.,false);
            } else requireRecharge(c,"profile="+profile+" recharge="+tick);
        }
        var full=RestartCheck.view(105,4.,false);var normal=RestartCheck.senses(4.);
        c.step(full,normal);Object d=decision(c);
        check(!flag(c.controller,"pressureRecovering"),"actual full charge must release pressure recovery");
        check(!flag(d,"faceAway")&&!flag(d,"jump")&&!flag(d,"attack"),"full charge must restore ordinary ground control: "+d+"/"+c.phase());
        check(!Set.of("PRESSURE_RECHARGE","ESCAPE","AIR_ESCAPE","RELOAD_ESCAPE").contains(c.phase()),"full charge left a persistent escape phase");
        Object heading=groundHeading(c,full,normal);
        check(heading!=null&&(double)call(heading,"x",new Class<?>[]{})==0,"full charge at far range must not force continuous advance");
        check(!flag(c.controller,"counterHopActive")&&!(boolean)field(c.controller,"counterFlight")&&!(boolean)field(c.controller,"escapeObserved"),"pressure cadence must not leave counter/escape flight state");
        var idle=RestartCheck.view(106,4.,false);idle.put("ownAttackCharge",.2f);
        c.step(idle,normal);
        check(!flag(c.controller,"pressureRecovering")&&!flag(decision(c),"faceAway"),"later unrelated low charge must not restart escape");
        c.step(RestartCheck.view(107,2.6,false),entry(2.6));requireStrike(c,"next full-charge cycle profile="+profile);
    }
    static void failedHits(int profile)throws Exception {
        var idle=controller(profile,18100);before(idle,20.);confirm(idle,10,21.);
        check(!flag(idle.controller,"pressureRecovering"),"non-pressure damage must not arm recovery");
        var c=controller(profile,18101);c.step(RestartCheck.view(20,2.6,false),entry(2.6));requireStrike(c,"failed hit profile="+profile);
        before(c,30.);
        for(double dealt:new double[]{30.,29.,Double.NaN}) {
            confirm(c,20,dealt);
            check(!flag(c.controller,"pressureRecovering"),"blocked, missed, decreased or invalid damage must not arm recovery: "+dealt);
        }
        confirm(c,20,30.01);
        check(flag(c.controller,"pressureRecovering"),"actual increased dealt damage must arm pressure recovery");
        var low=controller(profile,18102);var v=RestartCheck.view(30,2.6,false);v.put("ownAttackCharge",.1f);
        low.step(v,entry(2.6));
        check(!low.phase().equals("PRESSURE_STRIKE"),"low-charge legacy ENTRY must not masquerade as deliberate full-charge pressure");
        before(low,40.);confirm(low,30,41.);
        check(!flag(low.controller,"pressureRecovering"),"damage from a non-pressure ENTRY must not arm pressure recharge");
    }
    static void emergencyPriority(int profile)throws Exception {
        Object falling=threat(3.8,-.25,-.15),rising=threat(2.9,-.05,.25);
        var shield=armed(profile,200);var guard=RestartCheck.view(201,3.5,true);guard.put("ownAttackCharge",.1f);
        shield.step(guard,air(3.5,-.15,falling));Object d=decision(shield);
        check(shield.phase().equals("AIR_CONTROL")&&flag(d,"shield"),"available shield during recovery must own airborne defense: "+d+"/"+shield.phase());
        for(String f:List.of("attack","jump","sprint","faceAway"))check(!flag(d,f),"shield air guard forbids "+f);
        var fallingRecovery=armed(profile,300);var fallView=RestartCheck.view(301,3.5,false);fallView.put("ownAttackCharge",.1f);
        fallingRecovery.step(fallView,air(3.5,-.15,falling));d=decision(fallingRecovery);
        check(fallingRecovery.phase().equals("AIR_DODGE")&&!flag(d,"attack"),"dangerous falling opponent must interrupt ground recharge: "+d+"/"+fallingRecovery.phase());
        check(!flag(d,"shield")&&!flag(d,"faceAway"),"falling defense must not keep blind pressure retreat or request broken shield");
        var risingRecovery=armed(profile,400);var riseView=RestartCheck.view(401,2.6,false);riseView.put("ownAttackCharge",.1f);
        risingRecovery.step(riseView,air(2.6,.25,rising));d=decision(risingRecovery);
        check(risingRecovery.phase().equals("AIR_INTERRUPT")&&flag(d,"attack"),"available rising contact interrupt must precede pressure recharge");
        check(!flag(d,"jump")&&!flag(d,"shield"),"rising interrupt must retain existing grounded/broken-shield constraints");
    }
    static void wallAndReset(int profile)throws Exception {
        for(boolean near:new boolean[]{false,true}) {
            var c=armed(profile,near?600:500);long tick=near?601:501;
            var v=RestartCheck.view(tick,3.5,false);v.put("ownAttackCharge",.1f);v.put("nearWall",near);
            var s=RestartCheck.senses(3.5);s.put("retreatBlocked",!near);s.put("wallEscapeAvailable",false);
            c.step(v,s);Object d=decision(c);
            check(c.phase().equals("WALL_ENGAGE"),"blocked/near-wall recharge must delegate original wall control: "+d+"/"+c.phase());
            for(String f:List.of("faceAway","jump","attack"))check(!flag(d,f),"safe wall control must not blindly continue pressure "+f);
        }
        var reset=armed(profile,700);call(reset.controller,"reset",new Class<?>[]{});
        check(!flag(reset.controller,"pressureRecovering")&&!flag(reset.controller,"controlAfterExit"),"controller lifecycle reset must clear pressure recovery and post-exit control");
        check(!flag(reset.controller,"counterHopActive")&&reset.phase().equals("SEARCH"),"controller reset must preserve normal clean state");
        var v=RestartCheck.view(1,4.,false);v.put("ownAttackCharge",.1f);reset.step(v,RestartCheck.senses(4.));
        check(!reset.phase().equals("PRESSURE_RECHARGE")&&!flag(reset.controller,"pressureRecovering"),"low charge after reset must not restore the old pressure cycle");
    }
    public static void main(String[] args)throws Exception {
        if(args.length!=1)throw new IllegalArgumentException("Usage: PressureControllerCheck <built-jar>");
        archive=new RestartCheck.Archive(Path.of(args[0]),null);
        for(int profile=0;profile<2;profile++) {
            cadence(profile);failedHits(profile);emergencyPriority(profile);wallAndReset(profile);
        }
        System.out.println("PressureControllerCheck: "+checks+" assertions passed; both profiles: full-charge ground ENTRY pressure, actual damage qualification, same-hit InstantTurn resume, recharge loop priority, full-charge ground return, misses/blocks, airborne shield/interrupt priority, safe wall delegation and lifecycle reset. No server/model writes.");
    }
}

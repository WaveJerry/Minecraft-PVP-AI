package local.wavedog.health;

import java.util.*;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import io.papermc.paper.scoreboard.numbers.NumberFormat;

/** Original clients display a server-formatted heart row below player nameplates. */
public final class HeadHeartsPlugin extends JavaPlugin {
    private static final String ID="wd_hearts";
    private final Map<Scoreboard,Objective> previous=new WeakHashMap<>();
    private final Map<Scoreboard,Map<String,String>> displayed=new WeakHashMap<>();
    static final int RED=0xff3333,HALF=0xff9c9c,EMPTY=0x555555,GOLD=0xffcc33;
    static Component hearts(double health,double maximum,double absorption) {
        if(!Double.isFinite(maximum)||maximum<=0)maximum=20;
        if(!Double.isFinite(health))health=0;
        if(!Double.isFinite(absorption))absorption=0;
        health=Math.max(0,Math.min(maximum,health));absorption=Math.max(0,absorption);
        int count=Math.min(40,(int)Math.ceil(maximum/2));Component line=Component.empty();
        for(int i=0;i<count;i++) {
            double points=Math.min(2,health-i*2);
            // Font hearts require no client mod/resource pack. A pale heart marks half
            // health; the HUD's textured half-heart cannot be embedded in nameplate text.
            line=line.append(Component.text("❤",TextColor.color(points>=2?RED:points>0?HALF:EMPTY)));
        }
        for(int i=0;i<Math.min(20,(int)Math.ceil(absorption/2));i++)
            line=line.append(Component.text("❤",TextColor.color(GOLD)));
        return line;
    }
    @Override public void onEnable() {
        Bukkit.getScheduler().runTaskTimer(this,this::update,1,2);
    }
    private void update() {
        Set<Scoreboard> boards=Collections.newSetFromMap(new IdentityHashMap<>());
        boards.add(Bukkit.getScoreboardManager().getMainScoreboard());
        for(Player viewer:Bukkit.getOnlinePlayers())boards.add(viewer.getScoreboard());
        for(var board:boards) {
            Objective objective=board.getObjective(ID);
            if(objective==null)objective=board.registerNewObjective(ID,Criteria.DUMMY,Component.empty(),RenderType.HEARTS);
            if(!previous.containsKey(board))previous.put(board,board.getObjective(DisplaySlot.BELOW_NAME));
            if(board.getObjective(DisplaySlot.BELOW_NAME)!=objective)objective.setDisplaySlot(DisplaySlot.BELOW_NAME);
            var cache=displayed.computeIfAbsent(board,key->new HashMap<>());var online=new HashSet<String>();
            for(Player player:Bukkit.getOnlinePlayers()) {
                online.add(player.getName());double max=player.getMaxHealth(),hp=player.getHealth(),abs=player.getAbsorptionAmount();
                String value=hp+":"+max+":"+abs;
                if(value.equals(cache.put(player.getName(),value)))continue;
                var score=objective.getScore(player.getName());score.setScore((int)Math.ceil(hp));
                score.numberFormat(NumberFormat.fixed(hearts(hp,max,abs)));
            }
            for(String old:new HashSet<>(cache.keySet()))if(!online.contains(old)) {
                objective.getScore(old).resetScore();cache.remove(old);
            }
        }
    }
    @Override public void onDisable() {
        for(var entry:previous.entrySet()) {
            var own=entry.getKey().getObjective(ID);
            if(own!=null)own.unregister();
            if(entry.getValue()!=null) {
                try{entry.getValue().setDisplaySlot(DisplaySlot.BELOW_NAME);}catch(IllegalStateException ignored){}
            }
        }
        previous.clear();displayed.clear();
    }
}

package local.wavedog.testtools;

import java.util.*;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;
import io.papermc.paper.event.entity.EntityKnockbackEvent;

/** Explicit, off-by-default stress-test aid for real players. No bot physics are changed. */
public final class KnockbackTestPlugin extends JavaPlugin implements Listener,CommandExecutor {
    private final Map<UUID,String> modes=new HashMap<>();
    private final Map<UUID,Integer> counts=new HashMap<>();
    @Override public void onEnable(){Bukkit.getPluginManager().registerEvents(this,this);Objects.requireNonNull(getCommand("kbtest")).setExecutor(this);}
    @Override public void onDisable(){modes.clear();counts.clear();}
    static Vector filtered(Vector impulse,boolean enabled,boolean groundOnly,boolean grounded) {
        return enabled&&(!groundOnly||grounded)?new Vector(0,impulse.getY(),0):impulse.clone();
    }
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void knockback(EntityKnockbackEvent event) {
        if(!(event.getEntity() instanceof Player player))return;
        String mode=modes.get(player.getUniqueId());if(mode==null)return;
        String cause=event.getCause().name();
        if(!cause.equals("ENTITY_ATTACK")&&!cause.equals("DAMAGE")&&!cause.equals("SWEEP_ATTACK"))return;
        boolean ground=player.isOnGround();if(mode.equals("ground")&&!ground)return;
        // Paper 1.21.1's event vector is an impulse added to existing velocity.
        // Zero X/Z removes that impulse, preserving current movement and the native Y impulse.
        event.setKnockback(filtered(event.getKnockback(),true,mode.equals("ground"),ground));
        counts.merge(player.getUniqueId(),1,Integer::sum);
    }
    @Override public boolean onCommand(CommandSender sender,Command command,String label,String[] args) {
        if(!sender.hasPermission("wavedog.kbtest")){sender.sendMessage("只有 OP 可以开启击退测试。");return true;}
        if(args.length<1||args.length>2||!Set.of("ground","all","off","status").contains(args[0].toLowerCase(Locale.ROOT))) {
            sender.sendMessage("/kbtest ground [玩家]：地面水平击退归零；/kbtest all [玩家]：所有状态水平击退归零；/kbtest off [玩家]：恢复。");return true;
        }
        String name=args.length==2?args[1]:sender instanceof Player p?p.getName():"WaveJerry";
        Player target=Bukkit.getPlayerExact(name);
        if(target==null||Set.of("wavedog","wavedog2","pvpbot","pvpbot2").contains(name.toLowerCase(Locale.ROOT))) {sender.sendMessage("请指定在线真实玩家。");return true;}
        String mode=args[0].toLowerCase(Locale.ROOT);var id=target.getUniqueId();
        if(mode.equals("off"))modes.remove(id);else if(!mode.equals("status")){modes.put(id,mode);counts.put(id,0);}
        String result=target.getName()+"：水平击退测试="+modes.getOrDefault(id,"关闭")+"；已拦截="+counts.getOrDefault(id,0)+"。";
        sender.sendMessage(result);if(sender!=target)target.sendMessage(result);
        if(!mode.equals("status"))getLogger().info(result);
        return true;
    }
}

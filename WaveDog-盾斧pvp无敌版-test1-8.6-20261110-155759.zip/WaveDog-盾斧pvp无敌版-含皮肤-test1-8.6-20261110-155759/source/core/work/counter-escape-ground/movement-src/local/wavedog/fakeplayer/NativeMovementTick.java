package local.wavedog.fakeplayer;

import java.lang.reflect.Method;
import java.util.UUID;
import io.github.hello09x.fakeplayer.core.entity.Fakeplayer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.plugin.java.JavaPlugin;

/** Supplies the movement-packet fall bookkeeping missing from fakeplayer's physics tick. */
public final class NativeMovementTick implements Listener {
    private record Access(Method handle, Method fall) {}
    private static final ClassValue<Access> ACCESS = new ClassValue<>() {
        @Override protected Access computeValue(Class<?> craftPlayer) {
            try {
                var handle=craftPlayer.getMethod("getHandle");
                return new Access(handle,handle.getReturnType().getMethod("doCheckFallDamage",
                    double.class,double.class,double.class,boolean.class));
            } catch (ReflectiveOperationException e) {
                throw new IllegalStateException("Native player movement bookkeeping unavailable",e);
            }
        }
    };
    private static boolean registered;
    private static UUID ticking;
    private static boolean teleported;

    public static void tick(Fakeplayer fake) {
        if(!registered) {
            Bukkit.getPluginManager().registerEvents(new NativeMovementTick(),
                JavaPlugin.getProvidingPlugin(NativeMovementTick.class));
            registered=true;
        }
        Player player=fake.getPlayer();
        var access=ACCESS.get(player.getClass());
        var before=player.getLocation();
        ticking=player.getUniqueId();teleported=false;
        try {
            // Exactly the original physics call; no extra tick, velocity or fall-distance setter.
            fake.getHandle().doTick();
            if(teleported||!player.isOnline()||player.isDead()||player.isInsideVehicle()
                    ||!before.getWorld().equals(player.getWorld()))return;
            var after=player.getLocation();
            // ServerPlayer.checkFallDamage is intentionally empty: real players call this
            // method from their movement-packet handler instead. Use actual collision-resolved
            // displacement and the native grounded flag, once after each fakeplayer tick.
            access.fall.invoke(access.handle.invoke(player),after.getX()-before.getX(),
                after.getY()-before.getY(),after.getZ()-before.getZ(),player.isOnGround());
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException("Cannot settle native fakeplayer movement",e);
        } finally { ticking=null; }
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void teleport(PlayerTeleportEvent event) {
        if(event.getPlayer().getUniqueId().equals(ticking))teleported=true;
    }
}

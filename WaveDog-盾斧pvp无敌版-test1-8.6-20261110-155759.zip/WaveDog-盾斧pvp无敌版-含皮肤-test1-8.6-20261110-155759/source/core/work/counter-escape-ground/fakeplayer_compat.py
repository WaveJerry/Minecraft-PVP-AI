"""Strict JAR payload identity; ZIP timestamps/compression are not executable content."""
from pathlib import Path
import hashlib
import zipfile


def payload_sha(path):
    digest = hashlib.sha256()
    with zipfile.ZipFile(path) as archive:
        names = [entry.filename for entry in archive.infolist() if not entry.is_dir()]
        if len(names) != len(set(names)):
            raise ValueError('Duplicate entries in fakeplayer JAR')
        for name in sorted(names):
            encoded = name.encode('utf-8')
            data = archive.read(name)
            digest.update(len(encoded).to_bytes(8, 'big'))
            digest.update(encoded)
            digest.update(len(data).to_bytes(8, 'big'))
            digest.update(hashlib.sha256(data).digest())
    return digest.hexdigest()


def compatible(installed, packaged, movement):
    installed = Path(installed)
    file_sha = hashlib.sha256(installed.read_bytes()).hexdigest()
    if file_sha in (movement['base_sha256'], movement['jar_sha256']):
        return True
    actual = payload_sha(installed)
    # The packaged JAR was checked separately before reaching this gate.
    return actual == payload_sha(packaged) or actual == movement.get('base_payload_sha256')

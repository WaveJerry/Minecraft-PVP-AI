import java.nio.file.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** Change only the private subsequent-tick body; spawning and input scheduling stay original. */
public final class PatchFakeplayerMovement {
    public static void main(String[] args)throws Exception {
        var n=new ClassNode();new ClassReader(Files.readAllBytes(Path.of(args[0]))).accept(n,0);
        int changed=0;
        for(var m:n.methods)if(m.name.equals("doTick")&&m.desc.equals("()V")) {
            long calls=java.util.Arrays.stream(m.instructions.toArray())
                .filter(i->i instanceof MethodInsnNode c&&c.name.equals("doTick")
                    &&c.owner.equals("io/github/hello09x/fakeplayer/api/spi/NMSServerPlayer")).count();
            if(calls!=1)throw new IllegalStateException("Unsupported fakeplayer physics ticker");
            m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();
            m.instructions.add(new VarInsnNode(Opcodes.ALOAD,0));
            m.instructions.add(new FieldInsnNode(Opcodes.GETFIELD,n.name,"player","Lio/github/hello09x/fakeplayer/core/entity/Fakeplayer;"));
            m.instructions.add(new MethodInsnNode(Opcodes.INVOKESTATIC,"local/wavedog/fakeplayer/NativeMovementTick","tick","(Lio/github/hello09x/fakeplayer/core/entity/Fakeplayer;)V",false));
            m.instructions.add(new InsnNode(Opcodes.RETURN));changed++;
        }
        if(changed!=1)throw new IllegalStateException("Missing exact physics tick");
        var w=new ClassWriter(ClassWriter.COMPUTE_MAXS);n.accept(w);Files.write(Path.of(args[1]),w.toByteArray());
        System.out.println("PASS fakeplayer: one original physics tick plus native movement/fall bookkeeping");
    }
}

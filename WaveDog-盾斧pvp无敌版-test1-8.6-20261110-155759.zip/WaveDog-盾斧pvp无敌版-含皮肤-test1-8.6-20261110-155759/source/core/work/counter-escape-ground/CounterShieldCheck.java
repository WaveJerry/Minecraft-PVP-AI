import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;

/** Focused regression checks against the built jar; no server or model writes. */
public final class CounterShieldCheck {
    static int checks, shieldCases, flightFrames;
    static RestartCheck.Archive archive;

    static void check(boolean ok, String reason) {
        checks++;
        if (!ok) throw new AssertionError(reason);
    }

    static Object call(Object receiver, String name, Class<?>[] types, Object... args) throws Exception {
        Method method = receiver.getClass().getDeclaredMethod(name, types);
        method.setAccessible(true);
        return method.invoke(receiver, args);
    }

    static Object field(Object receiver, String name) throws Exception {
        Field field = receiver.getClass().getDeclaredField(name);
        field.setAccessible(true);
        return field.get(receiver);
    }

    static void field(Object receiver, String name, Object value) throws Exception {
        Field field = receiver.getClass().getDeclaredField(name);
        field.setAccessible(true);
        field.set(receiver, field.getType().isEnum()
            ? RestartCheck.enumValue(field.getType(), (String) value) : value);
    }

    static boolean flag(Object receiver, String name) throws Exception {
        return (boolean) call(receiver, name, new Class<?>[] {});
    }

    static Object decision(RestartCheck.Controller controller) throws Exception {
        return field(controller.controller, "decision");
    }

    static Object body(double x, double y, double vx, double vy, boolean grounded) throws Exception {
        return archive.make("AirborneEnvelope$Body", new Class<?>[] {
            double.class, double.class, double.class, double.class, double.class,
            double.class, double.class, double.class, double.class, double.class, boolean.class
        }, x, y, 0., vx, vy, 0., 1.62, .3, .3, 1.8, grounded);
    }

    /** Invoke the production predictor rather than fabricate a danger record. */
    static Object threat(double x, double vx, double vy) throws Exception {
        Class<?> body = archive.type("AirborneEnvelope$Body");
        Method forecast = archive.type("AirborneEnvelope").getDeclaredMethod("forecast",
            body, body, double.class, double.class, boolean.class, boolean.class,
            double.class, double.class);
        forecast.setAccessible(true);
        Object result = forecast.invoke(null, body(0, 0, 0, 0, true),
            body(x, .6, vx, vy, false), 0., .02548, true, true, 1., 1.);
        check(flag(result, "valid") && flag(result, "threat"), "fixture must be a real possible melee threat");
        return result;
    }

    static Object rising(boolean feasible, int ticks) throws Exception {
        return archive.make("RisingIntercept$Plan",
            new Class<?>[] {boolean.class, int.class, double.class, double.class},
            feasible, ticks, 2.6, 4.);
    }

    static Object jumpPlan() throws Exception {
        return archive.make("JumpThreatSpacing$Plan", new Class<?>[] {
            boolean.class, int.class, double.class, double.class, double.class,
            boolean.class, boolean.class
        }, true, 2, 3.4, -1., 0., true, true);
    }

    static Object projectile() throws Exception {
        boolean[] safe = new boolean[18], viable = new boolean[18];
        Arrays.fill(viable, true);
        safe[4] = true;
        return archive.make("ArrowDodgePlanner$Result", new Class<?>[] {
            boolean.class, double.class, double.class, int.class, boolean[].class,
            boolean[].class, boolean.class, boolean.class, int.class
        }, true, 2., 0., 4, safe, viable, false, true, 7);
    }

    static Map<String, Object> airSenses(double distance, double vertical, Object envelope) throws Exception {
        Map<String, Object> senses = RestartCheck.senses(distance);
        senses.put("targetAirborne", true);
        senses.put("targetCritThreat", true);
        senses.put("targetCriticalPossible", true);
        senses.put("targetY", vertical);
        senses.put("targetCritEta", 5.);
        senses.put("targetKnockbackAge", 1000.);
        senses.put("airEnvelope", envelope);
        senses.put("risingPlan", rising(true, 0));
        senses.put("jumpSpace", jumpPlan());
        senses.put("retreatJumpEligible", true);
        return senses;
    }

    static void requireShield(RestartCheck.Controller controller, String context) throws Exception {
        Object frame = decision(controller);
        check(Set.of("AIR_CONTROL","ARROW_GUARD").contains(controller.phase()), context + ": wrong phase " + controller.phase());
        check(flag(frame, "shield"), context + ": usable shield was not requested");
        for (String input : List.of("attack", "jump", "sprint", "faceAway"))
            check(!flag(frame, input), context + ": forbidden " + input + " in " + frame);
        check(((long) field(controller.controller, "orbitUntil")) == 0,
            context + ": previous orbit must be cancelled");
        shieldCases++;
    }

    static void configureMode(RestartCheck.Controller controller, Map<String, Object> senses,
                              String mode, long tick) throws Exception {
        switch (mode) {
            case "ORBIT" -> {
                field(controller.controller, "phase", "ORBIT_BURST");
                field(controller.controller, "orbitUntil", tick + 10);
                senses.put("damageAge", .5);
            }
            case "COMBO" -> senses.put("comboPursuit", true);
            case "WITHDRAW" -> senses.put("withdrawing", true);
            case "POST_EXIT" -> field(controller.controller, "exitControl", true);
            case "SETTLING" -> senses.put("guardSettling", true);
            case "NORMAL" -> { }
            default -> throw new AssertionError(mode);
        }
    }

    static void shieldMatrix() throws Exception {
        String[] opportunities = {"NONE", "ENTRY", "RISE_INTERRUPT", "ORBIT_TRADE", "ORBIT_BACK",
            "BREAK_COUNTER", "COUNTER_FOLLOW", "EXIT", "SHIELD_START", "RECOVERY_BREAK"};
        String[] modes = {"NORMAL", "ORBIT", "COMBO", "WITHDRAW", "POST_EXIT", "SETTLING"};
        double[] verticals = {.25, 0., -.25};
        Object[] threats = new Object[verticals.length];
        for (int i = 0; i < verticals.length; i++) threats[i] = threat(2.9, -.05, verticals[i]);
        for (int profile = 0; profile < 2; profile++)
            for (boolean blocking : new boolean[] {false, true})
                for (int direction = 0; direction < verticals.length; direction++)
                    for (float charge : new float[] {0f, .1f, 1f})
                        for (String opportunity : opportunities)
                            for (String mode : modes)
                                for (int weapon : new int[] {0, 1}) {
                                    long tick = 100;
                                    var controller = new RestartCheck.Controller(archive, profile, 7831);
                                    var senses = airSenses(2.6, verticals[direction], threats[direction]);
                                    var view = RestartCheck.view(tick, 2.6, true);
                                    view.put("ownAttackCharge", charge);
                                    senses.put("blocking", blocking);
                                    senses.put("holdingShield", true);
                                    senses.put("ownShieldWarmup", blocking ? 0. : 5.);
                                    senses.put("ownWeapon", weapon);
                                    senses.put("escapeSword", weapon == 1);
                                    senses.put("ownCriticalReady", true);
                                    senses.put("opportunity", opportunity);
                                    senses.put("orbitWoundPending", opportunity.equals("ORBIT_TRADE"));
                                    senses.put("orbitBackPending", opportunity.equals("ORBIT_BACK"));
                                    senses.put("targetFacingDot", -.2);
                                    // Deliberately inconsistent old opportunity hint: the actual envelope wins.
                                    senses.put("targetCriticalPossible", false);
                                    if (opportunity.equals("BREAK_COUNTER")) {
                                        senses.put("lastBlockTick", tick);
                                        senses.put("blockedMeleeAge", 0.);
                                    }
                                    configureMode(controller, senses, mode, tick);
                                    String result = controller.step(view, senses);
                                    String context = "profile=" + profile + " raised=" + blocking + " y="
                                        + verticals[direction] + " charge=" + charge + " opportunity="
                                        + opportunity + " mode=" + mode + " weapon=" + weapon + " " + result;
                                    requireShield(controller, context);
                                    check(call(decision(controller), "weapon", new Class<?>[] {}).toString()
                                        .equals(weapon == 1 ? "SWORD" : "AXE"),
                                        context + ": shield guard must retain the current melee weapon");
                                }

        // Null, failed and delayed intercept forecasts cannot override an available shield.
        // A simultaneous arrow dodge previously preceded airborne shield arbitration.
        for (int profile = 0; profile < 2; profile++)
            for (boolean blocking : new boolean[] {false, true})
                for (int plan = 0; plan < 4; plan++)
                    for (boolean arrow : new boolean[] {false, true}) {
                        var controller = new RestartCheck.Controller(archive, profile, 7832);
                        var senses = airSenses(3.5, .25, threat(3.8, -.25, .25));
                        senses.put("blocking", blocking);
                        senses.put("risingPlan", plan == 0 ? null : rising(plan != 3, plan == 2 ? 2 : 0));
                        if (arrow) senses.put("projectilePlan", projectile());
                        controller.step(RestartCheck.view(200, 3.5, true), senses);
                        requireShield(controller, "shield during plan=" + plan + " arrow=" + arrow + " profile=" + profile);
                    }
    }

    static void brokenShieldCounter() throws Exception {
        for (int profile = 0; profile < 2; profile++)
            for (float charge : new float[] {.1f, 1f})
                for (boolean ownCritical : new boolean[] {false, true}) {
                    var controller = new RestartCheck.Controller(archive, profile, 7833);
                    var senses = airSenses(2.6, .25, threat(2.9, -.05, .25));
                    var view = RestartCheck.view(300, 2.6, false);
                    view.put("ownAttackCharge", charge);
                    senses.put("ownShieldCooldown", 80.);
                    senses.put("opportunity", "BREAK_COUNTER");
                    senses.put("ownCriticalReady", ownCritical);
                    String result = controller.step(view, senses);
                    Object frame = decision(controller);
                    check(controller.phase().equals("COUNTER"), "rising threat must not steal broken-shield counter: " + result);
                    check(flag(frame, "attack") && flag(frame, "sprint"), "counter must submit sprint knockback input: " + result);
                    check(!flag(frame, "jump") && !flag(frame, "shield"), "counter must not jump or request disabled shield: " + result);
                    check(call(frame, "technique", new Class<?>[] {}).toString().equals("AXE_READY"),
                        "counter must never convert to FALL_CRIT: " + result);
                }
    }

    static void requireFlight(RestartCheck.Controller controller, boolean expectedJump, String context) throws Exception {
        Object frame = decision(controller);
        check(controller.phase().equals("ESCAPE"), context + ": critical prediction interrupted retreat: " + controller.phase());
        check(flag(frame, "sprint") && flag(frame, "faceAway"), context + ": full sprint retreat input lost");
        check(flag(frame, "jump") == expectedJump, context + ": expected jump=" + expectedJump + " in " + frame);
        check(!flag(frame, "attack") && !flag(frame, "shield"), context + ": retreat unexpectedly attacks or raises disabled shield");
        flightFrames++;
    }

    static void disabledDefense() throws Exception {
        for (int profile = 0; profile < 2; profile++) {
            var interrupt = new RestartCheck.Controller(archive, profile, 7835);
            var rising = airSenses(2.6, .25, threat(2.9, -.05, .25));
            rising.put("ownShieldCooldown", 80.);
            rising.put("opportunity", "ENTRY");
            var view = RestartCheck.view(350, 2.6, false);
            view.put("ownAttackCharge", .1f);
            String contact = interrupt.step(view, rising);
            check(interrupt.phase().equals("AIR_INTERRUPT") && flag(decision(interrupt), "attack"),
                "ordinary shield-disabled legal rise interrupt must remain available: " + contact);
            check(!flag(decision(interrupt), "shield") && !flag(decision(interrupt), "jump"),
                "ordinary interrupt must not request a disabled shield or punishment jump");

            var evade = new RestartCheck.Controller(archive, profile, 7836);
            var falling = airSenses(3.5, -.15, threat(3.8, -.25, -.15));
            falling.put("ownShieldCooldown", 80.);
            String dodge = evade.step(RestartCheck.view(351, 3.5, false), falling);
            check(evade.phase().equals("AIR_DODGE") && !flag(decision(evade), "attack"),
                "shield-disabled falling threat must retain a safe physical dodge: " + dodge);
            check(!flag(decision(evade), "jump") && !flag(decision(evade), "shield"),
                "falling threat must not start a punishment jump: " + dodge);
        }
    }

    static void counterFlightAndLaterEmergency() throws Exception {
        Object risingThreat = threat(3.8, -.25, .25);
        Object fallingThreat = threat(3.8, -.25, -.15);
        Object closeRisingThreat = threat(2.9, -.05, .25);
        for (int profile = 0; profile < 2; profile++) {
            var controller = new RestartCheck.Controller(archive, profile, 7834);
            long counterAt = 400;
            call(controller.controller, "confirmedCounterHop", new Class<?>[] {long.class}, counterAt);
            check(flag(controller.controller, "counterHopActive"), "confirmed hit must arm one flight");
            for (int offset = 1; offset <= 12; offset++) {
                boolean rising = offset % 2 == 1;
                boolean legalRisingContact = offset == 1 || offset == 5;
                double distance = legalRisingContact ? 2.6 : 3.5;
                var senses = airSenses(distance, rising ? .25 : -.15,
                    legalRisingContact ? closeRisingThreat : rising ? risingThreat : fallingThreat);
                senses.put("counterAxeHitTick", counterAt);
                senses.put("ownShieldCooldown", 80.);
                senses.put("withdrawing", true);
                senses.put("onGround", offset <= 2);
                var view = RestartCheck.view(counterAt + offset, distance, false);
                view.put("ownAttackCharge", legalRisingContact ? 1f : .1f);
                controller.step(view, senses);
                requireFlight(controller, offset == 1, "profile=" + profile + " flight offset=" + offset);
                if (offset == 1) {
                    check((boolean) call(controller.controller, "allowJumpInput", new Class<?>[] {long.class}, counterAt),
                        "first confirmed escape jump must pass the execution guard");
                    call(controller.controller, "jumpInputSubmitted", new Class<?>[] {long.class}, counterAt + offset);
                }
                check(!(boolean) call(controller.controller, "allowJumpInput", new Class<?>[] {long.class}, counterAt),
                    "a submitted flight must never permit a second jump input");
                check(flag(controller.controller, "counterHopActive"), "flight must remain active until actual landing");
            }

            var ground = RestartCheck.senses(3.5);
            ground.put("counterAxeHitTick", counterAt);
            ground.put("ownShieldCooldown", 80.);
            ground.put("withdrawing", true);
            ground.put("retreatJumpEligible", true);
            ground.put("jumpSpace", jumpPlan()); // A stale jumping plan must not revive ordinary hopping.
            String landing = controller.step(RestartCheck.view(413, 3.5, false), ground);
            check(!flag(controller.controller, "counterHopActive"), "landing must end the confirmed flight");
            check(flag(controller.controller, "needsAxeSwitch") && flag(controller.controller, "pressureRecovering"),
                "separated landing must request axe and wait for its real charge");
            check(controller.phase().equals("PRESSURE_RECHARGE"), "landing must recharge the switched axe: " + landing);
            check(!flag(decision(controller), "jump"), "landing must stop ordinary retreat hopping: " + landing);
            call(controller.controller,"axeEquipped",new Class<?>[]{long.class},413L);
            check(!(boolean) call(controller.controller, "allowJumpInput", new Class<?>[] {long.class}, counterAt),
                "ordinary post-exit execution must reject a new retreat jump");

            // A later real rising crisis can use one independent dodge; it has no new counter hit.
            var crisis = airSenses(3.5, .25, risingThreat);
            crisis.put("counterAxeHitTick", counterAt);
            crisis.put("ownShieldCooldown", 80.);
            crisis.put("risingPlan", rising(false, 0));
            String dodge = controller.step(RestartCheck.view(414, 3.5, false), crisis);
            check(controller.phase().equals("AIR_DODGE"), "later real crisis must choose a physical dodge: " + dodge);
            check(flag(decision(controller), "jump") && flag(decision(controller), "sprint"),
                "completed counter flight must not suppress later emergency dodge: " + dodge);
            check((boolean) call(controller.controller, "allowJumpInput", new Class<?>[] {long.class}, counterAt),
                "later emergency dodge must pass the actual jump-input guard");
            check(!flag(decision(controller), "attack"), "out-of-reach crisis must not fabricate a hit");

            controller.step(RestartCheck.view(415, 3.5, false), ground);
            check(!flag(decision(controller), "jump"), "emergency permission must clear on the next normal ground decision");
            check(!(boolean) call(controller.controller, "allowJumpInput", new Class<?>[] {long.class}, counterAt),
                "emergency jump permission must not leak into ordinary ground control");

            call(controller.controller, "confirmedCounterHop", new Class<?>[] {long.class}, 416L);
            var renewed = RestartCheck.senses(3.5);
            renewed.put("counterAxeHitTick", 416L);
            renewed.put("ownShieldCooldown", 80.);
            renewed.put("withdrawing", true);
            renewed.put("retreatJumpEligible", true);
            controller.step(RestartCheck.view(417, 3.5, false), renewed);
            requireFlight(controller, true, "new confirmed counter must rearm exactly one flight");
            call(controller.controller, "jumpInputSubmitted", new Class<?>[] {long.class}, 417L);
            check(!(boolean) call(controller.controller, "allowJumpInput", new Class<?>[] {long.class}, 416L),
                "renewed confirmed flight must also consume its sole jump");
        }
    }

    static void closeLandingAndLaterEmergency() throws Exception {
        Object risingThreat = threat(3.8, -.25, .25);
        for (int profile = 0; profile < 2; profile++)
            for (double[] reaches : new double[][] {{2.6, 2.8}, {2.8, 2.6}}) {
                var controller = new RestartCheck.Controller(archive, profile, 7837);
                long counterAt = 500;
                call(controller.controller, "confirmedCounterHop", new Class<?>[] {long.class}, counterAt);
                var escape = RestartCheck.senses(3.5);
                escape.put("counterAxeHitTick", counterAt);
                escape.put("ownShieldCooldown", 80.);
                escape.put("withdrawing", true);
                escape.put("retreatJumpEligible", true);
                var view = RestartCheck.view(501, 3.5, false);
                view.put("ownAttackCharge", .1f);
                controller.step(view, escape);
                requireFlight(controller, true, "close-landing fixture first jump");
                call(controller.controller, "jumpInputSubmitted", new Class<?>[] {long.class}, 501L);
                escape.put("onGround", false);
                view.put("tick", 502L);
                controller.step(view, escape);
                requireFlight(controller, false, "close-landing fixture airborne observation");

                var ground = RestartCheck.senses(reaches[0]);
                ground.put("targetReachDistance", reaches[1]);
                ground.put("counterAxeHitTick", counterAt);
                ground.put("ownShieldCooldown", 80.);
                ground.put("withdrawing", true);
                ground.put("retreatJumpEligible", true);
                ground.put("jumpSpace", jumpPlan());
                var landedView = RestartCheck.view(503, reaches[0], false);
                landedView.put("ownAttackCharge", .1f);
                String landing = controller.step(landedView, ground);
                String context = "profile=" + profile + " close landing own=" + reaches[0]
                    + " target=" + reaches[1] + " " + landing;
                check(!flag(controller.controller, "counterHopActive"), context + ": actual landing must finish the sole flight");
                check(flag(controller.controller, "controlAfterExit"), context + ": proximity must not restart flight");
                check(controller.phase().equals("RANGE_CONTROL"), context + ": landing must use ground spacing");
                check(!flag(decision(controller), "jump") && !flag(decision(controller), "faceAway")
                    && !flag(decision(controller), "attack"), context + ": no second hop, retreat or low-charge attack");
                check(!(boolean) field(controller.controller, "counterFlight")
                    && !(boolean) field(controller.controller, "escapeObserved"), context + ": stale escape state must clear");
                check(!(boolean) call(controller.controller, "allowJumpInput", new Class<?>[] {long.class}, counterAt),
                    context + ": native input must reject an ordinary second jump");

                var crisis = airSenses(3.5, .25, risingThreat);
                crisis.put("counterAxeHitTick", counterAt);
                crisis.put("ownShieldCooldown", 80.);
                crisis.put("risingPlan", rising(false, 0));
                String dodge = controller.step(RestartCheck.view(504, 3.5, false), crisis);
                check(controller.phase().equals("AIR_DODGE") && flag(decision(controller), "jump")
                    && flag(decision(controller), "sprint"), context + ": later real emergency must still jump: " + dodge);
                check((boolean) call(controller.controller, "allowJumpInput", new Class<?>[] {long.class}, counterAt),
                    context + ": later emergency must pass native jump guard without a new counter");
                check(!flag(decision(controller), "attack"), context + ": emergency cannot fabricate out-of-range damage");

                landedView.put("tick", 505L);
                controller.step(landedView, ground);
                check(!flag(decision(controller), "jump") && !flag(decision(controller), "attack"),
                    context + ": emergency permission cannot leak into ordinary close ground control");
                check(!(boolean) call(controller.controller, "allowJumpInput", new Class<?>[] {long.class}, counterAt),
                    context + ": ordinary native jump guard must close again");
            }
    }

    public static void main(String[] args) throws Exception {
        Path jar = args.length == 0 ? Path.of("work/counter-escape-ground/PvPArenaAI.jar") : Path.of(args[0]);
        archive = new RestartCheck.Archive(jar, null);
        shieldMatrix();
        brokenShieldCounter();
        disabledDefense();
        counterFlightAndLaterEmergency();
        closeLandingAndLaterEmergency();
        System.out.println("PASS: " + checks + " assertions; " + shieldCases
            + " shield-available cases across both profiles, raised/unraised, rise/apex/fall, charges, opportunities and states; "
            + flightFrames + " confirmed-flight frames; broken-shield sprint counter, one jump, separated/close landing ground spacing and later emergency dodge");
    }
}

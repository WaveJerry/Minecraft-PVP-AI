import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;

/** Packaged decisions: exchange timing, shield-pressure overlay and short legal advances. */
public final class TradeMechanicsCheck {
    static RestartCheck.Archive archive;static int checks;
    static void check(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}
    static Object call(Object o,String name,Class<?>[] types,Object...args)throws Exception {
        var m=o.getClass().getDeclaredMethod(name,types);m.setAccessible(true);return m.invoke(o,args);
    }
    static void set(Object o,String name,Object v)throws Exception {var f=o.getClass().getDeclaredField(name);f.setAccessible(true);f.set(o,v);}
    static Object get(Object o,String name)throws Exception {var f=o.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(o);}
    static boolean flag(Object o,String n)throws Exception{return (boolean)call(o,n,new Class<?>[]{});}
    static Object frame(RestartCheck.Controller c)throws Exception{return get(c.controller,"decision");}
    static Object plan()throws Exception {return archive.make("TradeJump$Plan",new Class<?>[]{double.class,double.class,int.class,double.class,boolean.class},-1.,0.,11,3.4,true);}
    static void observe(RestartCheck.Controller c,Object plan,long crit,boolean last,boolean shield)throws Exception {
        call(c.controller,"tradeObservation",new Class<?>[]{archive.type("TradeJump$Plan"),long.class,boolean.class,boolean.class},plan,crit,last,shield);
        call(c.controller,"hopCriticalObservation",new Class<?>[]{float.class,double.class},.95f,-.1);
    }
    static Map<String,Object> air(double reach,boolean ownGround) {
        var s=RestartCheck.senses(reach);s.put("onGround",ownGround);s.put("ownWeapon",0);
        s.put("ownShieldCooldown",80.);s.put("targetAirborne",true);s.put("targetY",.25);
        s.put("targetCritThreat",true);s.put("targetCriticalPossible",true);s.put("retreatBlocked",true);
        s.put("targetCritEta",5.);s.put("withdrawing",true);s.put("ownCriticalWindow",!ownGround);
        return s;
    }
    static RestartCheck.Controller exchangeStart(int profile)throws Exception {
        var c=new RestartCheck.Controller(archive,profile,991);set(c.controller,"exitControl",true);set(c.controller,"landingTradePending",true);
        observe(c,plan(),-1000,false,false);
        c.step(RestartCheck.view(100,2.8,false),air(2.8,true));
        check(c.phase().equals("AIR_DODGE")&&flag(frame(c),"jump"),"post-escape blocked route may choose one preplanned exchange jump");
        check(call(frame(c),"weapon",new Class<?>[]{}).toString().equals("AXE"),"exchange prepares axe before takeoff");
        call(c.controller,"jumpInputSubmitted",new Class<?>[]{long.class},100L);return c;
    }
    static void exchanges(int profile)throws Exception {
        for(boolean blocked:new boolean[]{false,true})for(boolean incoming:new boolean[]{false,true}) {
            var c=exchangeStart(profile);var s=air(2.8,false);s.put("targetY",-.1);s.put("ownY",-.1);
            observe(c,null,-1000,false,false);
            s.put("ownCriticalWindow",false);c.step(RestartCheck.view(105,2.8,false),s);s.put("ownCriticalWindow",true);
            check(c.phase().equals("AIR_DODGE")&&!flag(frame(c),"attack")&&!flag(frame(c),"jump"),"ascending/invalid native window preserves charge and never repeats the jump");
            observe(c,null,incoming?106:-1000,!incoming,blocked);
            call(c.controller,"opponentAttack",new Class<?>[]{long.class,boolean.class},106L,true);
            s.put("targetShieldRaised",blocked);s.put("targetFacingDot",blocked?1.:0.);
            var view=RestartCheck.view(106,2.8,false);view.put("targetBlocking",blocked);
            c.step(view,s);
            check(flag(frame(c),"attack")==!blocked,"real incoming critical or final native window attacks only an exposed target");
            if(!blocked) {
                check(c.phase().equals("TRADE_CRIT")&&!flag(frame(c),"sprint"),"exchange attack cancels sprint for a native falling axe critical");
                call(c.controller,"beforeMelee",new Class<?>[]{double.class},10.);
                call(c.controller,"nativeMeleeOutcome",new Class<?>[]{boolean.class,boolean.class},true,true);
                call(c.controller,"meleeAttemptFinished",new Class<?>[]{long.class,double.class,boolean.class},106L,13.,false);
                check(flag(c.controller,"controlAfterExit")&&get(c.controller,"activeTrade")==null,"confirmed native critical immediately ends in control");
                check(flag(c.controller,"exchangeMotion"),"same-call movement restoration remains pending after the attack");
                call(c.controller,"frameRestored",new Class<?>[]{});
                var ground=RestartCheck.senses(4.);ground.put("ownWeapon",0);ground.put("ownShieldCooldown",80.);
                c.step(RestartCheck.view(107,4,false),ground);
                check(!flag(frame(c),"jump")&&!flag(frame(c),"faceAway"),"completed exchange never queues another retreat hop");
            }
        }
        var outside=exchangeStart(profile);observe(outside,null,102,true,false);
        var s=air(3.01,false);s.put("targetY",-.1);outside.step(RestartCheck.view(102,3.01,false),s);
        check(!flag(frame(outside),"attack"),"confirmed enemy critical cannot authorize an out-of-reach revenge hit");
        call(outside.controller,"reset",new Class<?>[]{});
        check(!flag(outside.controller,"exchangeMotion"),"target/death/reset clears exchange state");
        var warming=exchangeStart(profile);var warm=air(2.8,false);warm.put("targetShieldRaised",true);
        warm.put("targetFacingDot",1.);observe(warming,null,-1000,true,false);
        call(warming.controller,"opponentAttack",new Class<?>[]{long.class,boolean.class},111L,true);
        var wv=RestartCheck.view(111,2.8,false);wv.put("targetBlocking",false);warming.step(wv,warm);
        check(warming.phase().equals("TRADE_CRIT")&&flag(frame(warming),"attack"),"raised hand before the real shield delay is not an effective shield and cannot veto the final exchange");
    }
    static void planner()throws Exception {
        Class<?> body=archive.type("AirborneEnvelope$Body"),clear=archive.type("TradeJump$Clear");
        var ctor=new Class<?>[]{double.class,double.class,double.class,double.class,double.class,double.class,double.class,double.class,double.class,double.class,boolean.class};
        Object own=archive.make("AirborneEnvelope$Body",ctor,0.,0.,0.,0.,0.,0.,1.62,.3,.3,1.8,true);
        Object target=archive.make("AirborneEnvelope$Body",ctor,2.7,.4,0.,-.1,.25,0.,1.62,.3,.3,1.8,false);
        var method=archive.type("TradeJump").getDeclaredMethod("plan",body,body,double.class,double.class,double.class,double.class,clear);method.setAccessible(true);
        int[] probes={0};Object open=Proxy.newProxyInstance(archive,new Class<?>[]{clear},(p,m,a)->{probes[0]++;return true;});
        Object result=method.invoke(null,own,target,-8.,8.,-8.,8.,open);
        check(result!=null&&probes[0]>20,"real route planner sweeps a complete ordinary jump, rather than only choosing the arena center");
        check(Math.abs(Math.hypot((double)call(result,"x",new Class<?>[]{}),(double)call(result,"z",new Class<?>[]{}))-1)<1e-9,"planner returns a unit native input heading, not a speed multiplier");
        Object shut=Proxy.newProxyInstance(archive,new Class<?>[]{clear},(p,m,a)->false);
        check(method.invoke(null,own,target,-8.,8.,-8.,8.,shut)==null,"colliding jump paths cannot be authorized");
        Object falling=archive.make("AirborneEnvelope$Body",ctor,2.7,.4,0.,-.1,-.25,0.,1.62,.3,.3,1.8,false);
        check(method.invoke(null,own,falling,-8.,8.,-8.,8.,open)==null,"planner cannot manufacture synchronized takeoff after the opponent is already falling");
    }
    static void shieldPressure(int profile)throws Exception {
        var c=new RestartCheck.Controller(archive,profile,22);set(c.controller,"exitControl",true);
        for(int i=0;i<4;i++) {
            var s=RestartCheck.senses(2.8);s.put("ownWeapon",0);s.put("ownShieldCooldown",80.);
            s.put("targetShieldRaised",true);s.put("targetFacingDot",1.);
            var v=RestartCheck.view(200+i,2.8,false);v.put("ownAttackCharge",.1f);v.put("targetBlocking",true);
            observe(c,null,-1000,false,true);c.step(v,s);
            check(c.phase().equals("SHIELD_PRESS")&&flag(frame(c),"attack"),"every live legal grounded shield-contact tick can submit a normal axe click without full charge");
            check(call(frame(c),"weapon",new Class<?>[]{}).toString().equals("AXE")&&!flag(frame(c),"jump"),"shield clicks retain current axe and do not create a jump sequence");
        }
        var lowered=RestartCheck.senses(3.5);lowered.put("ownShieldCooldown",80.);
        observe(c,null,-1000,false,false);c.step(RestartCheck.view(205,3.5,false),lowered);
        check(!c.phase().equals("SHIELD_PRESS"),"lowered shield/outside live reach ends pressure immediately");
        var rising=air(2.8,true);rising.put("targetShieldRaised",true);rising.put("targetFacingDot",1.);
        observe(c,null,-1000,false,true);c.step(RestartCheck.view(206,2.8,false),rising);
        check(!c.phase().equals("SHIELD_PRESS"),"enemy takeoff disables axe spam before the jump-defense branch needs that charge");
    }
    static void advances(int profile)throws Exception {
        for(boolean shield:new boolean[]{false,true}) {
            boolean exercised=false;
            for(long seed=0;seed<100&&!exercised;seed++) {
                var c=new RestartCheck.Controller(archive,profile,seed*104729L);
                call(c.controller,"shortAdvanceAvailable",new Class<?>[]{boolean.class},true);
                call(c.controller,"shortAdvanceTiming",new Class<?>[]{int.class,int.class},3,5);
                var s=RestartCheck.senses(3.2);s.put("ownWeapon",0);s.put("ownShieldCooldown",shield?0.:80.);
                c.step(RestartCheck.view(300,3.2,shield),s);
                if(!c.phase().equals("ACTIVE_ADVANCE"))continue;
                exercised=true;check(!flag(frame(c),"attack")&&flag(frame(c),"sprint"),"outer 0.3-block window advances with native sprint input and no remote hit");
                s=RestartCheck.senses(2.99);s.put("ownWeapon",0);s.put("ownShieldCooldown",shield?0.:80.);
                c.step(RestartCheck.view(301,2.99,shield),s);
                check(c.phase().equals("ACTIVE_STRIKE")&&flag(frame(c),"attack")&&flag(frame(c),"sprint"),"new live legal reach permits the short sprint-knockback axe attack");
                var blocked=RestartCheck.senses(2.99);blocked.put("targetShieldRaised",true);blocked.put("targetFacingDot",1.);
                var view=RestartCheck.view(302,2.99,shield);view.put("targetBlocking",true);
                observe(c,null,-1000,false,true);c.step(view,blocked);
                check(!c.phase().equals("ACTIVE_STRIKE"),"proactive sequence aborts when an effective front shield appears");
            }
            check(exercised,"both shielded and shieldless control support occasional short advances");
        }
        var timed=new RestartCheck.Controller(archive,profile,6);
        call(timed.controller,"confirmedCounterHop",new Class<?>[]{long.class},400L);
        var s=RestartCheck.senses(2.9);s.put("ownWeapon",1);s.put("ownShieldCooldown",80.);s.put("counterAxeHitTick",400L);
        s.put("opportunity","COUNTER_FOLLOW");s.put("onGround",false);
        var v=RestartCheck.view(410,2.9,false);v.put("ownAttackCharge",.1f);timed.step(v,s);
        check(!flag(frame(timed),"attack")&&!timed.phase().equals("COUNTER_EXIT"),"retired fixed-time follow hint cannot produce a normal follow-up swing");
    }
    public static void main(String[] args)throws Exception {
        archive=new RestartCheck.Archive(Path.of(args[0]),null);
        planner();
        for(int p=0;p<2;p++){exchanges(p);shieldPressure(p);advances(p);}
        System.out.println("TradeMechanicsCheck: "+checks+" passed; both profiles, one axe exchange jump, early descending/confirmed-critical timing, effective shield veto, immediate control, per-tick interruptible shield clicks, short legal advances and no timed follow. No server/model writes.");
    }
}

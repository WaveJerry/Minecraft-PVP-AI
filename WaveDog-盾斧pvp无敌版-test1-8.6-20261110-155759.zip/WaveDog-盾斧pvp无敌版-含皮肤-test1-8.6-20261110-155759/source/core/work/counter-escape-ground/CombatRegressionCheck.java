import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;

/** Reproductions of reported state-machine failures, executed in the packaged policies. */
public final class CombatRegressionCheck {
    static RestartCheck.Archive a;static int checks;
    static void check(boolean x,String why){checks++;if(!x)throw new AssertionError(why);}
    static Object call(Object o,String n,Class<?>[] t,Object...v)throws Exception {
        var m=o.getClass().getDeclaredMethod(n,t);m.setAccessible(true);return m.invoke(o,v);
    }
    static void set(Object o,String n,Object v)throws Exception {var f=o.getClass().getDeclaredField(n);f.setAccessible(true);f.set(o,v);}
    static Object get(Object o,String n)throws Exception {var f=o.getClass().getDeclaredField(n);f.setAccessible(true);return f.get(o);}
    static boolean flag(Object o,String n)throws Exception{return (boolean)call(o,n,new Class<?>[]{});}
    static Object frame(RestartCheck.Controller c)throws Exception{return get(c.controller,"decision");}
    static void observe(RestartCheck.Controller c,boolean enabled,boolean blocked,int immunity)throws Exception {
        call(c.controller,"combatObservation",new Class<?>[]{boolean.class,int.class,int.class},true,immunity,20);
        call(c.controller,"tradeObservation",new Class<?>[]{a.type("TradeJump$Plan"),long.class,boolean.class,boolean.class},null,-1000L,false,blocked);
    }
    static Map<String,Object> shield(double reach,boolean ownShield) {
        var s=RestartCheck.senses(reach);s.put("ownShieldCooldown",ownShield?0.:80.);
        s.put("targetShieldRaised",true);s.put("targetShieldDisabled",false);return s;
    }
    static Map<String,Object> view(long tick,double reach,boolean shield,float charge,boolean block) {
        var v=RestartCheck.view(tick,reach,shield);v.put("ownAttackCharge",charge);v.put("targetBlocking",block);return v;
    }
    static void hopRegression(int p)throws Exception {
        HopWeaponCheck.archive=a;
        var c=HopWeaponCheck.start(p);
        var s=HopWeaponCheck.senses(2.98,false,.2,false);s.put("opportunity","ENTRY");
        c.step(view(102,2.98,false,.2f,false),s);
        check(!flag(frame(c),"attack"),"ordinary ascending ENTRY may not consume the reserved escape-sword critical charge");
        s=HopWeaponCheck.senses(2.98,false,.2,false);s.put("opportunity","EXIT");
        c.step(view(103,2.98,false,.2f,false),s);
        check(c.phase().equals("TURN_EXIT")&&flag(frame(c),"attack"),"a real departure window still permits the ordinary final sword hit");
        call(c.controller,"beforeMelee",new Class<?>[]{double.class},0.);
        call(c.controller,"meleeAttemptFinished",new Class<?>[]{long.class,double.class,boolean.class},103L,1.,false);
        call(c.controller,"hopCriticalObservation",new Class<?>[]{float.class,double.class},.95f,-.08);
        c.step(view(104,2.98,false,.88f,false),HopWeaponCheck.senses(2.98,false,-.08,true));
        check(!c.phase().equals("HOP_CRIT")&&!flag(frame(c),"attack"),"a confirmed final fallback completes this escape's attack sequence; no later critical search or extra click");
        var priority=HopWeaponCheck.start(p);
        s=HopWeaponCheck.senses(2.98,false,-.08,true);s.put("opportunity","EXIT");
        call(priority.controller,"hopCriticalObservation",new Class<?>[]{float.class,double.class},.95f,-.08);
        priority.step(view(104,2.98,false,.88f,false),s);
        check(priority.phase().equals("HOP_CRIT")&&flag(frame(priority),"attack"),"a real critical and final EXIT in the same frame choose the critical, never a normal fallback first");
        var missed=HopWeaponCheck.start(p);
        s=HopWeaponCheck.senses(2.98,false,.2,false);s.put("opportunity","EXIT");
        missed.step(view(103,2.98,false,.2f,false),s);
        call(missed.controller,"beforeMelee",new Class<?>[]{double.class},0.);
        call(missed.controller,"meleeAttemptFinished",new Class<?>[]{long.class,double.class,boolean.class},103L,0.,false);
        call(missed.controller,"hopCriticalObservation",new Class<?>[]{float.class,double.class},.95f,-.08);
        missed.step(view(104,2.98,false,.88f,false),HopWeaponCheck.senses(2.98,false,-.08,true));
        check(missed.phase().equals("HOP_CRIT"),"an attempted but unconfirmed final hit cannot falsely complete the escape");
        var outside=HopWeaponCheck.start(p);
        call(outside.controller,"hopCriticalObservation",new Class<?>[]{float.class,double.class},.95f,-.08);
        outside.step(view(104,3.00001,false,1f,false),HopWeaponCheck.senses(3.00001,false,-.08,true));
        check(!flag(frame(outside),"attack"),"the critical fix never grants out-of-reach retaliation");
    }
    static void bothShields(int p)throws Exception {
        for(boolean raised:new boolean[]{false,true})for(long seed=0;seed<40;seed++) {
            var c=new RestartCheck.Controller(a,p,seed*104729);
            set(c.controller,"exitControl",true);observe(c,true,raised,0);
            call(c.controller,"shortAdvanceAvailable",new Class<?>[]{boolean.class},true);
            var s=shield(raised?2.98:3.2,true);s.put("targetShieldRaised",raised);
            c.step(view(100,raised?2.98:3.2,true,1f,raised),s);
            check(!Set.of("ACTIVE_ADVANCE","ACTIVE_STRIKE","STUN_FIRST","SHIELD_PRESS").contains(c.phase()),
                "two usable shields without a proven outside shield-delay budget prohibit optional attacks; passive shield pressure may not leak");
            if(raised)check(!flag(frame(c),"attack"),"effective opposing shield is not an automatic axe target while own shield is usable");
        }
    }
    static void openingTiming(RestartCheck.Controller c,int ticks,int delay)throws Exception {
        call(c.controller,"shortAdvanceAvailable",new Class<?>[]{boolean.class},true);
        call(c.controller,"shortAdvanceTiming",new Class<?>[]{int.class,int.class},ticks,delay);
    }
    static RestartCheck.Controller outerOpening(int p,boolean ownShield,boolean targetShield)throws Exception {
        for(long seed=0;seed<100;seed++) {
            var c=new RestartCheck.Controller(a,p,seed*104729L);set(c.controller,"exitControl",true);
            observe(c,true,false,0);openingTiming(c,3,5);
            var s=RestartCheck.senses(3.2);s.put("targetShieldDisabled",!targetShield);
            s.put("ownShieldCooldown",ownShield?0.:80.);
            c.step(view(600,3.2,ownShield,1f,false),s);
            check(!flag(frame(c),"attack"),"outer opening never damages from outside the real reach");
            if(c.phase().equals("ACTIVE_ADVANCE"))return c;
        }
        throw new AssertionError("eligible outer opening never exercised");
    }
    static void outerOpenings(int p)throws Exception {
        for(boolean ownShield:new boolean[]{false,true})for(boolean targetShield:new boolean[]{false,true}) {
            var c=outerOpening(p,ownShield,targetShield);
            for(int step=1;step<=3;step++) {
                double reach=step==1?3.10:step==2?3.02:2.98;
                openingTiming(c,3-step,5);observe(c,true,false,0);
                var s=RestartCheck.senses(reach);s.put("targetShieldDisabled",!targetShield);
                s.put("ownShieldCooldown",ownShield?0.:80.);
                c.step(view(600+step,reach,ownShield,1f,false),s);
                check(c.phase().equals(step==3?"ACTIVE_STRIKE":"ACTIVE_ADVANCE"),
                    "outside-started opening may finish at a real legal edge after at most three movement ticks");
                check(flag(frame(c),"attack")== (step==3),"only the live legal edge frame may attack");
            }
            call(c.controller,"beforeMelee",new Class<?>[]{double.class},0.);
            call(c.controller,"meleeAttemptFinished",new Class<?>[]{long.class,double.class,boolean.class},603L,2.,false);
            var s=RestartCheck.senses(2.98);s.put("targetLandAge",0.);s.put("targetShieldDisabled",true);
            s.put("ownShieldCooldown",ownShield?0.:80.);observe(c,true,false,0);
            c.step(view(613,2.98,ownShield,.5f,false),s);
            check(c.phase().equals("COMBO_EDGE"),"confirmed optional opening damage feeds the existing safe ground combo");
        }
        for(double reach:new double[]{2.0,2.8,2.95,2.98,3.0,3.30001})for(boolean ownShield:new boolean[]{false,true})
            for(long seed=0;seed<24;seed++) {
                var c=new RestartCheck.Controller(a,p,seed*104729L);set(c.controller,"exitControl",true);
                observe(c,false,false,0);openingTiming(c,1,5);
                var s=RestartCheck.senses(reach);s.put("ownShieldCooldown",ownShield?0.:80.);
                c.step(view(600,reach,ownShield,1f,false),s);
                check(!Set.of("ACTIVE_ADVANCE","ACTIVE_STRIKE").contains(c.phase()),
                    "already-close or too-far states cannot start the optional edge-combo opening");
            }
        for(int[] budget:new int[][]{{3,-1},{3,0},{3,3},{3,4},{-1,5},{0,5},{4,8}})
            for(long seed=0;seed<24;seed++) {
                var c=new RestartCheck.Controller(a,p,seed*104729L);set(c.controller,"exitControl",true);
                observe(c,true,false,0);openingTiming(c,budget[0],budget[1]);
                var s=RestartCheck.senses(3.2);s.put("targetShieldDisabled",false);
                c.step(view(600,3.2,true,1f,false),s);
                check(!Set.of("ACTIVE_ADVANCE","ACTIVE_STRIKE","STUN_FIRST").contains(c.phase()),
                    "unknown/insufficient shield delay or invalid edge forecast cannot authorize the both-shields exception");
            }
        for(String scenario:List.of("RAISED","JUMP","ARROW","TIMEOUT","SHORT_DELAY")) {
            var c=outerOpening(p,true,true);openingTiming(c,1,scenario.equals("SHORT_DELAY")?2:5);
            double reach=2.98;
            var s=RestartCheck.senses(reach);s.put("targetShieldDisabled",false);
            if(scenario.equals("RAISED"))s.put("targetShieldRaised",true);
            if(scenario.equals("JUMP")){s.put("targetAirborne",true);s.put("targetCritThreat",true);s.put("targetY",.3);}
            if(scenario.equals("ARROW"))s.put("closeRangedGuard",true);
            c.step(view(scenario.equals("TIMEOUT")?604:601,reach,true,1f,false),s);
            check(!Set.of("ACTIVE_ADVANCE","ACTIVE_STRIKE","STUN_FIRST").contains(c.phase()),
                "opening yields immediately when edge or safety proof is lost: "+scenario);
            check((long)get(c.controller,"advanceUntil")<0,"aborted optional opening clears its pending movement window: "+scenario);
        }
        var interrupted=outerOpening(p,true,true);
        var threat=RestartCheck.senses(3.2);threat.put("targetShieldDisabled",false);threat.put("closeRangedGuard",true);
        interrupted.step(view(601,3.2,true,1f,false),threat);
        openingTiming(interrupted,1,5);var near=RestartCheck.senses(2.98);near.put("targetShieldDisabled",false);
        interrupted.step(view(602,2.98,true,1f,false),near);
        check(!interrupted.phase().equals("ACTIVE_STRIKE"),"defensive interruption cannot later resume the old dropped-shield opening");
        var crossed=outerOpening(p,true,true);openingTiming(crossed,1,5);
        near=RestartCheck.senses(2.8);near.put("targetShieldDisabled",false);
        crossed.step(view(601,2.8,true,1f,false),near);
        check(crossed.phase().equals("ACTIVE_STRIKE")&&flag(frame(crossed),"attack"),
            "an outside-started shield-race must attack immediately on real contact, even when one movement step crosses inside 2.96");
    }
    static void openingExecution(int p)throws Exception {
        var c=outerOpening(p,true,true);openingTiming(c,1,5);
        var s=RestartCheck.senses(2.98);s.put("targetShieldDisabled",false);
        c.step(view(601,2.98,true,1f,false),s);
        check(c.phase().equals("ACTIVE_STRIKE"),"fixture reaches the real proactive execution phase");
        Class<?> player=Class.forName("org.bukkit.entity.Player"),entity=Class.forName("org.bukkit.entity.Entity");
        Class<?> world=Class.forName("org.bukkit.World"),loc=Class.forName("org.bukkit.Location"),box=Class.forName("org.bukkit.util.BoundingBox");
        var location=loc.getConstructor(world,double.class,double.class,double.class,float.class,float.class);
        var bounds=box.getConstructor(double.class,double.class,double.class,double.class,double.class,double.class);
        double[] reach={2.98};boolean[] grounded={true,true},blocking={false};
        Object own=Proxy.newProxyInstance(CombatRegressionCheck.class.getClassLoader(),new Class<?>[]{player},(o,m,args)->switch(m.getName()) {
            case "isOnGround"->grounded[0];case "getEyeLocation"->location.newInstance(null,0.,1.62,0.,0f,0f);
            case "getX","getZ"->0.;default->null;
        });
        Object target=Proxy.newProxyInstance(CombatRegressionCheck.class.getClassLoader(),new Class<?>[]{player},(o,m,args)->switch(m.getName()) {
            case "isOnGround"->grounded[1];case "isBlocking"->blocking[0];
            case "getX"->reach[0]+.3;case "getZ"->0.;
            case "getBoundingBox"->bounds.newInstance(reach[0],0.,-.3,reach[0]+.6,1.8,.3);
            case "getLocation"->location.newInstance(null,reach[0]+.3,0.,0.,90f,0f);
            default->null;
        });
        var hook=a.type("CombatInputHooks").getDeclaredMethod("chargeAllowed",float.class,boolean.class,player,entity,a.type("InitialCombatController"));hook.setAccessible(true);
        for(String scenario:List.of("EDGE","NEAR","FAR","SHIELD","OWN_AIR","TARGET_AIR","LOW_CHARGE")) {
            reach[0]=scenario.equals("NEAR")?2.8:scenario.equals("FAR")?3.00001:2.98;
            blocking[0]=scenario.equals("SHIELD");grounded[0]=!scenario.equals("OWN_AIR");grounded[1]=!scenario.equals("TARGET_AIR");
            float charge=scenario.equals("LOW_CHARGE")?.1f:1f;
            check((boolean)hook.invoke(null,charge,true,own,target,c.controller)==Set.of("EDGE","NEAR").contains(scenario),
                "native execution independently rejects changed geometry/defense, even with an opportunity flag: "+scenario);
        }
    }
    static void contact(int p)throws Exception {
        var c=new RestartCheck.Controller(a,p,445);set(c.controller,"exitControl",true);
        var s=RestartCheck.senses(2.8);s.put("ownShieldCooldown",80.);s.put("targetAttackAge",0.);s.put("damageAge",0.);
        observe(c,false,false,0);c.step(view(300,2.8,false,.1f,false),s);
        check(c.phase().equals("CONTACT_REPLY")&&flag(frame(c),"attack")&&!flag(frame(c),"jump"),"breached ground control replies to a real normal hit without waiting for full charge");
        call(c.controller,"beforeMelee",new Class<?>[]{double.class},0.);
        call(c.controller,"meleeAttemptFinished",new Class<?>[]{long.class,double.class,boolean.class},300L,1.,false);
        s.put("damageAge",1.);s.put("targetAttackAge",1.);c.step(view(301,2.8,false,.1f,false),s);
        check(!c.phase().equals("CONTACT_REPLY"),"the same swing/wound does not repeatedly consume charge");
        c=new RestartCheck.Controller(a,p,446);set(c.controller,"exitControl",true);set(c.controller,"landingTradePending",true);
        Object plan=a.make("TradeJump$Plan",new Class<?>[]{double.class,double.class,int.class,double.class,boolean.class},-1.,0.,11,3.5,true);
        call(c.controller,"tradeObservation",new Class<?>[]{a.type("TradeJump$Plan"),long.class,boolean.class,boolean.class},plan,-1000L,false,false);
        s=RestartCheck.senses(2.8);s.put("ownShieldCooldown",80.);s.put("targetAirborne",true);s.put("targetY",.42);
        s.put("targetCritThreat",true);s.put("targetCriticalPossible",true);
        c.step(view(400,2.8,false,.55f,false),s);
        check(c.phase().equals("AIR_DODGE")&&flag(frame(c),"jump"),"first observed close rising frame submits synchronized exchange jump immediately; optional attacks and low-charge interrupts cannot steal it");
        call(c.controller,"jumpInputSubmitted",new Class<?>[]{long.class},400L);
        s.put("onGround",false);c.step(view(401,2.8,false,.6f,false),s);
        check(!flag(frame(c),"jump")&&!flag(frame(c),"attack"),"same exchange neither queues a second jump nor spends its charge early");
    }
    static void combos(int p)throws Exception {
        for(String scenario:List.of("VALID","RETREATING","IMMUNE","AIR_CRIT","SHIELD","OUTSIDE")) {
            var c=new RestartCheck.Controller(a,p,37);set(c.controller,"exitControl",true);
            call(get(c.controller,"groundCombo"),"hit",new Class<?>[]{long.class},500L);
            double reach=scenario.equals("OUTSIDE")?3.00001:2.98;
            var s=RestartCheck.senses(reach);s.put("ownShieldCooldown",80.);s.put("targetLandAge",0.);
            if(scenario.equals("RETREATING"))s.put("separationSpeed",.4);
            if(scenario.equals("AIR_CRIT")){s.put("targetAirborne",true);s.put("targetY",-.2);s.put("targetCritThreat",true);s.put("targetCriticalPossible",true);}
            boolean blocked=scenario.equals("SHIELD");s.put("targetShieldRaised",blocked);
            observe(c,false,blocked,scenario.equals("IMMUNE")?19:0);
            c.step(view(510,reach,false,.5f,blocked),s);
            boolean valid=List.of("VALID","RETREATING").contains(scenario);
            check(c.phase().equals("COMBO_EDGE")==valid,"landing continuation requires a real safe edge opportunity, not an opponent-retreat veto: "+scenario);
            if(valid) {
                call(c.controller,"beforeMelee",new Class<?>[]{double.class},1.);
                call(c.controller,"meleeAttemptFinished",new Class<?>[]{long.class,double.class,boolean.class},510L,2.,false);
                c.step(view(520,reach,false,.5f,false),s);
                check(c.phase().equals("COMBO_EDGE"),"another confirmed hit renews the chain without a fixed combo count");
            }
        }
    }
    public static void main(String[] args)throws Exception {
        a=new RestartCheck.Archive(Path.of(args[0]),null);
        for(int p=0;p<2;p++){hopRegression(p);bothShields(p);outerOpenings(p);openingExecution(p);contact(p);combos(p);}
        System.out.println("CombatRegressionCheck: "+checks+" passed; both models, outside-started combo openings with real shield-delay budget, immediate legal contact hit including deeper entry, interrupted/unsafe opening cancellation, deleted double-hit feature, scoped exchange and renewable landing combos.");
    }
}

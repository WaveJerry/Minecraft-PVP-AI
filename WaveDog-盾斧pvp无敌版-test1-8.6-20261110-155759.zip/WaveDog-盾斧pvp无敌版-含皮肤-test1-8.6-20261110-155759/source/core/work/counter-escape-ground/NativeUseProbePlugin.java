package local.wavedog.probe;

import java.lang.reflect.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.CrossbowMeta;
import org.bukkit.plugin.java.JavaPlugin;

/** Isolated test server only. Not shipped or installed on the user's main server. */
public final class NativeUseProbePlugin extends JavaPlugin implements Listener {
    private Object ai,memory,context;private Player own;private int shots,scenario,frame;private double health;private AbstractArrow incoming;private final List<String> result=new ArrayList<>();
    private Class<?> type(String name)throws Exception{return Class.forName("local.pvpbot.ai."+name,true,ai.getClass().getClassLoader());}
    private Object helper(String owner,String name,Class<?>[] types,Object...args)throws Exception{var m=type(owner).getDeclaredMethod(name,types);m.setAccessible(true);return m.invoke(null,args);}
    private void cancel()throws Exception{var m=ai.getClass().getDeclaredMethod("cancelCombatUse",Player.class,type("CombatMemory"));m.setAccessible(true);m.invoke(ai,own,memory);helper("NativeUseSession","detachQueuedUse",new Class<?>[]{ai.getClass(),Player.class},ai,own);}
    private void check(boolean ok,String text){if(!ok)throw new IllegalStateException(text);result.add("PASS "+text);getLogger().info("PASS "+text);}
    @Override public void onEnable(){
        getServer().getPluginManager().registerEvents(this,this);
        getServer().getScheduler().runTaskLater(this,()->run(this::start),30);
    }
    @FunctionalInterface interface Task{void run()throws Exception;}
    private void run(Task task){try{task.run();}catch(Throwable e){result.add("FAILED "+e);e.printStackTrace();finish();}}
    private void start()throws Exception{
        ai=getServer().getPluginManager().getPlugin("PvPArenaAI");check(ai!=null,"real WaveDog plugin enabled");
        var ctor=type("CombatMemory").getDeclaredConstructor();ctor.setAccessible(true);memory=ctor.newInstance();
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(),"fp spawn UseProbe");
        getServer().getScheduler().runTaskLater(this,()->run(this::load),40);
    }
    private void load()throws Exception{
        own=Bukkit.getPlayerExact("UseProbe");check(own!=null,"real fakeplayer spawned");
        World w=own.getWorld();for(int x=-18;x<=18;x++)for(int z=-18;z<=18;z++)w.getBlockAt(x,100,z).setType(Material.STONE);
        own.teleport(new Location(w,0.5,101,0.5));own.setGameMode(GameMode.SURVIVAL);own.setFoodLevel(20);
        own.getInventory().clear();own.getInventory().setItemInMainHand(new ItemStack(Material.DIAMOND_AXE));
        own.getInventory().setItemInOffHand(new ItemStack(Material.CROSSBOW));own.getInventory().setItem(4,new ItemStack(Material.ARROW,5));
        cancel();helper("NativeOffhandUse","use",new Class<?>[]{Player.class},own);
        check(own.hasActiveItem()&&own.getActiveItem().getType()==Material.CROSSBOW,"native OFF_HAND crossbow began");
        int duration=(int)helper("NativeCrossbowTiming","duration",new Class<?>[]{Player.class,ItemStack.class},own,own.getInventory().getItemInOffHand());
        result.add("native crossbow duration="+duration);
        getServer().getScheduler().runTaskLater(this,()->run(this::loaded),duration+2);
    }
    private void loaded()throws Exception{
        check(own.hasActiveItem()||charged(),"old queued USE stop did not cancel new crossbow use");
        if(!charged())helper("VanillaUseRelease","release",new Class<?>[]{Object.class},own);
        check(charged(),"real crossbow meta contains a charged arrow");
        check(own.getInventory().getItem(4).getAmount()==4,"loading consumed exactly one real arrow");
        own.getInventory().setItemInOffHand(new ItemStack(Material.BOW));cancel();
        helper("NativeOffhandUse","use",new Class<?>[]{Player.class},own);
        getServer().getScheduler().runTaskLater(this,()->run(this::bow),21);
    }
    private boolean charged(){return own.getInventory().getItemInOffHand().getItemMeta() instanceof CrossbowMeta m&&m.hasChargedProjectiles();}
    private void bow()throws Exception{
        check(own.hasActiveItem()&&own.getActiveItem().getType()==Material.BOW&&own.getHandRaisedTime()>=20,"bow draw survived twenty real server ticks");
        helper("VanillaUseRelease","release",new Class<?>[]{Object.class},own);
        check(shots==1,"normal native bow release emitted exactly one real EntityShootBowEvent");
        check(own.getInventory().getItem(4).getAmount()==3,"bow shot consumed one real arrow");
        var ctor=type("OffhandRangedSupport$Context").getDeclaredConstructor();ctor.setAccessible(true);context=ctor.newInstance();
        var cc=type("InitialCombatController").getDeclaredConstructor(long.class);cc.setAccessible(true);
        for(var entry:Map.of("plugin",ai,"own",own,"target",own,"memory",memory,"controller",cc.newInstance(123L)).entrySet())set(context,entry.getKey(),entry.getValue());
        var sc=type("NeuralLearner$Senses").getDeclaredConstructor();sc.setAccessible(true);set(context,"senses",sc.newInstance());
        projectileStart();
    }
    private void set(Object o,String field,Object value)throws Exception{var f=o.getClass().getDeclaredField(field);f.setAccessible(true);f.set(o,value);}
    private Object get(Object o,String field)throws Exception{var f=o.getClass().getDeclaredField(field);f.setAccessible(true);return f.get(o);}
    private Object value(Object o,String method)throws Exception{var m=o.getClass().getDeclaredMethod(method);m.setAccessible(true);return m.invoke(o);}
    private Object plan(AbstractArrow arrow)throws Exception{return helper("ProjectileDefence","plan",new Class<?>[]{ai.getClass(),Player.class,int.class,AbstractArrow.class},ai,own,0,arrow);}
    private void projectileStart()throws Exception{
        for(var e:own.getWorld().getEntitiesByClass(AbstractArrow.class))e.remove();
        cancel();own.teleport(new Location(own.getWorld(),.5,101,.5,0,0));own.setVelocity(new org.bukkit.util.Vector());own.setHealth(20);health=20;
        var zero=ai.getClass().getDeclaredMethod("applyMovementInput",Player.class,float.class,float.class,boolean.class,boolean.class);zero.setAccessible(true);zero.invoke(ai,own,0f,0f,false,false);
        own.getInventory().setItemInMainHand(new ItemStack(Material.DIAMOND_AXE));own.getInventory().setItemInOffHand(new ItemStack(Material.SHIELD));
        own.setCooldown(Material.SHIELD,scenario<2?0:100);
        for(int z=-3;z<=15;z++)for(int y=101;y<=103;y++)own.getWorld().getBlockAt(1,y,z).setType(scenario==4||scenario==6?Material.STONE:Material.AIR);
        for(int x=-12;x<=12;x++)for(int z=-3;z<=15;z++)own.getWorld().getBlockAt(x,103,z).setType(scenario==7?Material.STONE:Material.AIR);
        if(scenario==4||scenario==6)for(int z=-3;z<=15;z++)own.getWorld().getBlockAt(1,103,z).setType(Material.STONE);
        getServer().getScheduler().runTaskLater(this,()->run(this::projectileLaunch),2);
    }
    private void projectileLaunch()throws Exception {
        frame=0;double z=scenario==1?-13.5:14.5,y=scenario==3?107.1:102.1;
        org.bukkit.util.Vector velocity=scenario==3?new org.bukkit.util.Vector(0,-.15,-1.05):new org.bukkit.util.Vector(0,0,scenario==1?1.8:-1.8);
        if(scenario==3)z=12.5;
        if(scenario==5||scenario==6){z=10.5;velocity=new org.bukkit.util.Vector(0,0,-3.15);}
        incoming=own.getWorld().spawn(new Location(own.getWorld(),.5,y,z),Arrow.class);incoming.setGravity(scenario==3);incoming.setVelocity(velocity);
        var p=plan(incoming);
        check((boolean)value(p,"owns"),"scenario "+scenario+" has an executable projectile defence");
        check((boolean)value(p,"shield")== (scenario<2),"scenario "+scenario+" usable shield guards; broken shield alone dodges");
        if(scenario==5||scenario==6) {
            check((boolean)value(p,"jump"),"scenario "+scenario+" near arrow selects a sprint-side jump");
            check((boolean)value(plan(incoming),"jump"),"scenario "+scenario+" observing a plan cannot consume its jump input");
        }
        if(scenario==7)check(!(boolean)value(p,"jump"),"low ceiling keeps the real dodge grounded");
        var firstTick=ai.getClass().getDeclaredField("tick");firstTick.setAccessible(true);set(context,"tick",firstTick.getLong(ai));
        helper("OffhandRangedSupport","defend",new Class<?>[]{type("OffhandRangedSupport$Context"),AbstractArrow.class},context,incoming);
        if(scenario==5||scenario==6) {
            check(own.getVelocity().getY()>0&&own.isSprinting(),"scenario "+scenario+" same-callback native jump starts immediately at sprint speed");
            check(!(boolean)value(plan(incoming),"jump"),"scenario "+scenario+" same-tick observation never requests a second jump impulse");
            if(scenario==6)check(own.getVelocity().getX()<0,"wall selects the open left side in actual native jump impulse");
        }
        getServer().getScheduler().runTaskTimer(this,task->{
            try {
                if(frame++>=18){task.cancel();check(own.getHealth()==health,"scenario "+scenario+" real arrow caused no health loss");
                    scenario++;if(scenario<8)getServer().getScheduler().runTaskLater(this,()->run(this::projectileStart),2);else {
                        // The next probe needs an open sky; do not leak this scenario's ceiling.
                        for(int x=-12;x<=12;x++)for(int roofZ=-3;roofZ<=15;roofZ++)own.getWorld().getBlockAt(x,103,roofZ).setType(Material.AIR);
                        for(var arrow:own.getWorld().getEntitiesByClass(AbstractArrow.class))arrow.remove();
                        new NativeEscapeProbe(this,ai,own,result,this::finish).start();
                    }return;}
                var tick=ai.getClass().getDeclaredField("tick");tick.setAccessible(true);set(context,"tick",tick.getLong(ai));
                if(scenario>=5&&frame<=5) {
                    var before=plan(null);result.add("TRACE scenario="+scenario+" frame="+frame+" own="+own.getLocation()+" velocity="+own.getVelocity()+" ground="+own.isOnGround()+" hp="+own.getHealth()+" arrow="+incoming.getLocation()+" av="+incoming.getVelocity()+" jumping="+value(before,"jump")+" heading="+value(before,"forward")+" owns="+value(before,"owns"));
                }
                helper("OffhandRangedSupport","defend",new Class<?>[]{type("OffhandRangedSupport$Context"),AbstractArrow.class},context,null);
                if(scenario<2&&frame==7)check(own.isBlocking(),"scenario "+scenario+" repeated guard requests preserve native shield warmup");
                if(scenario>=2&&frame==2)check(!own.hasActiveItem(),"scenario "+scenario+" dodge has no stale USE slowdown");
            }catch(Throwable e){task.cancel();result.add("FAILED "+e);e.printStackTrace();finish();}
        },0,1);
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void shot(EntityShootBowEvent e){if(e.getEntity().equals(own)&&e.getBow()!=null&&e.getBow().getType()==Material.BOW&&e.getProjectile() instanceof AbstractArrow a&&a.getVelocity().lengthSquared()>0)shots++;}
    private void finish(){try{Files.write(getDataFolder().toPath().toAbsolutePath().getParent().getParent().resolve("native-use-result.txt"),result,StandardCharsets.UTF_8);}catch(Exception e){e.printStackTrace();}Bukkit.getScheduler().runTaskLater(this,Bukkit::shutdown,2);}
}

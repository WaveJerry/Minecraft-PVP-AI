package local.pvpbot.ai;
import java.util.*;
import static local.pvpbot.ai.ArrowDodgePlanner.*;

/** Pure swept-geometry and world-space route regressions. */
public final class ArrowEscapeCheck {
    private static int checks;
    static void check(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}
    static Body body(Vec velocity,boolean grounded){return new Body(new Vec(0,0,0),velocity,new Vec(0,0,1),.3,1.8,.1,1,grounded,true,-32,32,-32,32,0);}
    static ArrowEscapePlanner.Route route(Body b,List<Shot> shots,boolean jump,ArrowEscapePlanner.Space space) {
        return ArrowEscapePlanner.choose(new ArrowEscapePlanner.Motion(b,.546,.42,jump),shots,2,1,null,space);
    }
    public static void main(String[] args) {
        Shot near=new Shot(1,new Vec(0,1.2,10),new Vec(0,0,-3.15),false,.99,true);
        var stationary=body(new Vec(0,0,0),true);
        var fast=route(stationary,List.of(near),true,(a,b,w,h)->true);
        check(fast!=null&&fast.jump(),"near full-speed arrow requires immediate sprint-side jump");
        check(Math.abs(fast.heading().x())>.85,"escape heads across the trajectory instead of backing along it");
        check(route(stationary,List.of(near),false,(a,b,w,h)->true)==null,"ground-only search cannot falsely claim this late escape");
        var blocked=route(stationary,List.of(near),true,(a,b,w,h)->Math.max(a.x(),b.x())+w<.65);
        check(blocked!=null&&blocked.heading().x()<0,"right wall selects the left exit");
        var ceiling=route(stationary,List.of(new Shot(1,new Vec(0,1.2,14),new Vec(0,0,-2),false,.99,true)),true,
            (a,b,w,h)->Math.max(a.y(),b.y())+h<2.1);
        check(ceiling!=null&&!ceiling.jump(),"low ceiling rejects the jump while retaining a safe grounded escape");
        var airborne=body(new Vec(.3,.25,0),false);
        var air=route(airborne,List.of(new Shot(1,new Vec(0,1.2,10),new Vec(0,0,-2),false,.99,true)),false,(a,b,w,h)->true);
        check(air!=null&&!air.jump(),"airborne route uses existing momentum without a second jump");
        var far=route(stationary,List.of(new Shot(1,new Vec(0,1.2,.8),new Vec(0,0,-3.15),false,.99,true)),true,(a,b,w,h)->true);
        check(far==null,"physically unavoidable close arrow is never reported safe");
        check(ArrowEscapePlanner.segmentBoxDistance(-2,1,0,2,1,0,.42,-.12,1.92)==0,"sweep catches tunnelling across the body in one tick");
        check(ArrowEscapePlanner.segmentBoxDistance(-2,3,0,2,3,0,.42,-.12,1.92)>1,"high arrow remains above the body");
        var clipped=new Shot(1,new Vec(0,1.2,6),new Vec(0,0,-3.15),false,.99,true,List.of(new Vec(0,1.2,6),new Vec(0,1.2,4)));
        check(Double.isNaN(ArrowEscapePlanner.paths(List.of(clipped))[0][2][0]),"block-clipped arrow path is never extrapolated through the wall");
        var overhead=route(stationary,List.of(new Shot(1,new Vec(0,1.2,14),new Vec(0,0,-2),false,.99,true),
            new Shot(2,new Vec(0,2.25,1),new Vec(0,0,-3.15),false,.99,true)),true,(a,b,w,h)->true);
        check(overhead!=null&&!overhead.jump(),"do not jump into a second arrow which would pass safely overhead");
        var crossing=route(stationary,List.of(new Shot(1,new Vec(0,1.2,14),new Vec(0,0,-2),false,.99,true),
            new Shot(2,new Vec(14,1.2,0),new Vec(-2,0,0),false,.99,true)),true,(a,b,w,h)->true);
        check(crossing!=null,"crossing simultaneous arrows are evaluated together");
        var phase=route(stationary,List.of(new Shot(1,new Vec(0,1.2,6),new Vec(0,0,-3.15),false,.99,true)),true,(a,b,w,h)->true);
        check(phase==null,"native expanded arrow collision and arrow-before-movement order reject the too-late six-block dodge");
        // Rotate the encounter through all compass angles: choice cannot depend on look/yaw.
        for(int i=0;i<72;i++) {
            double angle=i*Math.PI/36,x=Math.sin(angle),z=Math.cos(angle);
            var shot=new Shot(1,new Vec(x*14,1.2,z*14),new Vec(-x*3.15,0,-z*3.15),false,.99,true);
            var r=route(stationary,List.of(shot),true,(a,b,w,h)->true);
            check(r!=null&&r.jump(),"rotated sprint jump is feasible at angle "+i);
            check(Math.abs(r.heading().x()*x+r.heading().z()*z)<.6,"rotated escape is predominantly sideways "+i);
        }
        System.out.println("ArrowEscapeCheck: "+checks+" passed");
    }
}

import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;

/** Packaged kit conservation, actual 1.21.1 native method resolution, and real arrow planner. */
public final class RangedIntegrationCheck {
    static int checks;static RestartCheck.Archive archive;
    static void check(boolean yes,String why){checks++;if(!yes)throw new AssertionError(why);}
    static Object call(Object o,String name,Class<?>[] types,Object...args)throws Exception {
        var m=o.getClass().getDeclaredMethod(name,types);m.setAccessible(true);return m.invoke(o,args);
    }
    static Object invoke(String name,String method,Class<?>[] types,Object...args)throws Exception {
        var m=archive.type(name).getDeclaredMethod(method,types);m.setAccessible(true);return m.invoke(null,args);
    }
    static Object field(Object o,String name)throws Exception {var f=o.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(o);}
    @SuppressWarnings("unchecked")static void layoutConservation()throws Exception {
        Object canonical=invoke("KitLayout","canonical",new Class<?>[]{});
        List<String> base=(List<String>)call(canonical,"rows",new Class<?>[]{});
        for(int slot=4;slot<36;slot++)for(int held=0;held<9;held++)for(int loaded=0;loaded<=1;loaded++) {
            var physical=new ArrayList<>(base);physical.set(4,slot+",ARROW,"+(5-loaded));var snapshot=List.copyOf(physical);
            var normalized=(List<String>)invoke("RoundCrossbowKit","normalizeRows",new Class<?>[]{List.class,int.class},physical,loaded);
            check(physical.equals(snapshot),"capturing must never mutate countdown inventory rows");
            Object parsed=invoke("KitLayout","parse",new Class<?>[]{List.class,int.class},normalized,held);
            check((int)field(parsed,"held")==held,"countdown hotbar selection must survive capture");
            check(normalized.contains(slot+",ARROW,5"),"five total arrows = loose plus loaded, including moved arrow slot");
            check(normalized.equals(invoke("RoundCrossbowKit","normalizeRows",new Class<?>[]{List.class,int.class},physical,loaded)),"repeated reads must not multiply loaded ammunition");
        }
        var over=new ArrayList<>(base);
        var invalid=(List<String>)invoke("RoundCrossbowKit","normalizeRows",new Class<?>[]{List.class,int.class},over,1);
        boolean rejected=false;try{invoke("KitLayout","parse",new Class<?>[]{List.class,int.class},invalid,0);}catch(InvocationTargetException e){rejected=e.getCause() instanceof IllegalArgumentException;}
        check(rejected,"five loose plus an extra loaded arrow cannot silently become the normal five-arrow kit");
    }
    static void nativeBindings()throws Exception {
        Class<?> main=archive.type("PvPArenaAI"),player=Class.forName("org.bukkit.entity.Player"),vector=Class.forName("org.bukkit.util.Vector");
        for(String type:List.of("RoundCrossbowKit","NativeOffhandUse","OffhandRangedSupport")) {
            archive.type(type).getDeclaredMethods();check(true,"actual Paper helper resolves: "+type);
        }
        var f=archive.type("NativeOffhandUse").getDeclaredField("ACCESS");f.setAccessible(true);
        Class<?> craft=Class.forName("org.bukkit.craftbukkit.entity.CraftPlayer",false,RangedIntegrationCheck.class.getClassLoader());
        Object access=((ClassValue<?>)f.get(null)).get(craft);
        Method use=(Method)call(access,"use",new Class<?>[]{});
        check(use.getName().equals("useItem")&&use.getParameterCount()==4,"normal game-mode useItem is bound, with no direct projectile creation");
        check(call(access,"hand",new Class<?>[]{}).toString().equals("OFF_HAND"),"native input explicitly uses the offhand");
        check(((Method)call(access,"stack",new Class<?>[]{})).getName().equals("getOffhandItem"),"native offhand stack is read from the real player");
        main.getDeclaredMethod("selectWeapon",player,archive.type("CombatMemory"),archive.type("Weapon"),boolean.class);
        main.getDeclaredMethod("move",player,archive.type("Motion"),boolean.class,boolean.class,boolean.class);
        main.getDeclaredMethod("cancelCombatUse",player,archive.type("CombatMemory"));
        main.getDeclaredMethod("applyMovementInput",player,float.class,float.class,boolean.class,boolean.class);
        main.getDeclaredMethod("rotateToward",player,player,archive.type("CombatMemory"),archive.type("Weapon"),double.class,boolean.class);
        main.getDeclaredMethod("resumeRetreatInputs",player,archive.type("CombatMemory"),boolean.class);
        main.getDeclaredMethod("turnToDirection",player,vector,float.class);check(true,"all private input/aim/movement bridges resolve exact signatures");
        Class<?> support=archive.type("OffhandRangedSupport");
        player.getMethod("getActiveItemHand");
        check(player.getMethod("getShieldBlockingDelay").getReturnType()==int.class,
            "outer opening uses the live target's actual Paper shield delay, not a hardcoded five ticks");
        check(true,"crossbow tracks the actual active hand");
        for(String helper:List.of("NativeCrossbowTiming","NativeCriticalState")) {
            var accessField=archive.type(helper).getDeclaredField("ACCESS");accessField.setAccessible(true);
            Class<?> bound=helper.equals("NativeCriticalState")?Class.forName("org.bukkit.craftbukkit.CraftWorld",false,RangedIntegrationCheck.class.getClassLoader()):craft;
            check(((ClassValue<?>)accessField.get(null)).get(bound)!=null,"bind real 1.21.1 native timing/configuration: "+helper);
        }
        for(String event:List.of("interact","shot","stopUsing","jump")) {
            var method=Arrays.stream(support.getDeclaredMethods()).filter(m->m.getName().equals(event)).findFirst().orElseThrow();
            var annotation=Arrays.stream(method.getAnnotations()).filter(a->a.annotationType().getSimpleName().equals("EventHandler")).findFirst().orElseThrow();
            check(annotation.annotationType().getMethod("priority").invoke(annotation).toString().equals("MONITOR"),"synchronization uses actual input/shot/stop event callback: "+event);
        }
    }
    static void loadOutcomes()throws Exception {
        for(boolean loaded:new boolean[]{false,true})for(boolean using:new boolean[]{false,true})
            for(boolean finalRelease:new boolean[]{false,true})for(long age:new long[]{0,1,2,10}) {
                String result=invoke("CrossbowLoadSync","outcome",new Class<?>[]{boolean.class,boolean.class,boolean.class,long.class},loaded,using,finalRelease,age).toString();
                if(loaded)check(result.equals("FINISH"),"charged metadata, including stopped use, is the actual completion signal");
                else {
                    check(!result.equals("FINISH"),"elapsed full-use duration or stopped animation can never manufacture loaded success");
                    check(result.equals(using?"CONTINUE":finalRelease&&age<=1?"VERIFY":"CANCEL"),"unloaded early stop cancels; complete-release callback gets only a bounded metadata commit check");
                }
            }
    }
    static Object vec(double x,double y,double z)throws Exception{return archive.make("ArrowDodgePlanner$Vec",new Class<?>[]{double.class,double.class,double.class},x,y,z);}
    static Object plan(double range,boolean shield,double warmup)throws Exception {
        Class<?> vec=archive.type("ArrowDodgePlanner$Vec");
        Object body=archive.make("ArrowDodgePlanner$Body",new Class<?>[]{vec,vec,vec,double.class,double.class,double.class,double.class,
            boolean.class,boolean.class,double.class,double.class,double.class,double.class,double.class},
            vec(0,0,0),vec(0,0,0),vec(1,0,0),.3,1.8,.1,1.,true,true,-10.,10.,-10.,10.,0.);
        Object shot=archive.make("ArrowDodgePlanner$Shot",new Class<?>[]{int.class,vec,vec,boolean.class,double.class,boolean.class},1,vec(range,1,0),vec(-3,0,0),true,.99,true);
        return invoke("ArrowDodgePlanner","evaluate",new Class<?>[]{archive.type("ArrowDodgePlanner$Body"),List.class,double.class,boolean.class,int.class},body,List.of(shot),warmup,shield,0);
    }
    static int safe(Object plan)throws Exception {
        boolean[] safe=(boolean[])call(plan,"safeMoves",new Class<?>[]{}),viable=(boolean[])call(plan,"viableMoves",new Class<?>[]{});int n=0;
        for(int i=0;i<safe.length;i++)if(safe[i]&&viable[i])n++;return n;
    }
    static void trajectories()throws Exception {
        Object close=plan(1.3,false,5);check((boolean)call(close,"threat",new Class<?>[]{}),"point-blank arrow fixture actually threatens body");
        check(safe(close)==0,"point-blank unavoidable exchange cannot fabricate an instant lateral teleport");
        Object dodge=plan(9,false,5);check((boolean)call(dodge,"threat",new Class<?>[]{}),"farther shot still threatens unchanged trajectory");
        check(safe(dodge)>0,"an avoidable real parabolic arrow has safe physical movement choices");
        Object shield=plan(9,true,2);check((boolean)call(shield,"shieldSafe",new Class<?>[]{}),"enough warmup time makes a native shield defence valid");
        for(int profile=0;profile<2;profile++) {
            var c=new RestartCheck.Controller(archive,profile,22991);var s=RestartCheck.senses(4);
            s.put("ownShieldCooldown",80.);s.put("projectilePlan",close);
            c.step(RestartCheck.view(100,4,false),s);
            check(!c.phase().equals("ARROW_DODGE"),"unavoidable point-blank arrow does not force an ineffective dodge phase");
            c=new RestartCheck.Controller(archive,profile,22991);s=RestartCheck.senses(2.9);
            call(c.controller,"targetLoadingCrossbow",new Class<?>[]{boolean.class},true);
            var view=RestartCheck.view(100,2.9,true);view.put("targetDrawingRanged",true);
            c.step(view,s);
            check(c.phase().equals("RANGED_PUNISH"),"a direct legal ready melee hit precedes mirrored crossbow loading");
        }
    }
    static void dodgeExecution()throws Exception {
        Class<?> worldType=Class.forName("org.bukkit.World"),playerType=Class.forName("org.bukkit.entity.Player"),vectorType=Class.forName("org.bukkit.util.Vector");
        var vectorCtor=vectorType.getConstructor(double.class,double.class,double.class);
        var hitCtor=Class.forName("org.bukkit.util.RayTraceResult").getConstructor(vectorType);
        var locationCtor=Class.forName("org.bukkit.Location").getConstructor(worldType,double.class,double.class,double.class);
        var blocked=new java.util.concurrent.atomic.AtomicReference<double[]>();
        Object world=Proxy.newProxyInstance(RangedIntegrationCheck.class.getClassLoader(),new Class<?>[]{worldType},(o,m,args)->{
            if(m.getName().equals("rayTraceBlocks")) {
                var stop=blocked.get();Object direction=args[1];
                double dx=(double)vectorType.getMethod("getX").invoke(direction),dz=(double)vectorType.getMethod("getZ").invoke(direction);
                if(stop!=null&&(stop[0]==0&&stop[1]==0||dx*stop[0]+dz*stop[1]>.999))
                    return hitCtor.newInstance(vectorCtor.newInstance(0.,0.,0.));
            }
            return null;
        });
        Object own=Proxy.newProxyInstance(RangedIntegrationCheck.class.getClassLoader(),new Class<?>[]{playerType},(o,m,args)->switch(m.getName()) {
            case "getWorld"->world;case "getLocation"->locationCtor.newInstance(world,0.,0.,0.);default->null;
        });
        Object forward=vectorCtor.newInstance(1.,0.,0.),planned=plan(9,false,5);
        Class<?>[] types={playerType,archive.type("ArrowDodgePlanner$Result"),vectorType};
        int selected=(int)invoke("OffhandRangedSupport","safeMove",types,own,planned,forward);
        check(selected==(int)call(planned,"preferredMove",new Class<?>[]{}),"use the planner's safe preferred input without a second wandering rotation");
        boolean[] safe=(boolean[])call(planned,"safeMoves",new Class<?>[]{}),viable=(boolean[])call(planned,"viableMoves",new Class<?>[]{});
        check(selected>=0&&safe[selected]&&viable[selected],"actual selected dodge is a safe viable physical input");
        double f=(double)invoke("OffhandRangedSupport","dodgeForward",new Class<?>[]{int.class},selected);
        double s=(double)invoke("OffhandRangedSupport","dodgeSide",new Class<?>[]{int.class},selected);
        blocked.set(new double[]{f/Math.hypot(f,s),s/Math.hypot(f,s)});
        int alternate=(int)invoke("OffhandRangedSupport","safeMove",types,own,planned,forward);
        check(alternate>=0&&alternate!=selected&&safe[alternate]&&viable[alternate],"obstructed preferred input falls back to another verified safe movement");
        blocked.set(new double[]{0,0});
        check((int)invoke("OffhandRangedSupport","safeMove",types,own,planned,forward)==-1,"blocked movement cannot be counted as a feasible dodge");
        blocked.set(null);
        check((int)invoke("OffhandRangedSupport","safeMove",types,own,plan(1.3,false,5),forward)==-1,"unavoidable close arrow has no fabricated dodge input");
        for(int action=0;action<18;action++) {
            check(invoke("OffhandRangedSupport","dodgeForward",new Class<?>[]{int.class},action).equals(invoke("ArrowDodgePlanner","forward",new Class<?>[]{int.class},action)),"executed forward input matches trajectory simulation action "+action);
            check(invoke("OffhandRangedSupport","dodgeSide",new Class<?>[]{int.class},action).equals(invoke("ArrowDodgePlanner","side",new Class<?>[]{int.class},action)),"executed sideways input matches trajectory simulation action "+action);
        }
    }
    public static void main(String[] args)throws Exception {
        archive=new RestartCheck.Archive(Path.of(args[0]),null);layoutConservation();nativeBindings();trajectories();dodgeExecution();loadOutcomes();
        System.out.println("RangedIntegrationCheck: "+checks+" assertions passed; moved layouts/countdown capture conserve five total arrows, exact native 1.21.1 OFF_HAND binding and all bridge signatures resolve, input/stop/shot events registered at MONITOR, real trajectory dodge versus unavoidable close shot. No server/world/model writes.");
    }
}

import java.io.*;
import java.net.URI;
import java.nio.file.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.function.BiPredicate;
import java.util.function.Consumer;
import java.util.zip.*;
import javax.tools.*;

/** Compile the authorized source in memory; never alter jars, model files or servers. */
public final class GroundPressureCheck {
    static int checks;static boolean lastSprint;
    static void check(boolean ok,String why) { checks++;if(!ok)throw new AssertionError(why); }
    static final class Code extends SimpleJavaFileObject {
        final String name; final byte[] input; final ByteArrayOutputStream output=new ByteArrayOutputStream();
        Code(String name,byte[] input) {super(URI.create("memory:///"+name.replace('.','/')+".class"),Kind.CLASS);this.name=name;this.input=input;}
        public InputStream openInputStream(){return new ByteArrayInputStream(input);}
        public OutputStream openOutputStream(){return output;}
    }
    static Map<String,byte[]> archive(Path path)throws Exception {
        Map<String,byte[]> result=new HashMap<>();
        try(var zip=new ZipInputStream(Files.newInputStream(path))) {
            for(ZipEntry e;(e=zip.getNextEntry())!=null;)if(e.getName().endsWith(".class"))
                result.put(e.getName().substring(0,e.getName().length()-6).replace('/','.'),zip.readAllBytes());
        }
        return result;
    }
    static Map<String,byte[]> compile(List<Path> sources,Map<String,byte[]> dependencies)throws Exception {
        Map<String,Code> inputs=new HashMap<>(),outputs=new HashMap<>();
        dependencies.forEach((name,bytes)->inputs.put(name,new Code(name,bytes)));
        var compiler=ToolProvider.getSystemJavaCompiler();
        try(var standard=compiler.getStandardFileManager(null,Locale.ROOT,java.nio.charset.StandardCharsets.UTF_8)) {
            var manager=new ForwardingJavaFileManager<StandardJavaFileManager>(standard) {
                public Iterable<JavaFileObject> list(Location where,String pkg,Set<JavaFileObject.Kind> kinds,boolean recurse)throws IOException {
                    if(where!=StandardLocation.CLASS_PATH)return super.list(where,pkg,kinds,recurse);
                    List<JavaFileObject> found=new ArrayList<>();
                    for(Code c:inputs.values()) {int dot=c.name.lastIndexOf('.');String p=dot<0?"":c.name.substring(0,dot);if(p.equals(pkg)||recurse&&p.startsWith(pkg+"."))found.add(c);}
                    return found;
                }
                public String inferBinaryName(Location where,JavaFileObject file){return file instanceof Code c?c.name:super.inferBinaryName(where,file);}
                public JavaFileObject getJavaFileForInput(Location where,String name,JavaFileObject.Kind kind)throws IOException {
                    return where==StandardLocation.CLASS_PATH&&inputs.containsKey(name)?inputs.get(name):super.getJavaFileForInput(where,name,kind);
                }
                public JavaFileObject getJavaFileForOutput(Location where,String name,JavaFileObject.Kind kind,FileObject sibling) {
                    Code c=new Code(name,null);outputs.put(name,c);return c;
                }
            };
            boolean ok=compiler.getTask(null,manager,null,List.of("--release","21","-proc:none","-encoding","UTF-8"),null,
                standard.getJavaFileObjectsFromPaths(sources)).call();
            check(ok,"authorized source must compile against the actual deployed archive");
        }
        Map<String,byte[]> result=new HashMap<>();outputs.forEach((name,c)->result.put(name,c.output.toByteArray()));return result;
    }
    static final class Loader extends ClassLoader {
        final Map<String,byte[]> bytes;
        Loader(Map<String,byte[]> bytes){super(GroundPressureCheck.class.getClassLoader());this.bytes=bytes;}
        protected Class<?> findClass(String name)throws ClassNotFoundException {byte[] value=bytes.get(name);if(value==null)throw new ClassNotFoundException(name);return defineClass(name,value,0,value.length);}
        Class<?> type(String name)throws Exception{return loadClass("local.pvpbot.ai."+name);}
        Object make(String name,Class<?>[] types,Object...args)throws Exception {var c=type(name).getDeclaredConstructor(types);c.setAccessible(true);return c.newInstance(args);}
    }
    static Object call(Object receiver,String name,Class<?>[] types,Object...args)throws Exception {
        var m=receiver.getClass().getDeclaredMethod(name,types);m.setAccessible(true);return m.invoke(receiver,args);
    }
    static void field(Object receiver,String name,Object value)throws Exception {var f=receiver.getClass().getDeclaredField(name);f.setAccessible(true);f.set(receiver,value);}
    static Object field(Object receiver,String name)throws Exception {var f=receiver.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(receiver);}
    @SuppressWarnings({"rawtypes","unchecked"}) static Object value(Class<?> type,String name){return Enum.valueOf((Class)type,name);}
    static Object view(Loader l,long tick,double reach,boolean shield)throws Exception {
        return view(l,tick,reach,shield,1f);
    }
    static Object view(Loader l,long tick,double reach,boolean shield,float charge)throws Exception {
        var parts=l.type("CombatView").getRecordComponents();Class<?>[] types=new Class<?>[parts.length];Object[] args=new Object[parts.length];
        Set<String> yes=Set.of("visible","targetAxe","targetFacing","ownAttackReady","hasArrows");
        for(int i=0;i<parts.length;i++) {
            var part=parts[i];String name=part.getName();Class<?> type=types[i]=part.getType();
            if(type==boolean.class)args[i]=yes.contains(name);
            else if(type==long.class)args[i]=tick;
            else if(type==int.class)args[i]=0;
            else if(type==double.class)args[i]=reach;
            else if(type==float.class)args[i]=charge;
            if(type.isEnum())args[i]=value(type,name.equals("targetMotion")?"APPROACH":"SHIELD");
            if(name.equals("ownShieldAvailable"))args[i]=shield;
            if(name.equals("targetInReach"))args[i]=reach<=3;
        }
        return l.make("CombatView",types,args);
    }
    static Object senses(Loader l,double reach)throws Exception {
        Object s=l.make("NeuralLearner$Senses",new Class<?>[]{});
        for(String key:List.of("ownReachDistance","targetReachDistance","meleeRayDistance","estimatedReach","estimatedTargetReach"))field(s,key,reach);
        for(String key:List.of("onGround","targetMotionFresh","weaponInputReady","targetShieldDisabled","escapeViable","wallEscapeAvailable"))field(s,key,true);
        for(String key:List.of("targetAttackAge","blockedMeleeAge","damageAge","ownKnockbackAge","targetLandAge"))field(s,key,1000.);
        field(s,"estimateAge",0.);field(s,"targetFacingDot",1.);field(s,"opportunity",value(l.type("OpportunityStrike$Kind"),"NONE"));
        field(s,"lastBlockTick",-1000L);field(s,"lastMeleeTick",-1000L);return s;
    }
    static Object body(Loader l,double x,double z,double vx,double vz)throws Exception {
        return l.make("PrecisionFootwork$Body",new Class<?>[]{double.class,double.class,double.class,double.class},x,z,vx,vz);
    }
    static Object choose(Loader l,Object own,Object target,boolean sprint,Object v,Object s,Object tactics,
                         double min,double max,BiPredicate<Double,Double> clear)throws Exception {
        var m=l.type("GroundFootwork").getDeclaredMethod("choose",l.type("PrecisionFootwork$Body"),l.type("PrecisionFootwork$Body"),
            boolean.class,double.class,double.class,double.class,double.class,BiPredicate.class,l.type("CombatView"),l.type("NeuralLearner$Senses"),l.type("ConstrainedTactics"),Consumer.class);
        m.setAccessible(true);return m.invoke(null,own,target,sprint,min,max,min,max,clear,v,s,tactics,(Consumer<Boolean>)(chosen->lastSprint=chosen));
    }
    static double axis(Object heading,String name)throws Exception{return (double)call(heading,name,new Class<?>[]{});}
    static Object route(Loader l,double reach,boolean sprint)throws Exception {
        return choose(l,body(l,0,0,0,0),body(l,reach+.3,0,0,0),sprint,view(l,1,reach,false),senses(l,reach),null,-20,20,(x,z)->true);
    }
    static void select(Object tactics,int action)throws Exception {
        ((int[])field(tactics,"selected"))[9]=action;((boolean[])field(tactics,"used"))[9]=true;
    }
    static double wall(Loader l,String method,Object...args)throws Exception {
        Class<?>[] types=new Class<?>[args.length];for(int i=0;i<types.length;i++)types[i]=args[i] instanceof Boolean?boolean.class:double.class;
        var m=l.type("WallPositioning").getDeclaredMethod(method,types);m.setAccessible(true);return (double)m.invoke(null,args);
    }
    public static void main(String[] args)throws Exception {
        Path root=Path.of(args.length==0?"work/counter-escape-ground":args[0]);
        Map<String,byte[]> baseline=archive(root.resolve("base.jar")),dependencies=new HashMap<>(baseline);
        if(args.length>1)archive(Path.of(args[1])).forEach(dependencies::putIfAbsent);
        Map<String,byte[]> compiled=compile(List.of(root.resolve("src/local/pvpbot/ai/ProjectileMovementPriority.java"),root.resolve("src/local/pvpbot/ai/GroundFootwork.java"),
            root.resolve("src/local/pvpbot/ai/ConstrainedTactics.java"),root.resolve("src/local/pvpbot/ai/WallPositioning.java")),dependencies);
        check(compiled.keySet().equals(Set.of("local.pvpbot.ai.ProjectileMovementPriority","local.pvpbot.ai.GroundFootwork","local.pvpbot.ai.GroundFootwork$Choice",
            "local.pvpbot.ai.ConstrainedTactics","local.pvpbot.ai.ConstrainedTactics$Sample","local.pvpbot.ai.WallPositioning")),"compile must replace only authorized ground motion/tactics classes");
        Map<String,byte[]> revised=new HashMap<>(dependencies);revised.putAll(compiled);var l=new Loader(revised);
        for(boolean sprint:new boolean[]{false,true})for(double reach:new double[]{3.14,3.4,4.5,6.0}) {
            Object h=route(l,reach,sprint);check((reach<=3.3?axis(h,"x")>.99:axis(h,"x")==0)&&axis(h,"z")==0,"only the short 0.3-block approach window may bias forward: "+reach+" sprint="+sprint);
        }
        Object walk=route(l,3.10,false),sprint=route(l,3.10,true);
        check(axis(walk,"x")>.99,"walking has a safe step at the measured boundary");
        check(axis(sprint,"x")>.99&&!lastSprint,"legacy caller sprint flag must not turn selected walking into sprinting");
        check(axis(route(l,3.01,false),"x")==0,"near-boundary pressure must yield to hold");
        check(axis(choose(l,body(l,0,0,0,0),body(l,3.5,0,0,0),false,view(l,2,3.2,false,.2f),senses(l,3.2),null,-20,20,(x,z)->true),"x")==0,
            "ordinary low-charge ground control does not force sustained approach");
        check(axis(route(l,2.9,true),"x")<-.99,"inside reach: boundary repair may retreat");
        var own=body(l,0,0,0,0);var target=body(l,3.7,0,0,0);var v=view(l,10,3.4,false);var s=senses(l,3.4);
        field(s,"targetReachDistance",3.01);
        check(axis(choose(l,own,target,true,v,s,null,-20,20,(x,z)->true),"x")==0,"both actual directional reach measurements constrain pressure");
        s=senses(l,3.05);v=view(l,11,3.05,false);
        Object inertia=choose(l,body(l,0,0,.4,0),target,true,v,s,null,-20,20,(x,z)->true);
        check(axis(inertia,"x")<-.99,"unavoidable inertia must choose the least-inward available step");
        s=senses(l,4);v=view(l,12,4,false);
        Object blocked=choose(l,own,target,true,v,s,null,-20,20,(x,z)->false);
        check(axis(blocked,"x")==0&&axis(blocked,"z")==0,"all real paths blocked: HOLD");
        Object wall=choose(l,body(l,.99,0,0,0),body(l,5,0,0,0),true,v,s,null,-1,1,(x,z)->true);
        check(axis(wall,"x")<=0,"arena edge must reject forward and diagonal steps");
        field(s,"targetAirborne",true);check(choose(l,own,target,true,v,s,null,-20,20,(x,z)->true)==null,"jump defense owns airborne threat");
        field(s,"targetAirborne",false);field(s,"targetCritThreat",true);check(choose(l,own,target,true,v,s,null,-20,20,(x,z)->true)==null,"critical defense outranks ground pressure");
        field(s,"targetCritThreat",false);check(choose(l,own,target,true,view(l,13,4,true),s,null,-20,20,(x,z)->true)==null,"shield control remains excluded");

        // Wall positioning is a prior below the existing hard reach/collision rules.
        for(double z:new double[]{-9,9}) {
            Object h=choose(l,body(l,0,z,0,0),body(l,4,z,0,0),false,view(l,20,4,false),senses(l,4),null,-10,10,(x,side)->true);
            check(axis(h,"x")>=0&&Math.signum(axis(h,"z"))==-Math.signum(z),"near either side wall, own clearance takes priority over advance: "+z);
        }
        for(double x:new double[]{-9,9}) {
            double targetX=x-Math.signum(x)*4;
            Object h=choose(l,body(l,x,0,0,0),body(l,targetX,0,0,0),false,view(l,21,4,false),senses(l,4),null,-10,10,(forward,side)->true);
            check(Math.signum(axis(h,"x"))==-Math.signum(x)&&Math.abs(axis(h,"z"))<1e-9,"short rear runway prior advances toward open self space: "+x);
        }
        Object corner=choose(l,body(l,-9,9,0,0),body(l,-5,9,0,0),false,view(l,22,4,false),senses(l,4),null,-10,10,(x,z)->true);
        check(axis(corner,"x")>0&&axis(corner,"z")<0,"corner prior opens room from both adjacent walls");
        for(double z:new double[]{-4,4}) {
            Object h=choose(l,body(l,-4,z,0,0),body(l,0,z,0,0),false,view(l,23,4,false),senses(l,4),null,-20,20,(x,side)->true);
            check(Math.signum(axis(h,"z"))==-Math.signum(z),"with self runway reserved, optional flank points knockback toward the opposing wall/corner: "+z+"/"+h);
        }
        for(double[] p:new double[][]{{-9,0,-5,0},{9,0,5,0},{0,-9,0,-5},{0,9,0,5}})
            check(Math.abs(wall(l,"rearRunway",p[0],p[1],p[2],p[3],-10.,10.,-10.,10.)-1)<1e-9,"rear runway measures the wall behind own relative to opponent");
        check(Math.abs(wall(l,"rearRunway",-9.,-9.,-5.,-5.,-10.,10.,-10.,10.)-Math.sqrt(2))<1e-9,"diagonal rear runway uses the first arena wall");
        check(wall(l,"margin",0.,9.,-10.,10.,-10.,10.)==1,"wall clearance considers all four arena sides");
        double safeSpace=wall(l,"preference",0.,9.,4.,9.,.0693,8.9307,-10.,10.,-10.,10.,true);
        double opponentInward=wall(l,"preference",0.,9.,4.,9.,.0693,9.0693,-10.,10.,-10.,10.,true);
        check(safeSpace>opponentInward,"own missing wall reserve outranks the opposing inward-knockback preference");
        check(wall(l,"preference",0.,9.,4.,9.,.0693,8.9307,-10.,10.,-10.,10.,false)>0,"blocked rear probe still values restoring own wall clearance");
        check(wall(l,"preference",0.,0.,4.,0.,.098,0.,Double.NaN,10.,-10.,10.,true)==0,"invalid arena geometry supplies no positioning prior");

        // Exercise the existing cached branch, including adversarial choices at a hard boundary.
        Object tactics=l.make("ConstrainedTactics",new Class<?>[]{Path.class,long.class},root.resolve("never-written-test-model.nn"),991L);
        call(tactics,"freeze",new Class<?>[]{});v=view(l,100,3.4,false);s=senses(l,3.4);
        call(tactics,"begin",new Class<?>[]{l.type("CombatView"),l.type("NeuralLearner$Senses")},v,s);
        for(int action:new int[]{1,2,6,7,8,9}) {
            select(tactics,action);Object h=choose(l,own,target,false,v,s,tactics,-20,20,(x,z)->true);
            check(action<=2?axis(h,"x")>.99:(action==6||action==8)?axis(h,"z")<0:axis(h,"z")>0,"existing DQN advancing forward/left/right choice remains executable: "+action);
            check(lastSprint==(action==2||action==8||action==9),"walking/sprinting must exactly match the existing selected action: "+action);
            check(((boolean[])field(tactics,"used"))[9],"executed ground action retains existing DQN credit");
        }
        for(int action:new int[]{0,3,4,5,10,11}) {
            select(tactics,action);Object h=choose(l,own,target,true,v,s,tactics,-20,20,(x,z)->true);
            check(axis(h,"x")<=0,"far-range learned hold/side/retreat must remain executable: "+action);
        }
        call(tactics,"reset",new Class<?>[]{});v=view(l,150,4,false);s=senses(l,4);
        call(tactics,"begin",new Class<?>[]{l.type("CombatView"),l.type("NeuralLearner$Senses")},v,s);select(tactics,7);
        Object learnedWall=choose(l,body(l,0,9,0,0),body(l,4,9,0,0),false,v,s,tactics,-10,10,(x,z)->true);
        check(axis(learnedWall,"z")>0,"wall preference stays soft: a learned, hard-legal opposite flank remains executable");
        select(tactics,7);Object collisionWall=choose(l,body(l,0,9,0,0),body(l,4,9,0,0),false,v,s,tactics,-10,10,(x,z)->z<=0);
        check(axis(collisionWall,"z")<=0,"hard real-block clearance rejects a learned wall-facing flank before positioning prior");
        for(double reach:new double[]{3.001,3.04,3.10,3.14,3.5})for(boolean running:new boolean[]{false,true})for(int action:new int[]{0,1,2,3,4,5,6,7,8,9,10,11}) {
            Object tv=view(l,200,reach,false),ts=senses(l,reach);call(tactics,"reset",new Class<?>[]{});
            call(tactics,"begin",new Class<?>[]{l.type("CombatView"),l.type("NeuralLearner$Senses")},tv,ts);select(tactics,action);
            Object h=choose(l,own,target,running,tv,ts,tactics,-20,20,(x,z)->true);
            double inward=Math.max(0,axis(h,"x")*.098*(lastSprint?1.3:1));
            check(reach-inward>3,"learned/cached action cannot override a measured safe boundary: "+reach+"/"+action);
        }

        // The model schema is unchanged, but actual ground movement refreshes its
        // observation and sprint/side selection on each tick, retaining same-tick reuse.
        call(tactics,"reset",new Class<?>[]{});v=view(l,300,3.4,false);s=senses(l,3.4);
        call(tactics,"begin",new Class<?>[]{l.type("CombatView"),l.type("NeuralLearner$Senses")},v,s);select(tactics,8);
        Object left=choose(l,own,target,false,v,s,tactics,-20,20,(x,z)->true);
        check(lastSprint&&axis(left,"z")<0,"first tick executes learned sprint-left");
        check((long)field(tactics,"nextChoice")==301L,"executed ground movement opts into next-tick refresh");
        Object sameTick=choose(l,own,target,false,v,s,tactics,-20,20,(x,z)->true);
        check(lastSprint&&axis(sameTick,"z")==axis(left,"z"),"same ground tick retains one learned decision");
        v=view(l,301,4.5,false);s=senses(l,4.5);
        call(tactics,"begin",new Class<?>[]{l.type("CombatView"),l.type("NeuralLearner$Senses")},v,s);
        check((long)field(tactics,"selectedAt")==301L&&!((boolean[])field(tactics,"used"))[9],"next ground tick discards prior movement cache");
        check(Math.abs(((double[])field(tactics,"state"))[1]-.75)<1e-12,"ground state uses the current live reach observation");
        select(tactics,7);Object right=choose(l,own,target,true,v,s,tactics,-20,20,(x,z)->true);
        check(!lastSprint&&axis(right,"z")>0,"next tick executes independently learned walking-right");
        var motion=l.type("GroundFootwork").getDeclaredMethod("chooseMotion",l.type("PrecisionFootwork$Body"),l.type("PrecisionFootwork$Body"),
            boolean.class,double.class,double.class,double.class,double.class,BiPredicate.class,l.type("CombatView"),l.type("NeuralLearner$Senses"),l.type("ConstrainedTactics"));
        motion.setAccessible(true);Object choice=motion.invoke(null,own,target,true,-20.,20.,-20.,20.,(BiPredicate<Double,Double>)((x,z)->true),v,s,tactics);
        check((int)call(choice,"action",new Class<?>[]{})==7&&!(boolean)call(choice,"sprint",new Class<?>[]{}),"Choice exposes the executed action and independent sprint flag");
        check(axis(call(choice,"heading",new Class<?>[]{}),"z")>0,"Choice exposes the corresponding heading");

        // Ground opt-in must not shorten the existing four-tick cache in other phases.
        call(tactics,"reset",new Class<?>[]{});v=view(l,500,4,true);s=senses(l,4);
        call(tactics,"begin",new Class<?>[]{l.type("CombatView"),l.type("NeuralLearner$Senses")},v,s);
        call(tactics,"choose",new Class<?>[]{int.class,int.class},0,1);
        for(long tick:new long[]{501,503}) {
            call(tactics,"begin",new Class<?>[]{l.type("CombatView"),l.type("NeuralLearner$Senses")},view(l,tick,4,true),s);
            check((long)field(tactics,"selectedAt")==500L&&((boolean[])field(tactics,"used"))[0],"non-ground phases retain four-tick cached choices: "+tick);
        }
        call(tactics,"begin",new Class<?>[]{l.type("CombatView"),l.type("NeuralLearner$Senses")},view(l,504,4,true),s);
        check((long)field(tactics,"selectedAt")==504L,"non-ground cache expires at its original fourth tick");

        Object learning=l.make("ConstrainedTactics",new Class<?>[]{Path.class,long.class},root.resolve("never-written-training-model.nn"),992L);
        call(learning,"enable",new Class<?>[]{boolean.class},true);
        for(long tick=700;tick<=740;tick++) {
            v=view(l,tick,4,false);s=senses(l,4);
            call(learning,"begin",new Class<?>[]{l.type("CombatView"),l.type("NeuralLearner$Senses")},v,s);
            select(learning,tick%2==0?8:7);choose(l,own,target,false,v,s,learning,-20,20,(x,z)->true);
        }
        check((long)call(learning,"samples",new Class<?>[]{})==40L,"ground training retains one credited transition per executed tick");
        check((int)call(learning,"replaySize",new Class<?>[]{})==40,"ground transitions reach existing replay memory");
        check((long)call(learning,"updates",new Class<?>[]{})==16L,"existing DQN replay optimizer trains on per-tick movement transitions");
        for(Object sample:(Object[])field(learning,"replay"))if(sample!=null) {
            check((int)call(sample,"ticks",new Class<?>[]{})==1,"ground replay duration is exactly one tick");
            check(((boolean[])call(sample,"used",new Class<?>[]{}))[9],"ground replay assigns credit to the existing movement branch");
        }
        var inputs=l.type("ConstrainedTactics").getDeclaredField("INPUTS");inputs.setAccessible(true);
        var outputs=l.type("ConstrainedTactics").getDeclaredField("OUTPUTS");outputs.setAccessible(true);
        check(inputs.getInt(null)==62&&outputs.getInt(null)==53,"neural input/output dimensions remain model compatible");
        check(((int[])field(learning,"selected")).length==11,"existing 11 action branches remain unchanged");
        for(int profile=0;profile<2;profile++) {
            Object controller=l.make("InitialCombatController",new Class<?>[]{long.class,int.class},778L,profile);
            call(controller,"setTactics",new Class<?>[]{l.type("ConstrainedTactics")},tactics);
            call(tactics,"reset",new Class<?>[]{});Object ev=view(l,400,2.9,false),es=senses(l,2.9);
            field(es,"opportunity",value(l.type("OpportunityStrike$Kind"),"ENTRY"));field(es,"enteredReach",true);
            Object decision=call(controller,"decide",new Class<?>[]{l.type("CombatView"),l.type("NeuralLearner$Senses")},ev,es);
            check(decision.toString().contains("attack=true")&&call(controller,"name",new Class<?>[]{}).equals("ENTRY_HIT"),"ENTRY hard attack retains priority, profile="+profile);
            check(field(tactics,"state")==null,"ENTRY must execute before preparing neural movement state");
        }
        check(!Files.exists(root.resolve("never-written-test-model.nn"))&&!Files.exists(root.resolve("never-written-training-model.nn")),"test must never write model data");
        System.out.println("PASS: "+checks+" assertions; source compiled in memory; wall-clearance prior, no forced distant advance, short 0.3-block attack approach, learned walk/sprint and all directions, per-tick live ground state/replay, unchanged non-ground four-tick cache and 62/53/11 model layout, dual reach boundary, inertia, collisions/walls, ENTRY and jump priority. No jar/model/server writes.");
        System.out.println("INTEGRATION: chooseMotion returns Choice(heading,sprint,action); legacy choose and sprint callback remain available. Native caller must apply Choice.sprint or consume the callback as the actual sprint flag.");
    }
}

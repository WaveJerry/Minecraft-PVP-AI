package local.pvpbot.ai;

/** Pure state checks; does not load plugins, move entities or change model files. */
public final class PressureRecoveryCheck {
    private static int checks;

    private static void check(boolean condition, String message) {
        checks++;
        if (!condition) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        PressureRecovery recovery = new PressureRecovery();
        check(!recovery.recoveryActive(10, 0), "low charge alone must not arm recovery");
        check(!recovery.recoveryActive(10, 1), "a charged attempt must not arm recovery");
        check(recovery.activeSince() == PressureRecovery.NO_TICK, "inactive state has no hit tick");

        check(recovery.confirmedHit(10), "a confirmed damaging pressure hit arms recovery");
        check(recovery.activeSince() == 10, "record the actual confirmed hit tick");
        check(recovery.recoveryActive(10, 1), "same-tick stale full charge cannot release recovery");
        check(recovery.recoveryActive(10, PressureRecovery.FULL_CHARGE), "same-tick threshold charge cannot release recovery");
        check(!recovery.confirmedHit(10), "duplicate hit notification must be ignored");
        check(!recovery.confirmedHit(9), "late older hit notification must be ignored");
        check(recovery.activeSince() == 10, "duplicate and older hits must not move the recovery start");
        check(recovery.recoveryActive(11, .08), "actual post-hit low charge keeps recovery active");
        check(recovery.recoveryActive(14, .75), "partly recharged weapon keeps recovering");
        check(recovery.recoveryActive(20, .9989), "recovery lasts until actual full-charge threshold");
        check(!recovery.recoveryActive(21, .999), "actual fully recharged weapon releases recovery");
        check(recovery.activeSince() == PressureRecovery.NO_TICK, "released state clears the active hit tick");
        check(!recovery.confirmedHit(10), "a repeated completed hit must not rearm recovery");
        check(!recovery.recoveryActive(22, .2), "later unrelated low charge must not rearm recovery");

        check(recovery.confirmedHit(30), "a later confirmed pressure hit may arm another cycle");
        check(recovery.recoveryActive(30, 1.1), "same-hit protection applies to above-one charge too");
        check(recovery.recoveryActive(31, Double.NaN), "NaN charge cannot fake recharge");
        check(recovery.recoveryActive(32, Double.POSITIVE_INFINITY), "infinite charge cannot fake recharge");
        check(recovery.recoveryActive(1000, .5), "elapsed time must not fake weapon recharge");
        check(!recovery.recoveryActive(1001, 1), "a new ready weapon releases using its real charge");

        check(recovery.confirmedHit(1010), "another confirmed hit rearms recovery");
        check(recovery.confirmedHit(1011), "a new confirmed hit refreshes the recovery tick");
        check(recovery.activeSince() == 1011, "latest confirmed hit owns the current cycle");
        check(recovery.recoveryActive(1011, 1), "refresh hit cannot release on its own tick");
        recovery.reset();
        check(!recovery.recoveryActive(1012, .1), "lifecycle reset clears active recovery");
        check(recovery.activeSince() == PressureRecovery.NO_TICK, "lifecycle reset clears active tick");
        check(recovery.confirmedHit(1), "reset permits a new controller lifecycle tick sequence");
        check(recovery.recoveryActive(1, 1), "new lifecycle hit still recovers on its hit tick");
        check(!recovery.recoveryActive(2, 1), "new lifecycle releases on real recharge");

        System.out.println("PressureRecoveryCheck: " + checks + " checks passed");
    }
}

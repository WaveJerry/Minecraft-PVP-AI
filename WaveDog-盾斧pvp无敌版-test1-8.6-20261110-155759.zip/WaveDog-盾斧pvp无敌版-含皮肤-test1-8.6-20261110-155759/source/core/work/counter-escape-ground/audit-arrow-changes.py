from pathlib import Path
import zipfile,json,hashlib
b=Path(__file__).resolve().parent
old=b.parents[1]/'outputs/MC-Native-Critical-8.5/PvPArenaAI.jar'
with zipfile.ZipFile(old) as a,zipfile.ZipFile(b/'PvPArenaAI.jar') as n:
    changed=[f for f in a.namelist() if a.read(f)!=n.read(f)]
    added=[f for f in n.namelist() if f not in a.namelist()]
    allowed={'plugin.yml','local/pvpbot/ai/OffhandRangedSupport.class',
             'local/pvpbot/ai/ProjectileDefence.class','local/pvpbot/ai/ProjectileDefence$Plan.class'}
    assert set(changed)<=allowed,changed
    assert all(f.startswith('local/pvpbot/ai/ArrowEscapePlanner') or f.startswith('local/pvpbot/ai/ProjectileDefence$') for f in added),added
    report={'previous_version':'0.10.11-ground.8.5-duel.1','changed_entries':changed,'added_entries':added,
            'native_critical_and_other_combat_exact':True,'jar_sha256':hashlib.sha256((b/'PvPArenaAI.jar').read_bytes()).hexdigest()}
    (b/'arrow-change-audit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print('PASS only projectile input/solver changed from 8.5; other combat classes exact')

import java.nio.file.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** Exact native input hooks; old attack ray, damage and physics methods are retained. */
public final class PatchCounterGround {
    static final String P="local/pvpbot/ai/", MAIN=P+"PvPArenaAI";
    static ClassNode read(Path p)throws Exception { var n=new ClassNode();new ClassReader(Files.readAllBytes(p)).accept(n,0);return n; }
    static void write(ClassNode n,Path p)throws Exception {var w=new ClassWriter(ClassWriter.COMPUTE_MAXS);n.accept(w);Files.write(p,w.toByteArray());}
    static void controller(InsnList code,int ownSlot) {
        code.add(new VarInsnNode(Opcodes.ALOAD,0));code.add(new VarInsnNode(Opcodes.ALOAD,ownSlot));
        code.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL,MAIN,"brainFor","(Lorg/bukkit/entity/Player;)L"+MAIN+"$Brain;",false));
        code.add(new FieldInsnNode(Opcodes.GETFIELD,MAIN+"$Brain","learner","L"+P+"NeuralLearner;"));
        code.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL,P+"NeuralLearner","groundController","()L"+P+"InitialCombatController;",false));
    }
    static AbstractInsnNode previous(AbstractInsnNode n) {n=n.getPrevious();while(n!=null&&(n.getType()==AbstractInsnNode.LABEL||n.getType()==AbstractInsnNode.LINE||n.getType()==AbstractInsnNode.FRAME))n=n.getPrevious();return n;}
    public static void main(String[] args)throws Exception {
        var n=read(Path.of(args[0]));int sprint=0,confirmed=0,jumps=0,motion=0,before=0,after=0,guard=0,restore=0,position=0;
        int swordFlags=0,weaponGate=0,equipped=0,retreatWeapon=0,chargeGates=0;
        int preload=0,kitCapture=0,offhand=0,criticalKind=0,noTimedFollow=0,finalized=0;
        for(var m:n.methods) {
            if(m.name.equals("ambientArrowDefence")) {
                m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();
                m.instructions.add(new VarInsnNode(Opcodes.ALOAD,0));m.instructions.add(new VarInsnNode(Opcodes.ALOAD,1));m.instructions.add(new VarInsnNode(Opcodes.ALOAD,2));
                m.instructions.add(new MethodInsnNode(Opcodes.INVOKESTATIC,P+"OffhandRangedSupport","ambientDefence","(L"+MAIN+";Lorg/bukkit/entity/Player;L"+P+"CombatMemory;)Z",false));
                m.instructions.add(new InsnNode(Opcodes.IRETURN));
            }
            if(m.name.equals("opportunityWindow"))for(var insn:m.instructions.toArray())
                if(insn instanceof MethodInsnNode c&&c.owner.equals(P+"CounterFollow")&&c.name.equals("window")) {
                    // Keep initial shield counter and normal EXIT discovery, disable only
                    // the obsolete fixed-time follow input. Fall through to other openings.
                    var code=new InsnList();code.add(new InsnNode(Opcodes.POP));code.add(new InsnNode(Opcodes.ICONST_0));
                    m.instructions.insert(c,code);noTimedFollow++;
                }
            if(m.name.equals("restoreLayout"))for(var insn:m.instructions.toArray())
                if(insn instanceof MethodInsnNode call&&call.owner.equals("org/bukkit/entity/Player")&&call.name.equals("updateInventory")) {
                    var code=new InsnList();code.add(new VarInsnNode(Opcodes.ALOAD,1));
                    code.add(new MethodInsnNode(Opcodes.INVOKESTATIC,P+"RoundCrossbowKit","preload","(Lorg/bukkit/entity/Player;)V",false));
                    m.instructions.insertBefore(call,code);preload++;
                }
            if(m.name.equals("captureLayout"))for(var insn:m.instructions.toArray())
                if(insn instanceof MethodInsnNode call&&call.owner.equals(P+"KitLayout")&&call.name.equals("parse")) {
                    var code=new InsnList();code.add(new VarInsnNode(Opcodes.ALOAD,1));m.instructions.insertBefore(call,code);
                    m.instructions.set(call,new MethodInsnNode(Opcodes.INVOKESTATIC,P+"RoundCrossbowKit","capture","(Ljava/util/List;ILorg/bukkit/entity/Player;)L"+P+"KitLayout;",false));kitCapture++;
                }
            if(m.name.equals("selectWeapon") && m.desc.endsWith(";Z)V")) {
                var head=new InsnList();head.add(new VarInsnNode(Opcodes.ALOAD,3));controller(head,1);
                head.add(new MethodInsnNode(Opcodes.INVOKESTATIC,P+"CombatInputHooks","escapeWeapon","(L"+P+"Weapon;L"+P+"InitialCombatController;)L"+P+"Weapon;",false));
                head.add(new VarInsnNode(Opcodes.ASTORE,3));
                head.add(new VarInsnNode(Opcodes.ALOAD,1));controller(head,1);head.add(new VarInsnNode(Opcodes.ALOAD,0));head.add(new FieldInsnNode(Opcodes.GETFIELD,MAIN,"tick","J"));
                head.add(new MethodInsnNode(Opcodes.INVOKESTATIC,P+"CombatInputHooks","weaponEquipped","(Lorg/bukkit/entity/Player;L"+P+"InitialCombatController;J)V",false));
                m.instructions.insert(head);weaponGate++;
                for(var insn:m.instructions.toArray())if(insn instanceof MethodInsnNode c&&c.name.equals("setHeldItemSlot")) {
                    var code=new InsnList();code.add(new VarInsnNode(Opcodes.ALOAD,1));controller(code,1);
                    code.add(new VarInsnNode(Opcodes.ALOAD,0));code.add(new FieldInsnNode(Opcodes.GETFIELD,MAIN,"tick","J"));
                    code.add(new MethodInsnNode(Opcodes.INVOKESTATIC,P+"CombatInputHooks","weaponEquipped","(Lorg/bukkit/entity/Player;L"+P+"InitialCombatController;J)V",false));
                    m.instructions.insert(c,code);equipped++;
                }
            }
            if(m.name.equals("tickBrain")||m.name.equals("executeCombatFrame")) {
                for(var insn:m.instructions.toArray())if(insn instanceof MethodInsnNode c&&c.owner.equals(P+"MeleeSequence")&&c.name.equals("useEscapeSword")) {
                    var code=new InsnList();controller(code,m.name.equals("tickBrain")?2:1);m.instructions.insertBefore(c,code);
                    m.instructions.set(c,new MethodInsnNode(Opcodes.INVOKESTATIC,P+"CombatInputHooks","escapeSword","(L"+P+"MeleeSequence;ZL"+P+"InitialCombatController;)V",false));swordFlags++;
                }
            }
            if(m.name.equals("executeCombatFrame"))for(var insn:m.instructions.toArray())
                if(insn instanceof MethodInsnNode call&&call.owner.equals(MAIN)&&call.name.equals("resumeRetreatInputs")) {
                    var code=new InsnList();code.add(new VarInsnNode(Opcodes.ALOAD,0));code.add(new VarInsnNode(Opcodes.ALOAD,1));
                    code.add(new VarInsnNode(Opcodes.ALOAD,3));code.add(new FieldInsnNode(Opcodes.GETFIELD,MAIN+"$Brain","memory","L"+P+"CombatMemory;"));
                    code.add(new VarInsnNode(Opcodes.ALOAD,6));code.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL,P+"CombatDecision","weapon","()L"+P+"Weapon;",false));
                    code.add(new InsnNode(Opcodes.ICONST_1));code.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL,MAIN,"selectWeapon","(Lorg/bukkit/entity/Player;L"+P+"CombatMemory;L"+P+"Weapon;Z)V",false));
                    m.instructions.insertBefore(call,code);retreatWeapon++;
                }
            if(m.name.equals("meleeInput")||m.name.equals("onAttackInput"))for(var insn:m.instructions.toArray())
                if(insn instanceof MethodInsnNode c&&c.owner.equals(P+"OpportunityStrike")&&c.name.equals("chargeAllowed")) {
                    int own=m.name.equals("onAttackInput")?2:1, target=m.name.equals("onAttackInput")?4:2;
                    var code=new InsnList();code.add(new VarInsnNode(Opcodes.ALOAD,own));code.add(new VarInsnNode(Opcodes.ALOAD,target));controller(code,own);m.instructions.insertBefore(c,code);
                    m.instructions.set(c,new MethodInsnNode(Opcodes.INVOKESTATIC,P+"CombatInputHooks","chargeAllowed","(FZLorg/bukkit/entity/Player;Lorg/bukkit/entity/Entity;L"+P+"InitialCombatController;)Z",false));chargeGates++;
                }
            if(m.name.equals("observe"))for(var insn:m.instructions.toArray())
                if(insn instanceof MethodInsnNode c && c.owner.equals(P+"AirborneObservation")&&c.name.equals("finish")) {
                    c.owner=P+"PositioningObservation";position++;
                }
            if(m.name.equals("meleeInput")&&m.desc.contains("OpportunityStrike$Kind")) {
                var kind=new InsnList();kind.add(new VarInsnNode(Opcodes.ALOAD,4));controller(kind,1);
                kind.add(new MethodInsnNode(Opcodes.INVOKESTATIC,P+"CombatInputHooks","criticalOpportunity","(L"+P+"OpportunityStrike$Kind;L"+P+"InitialCombatController;)L"+P+"OpportunityStrike$Kind;",false));
                kind.add(new VarInsnNode(Opcodes.ASTORE,4));m.instructions.insert(kind);criticalKind++;
                for(var insn:m.instructions.toArray())if(insn instanceof MethodInsnNode c) {
                    if(c.owner.equals("org/bukkit/entity/Player")&&c.name.equals("isSprinting")) {
                        var extra=new InsnList();controller(extra,1);m.instructions.insertBefore(c,extra);
                        m.instructions.set(c,new MethodInsnNode(Opcodes.INVOKESTATIC,P+"CombatInputHooks","sprintForMelee","(Lorg/bukkit/entity/Player;L"+P+"InitialCombatController;)Z",false));sprint++;
                    }
                    if(c.owner.equals("org/bukkit/entity/Player")&&c.name.equals("attack")) {
                        var pre=new InsnList();controller(pre,1);pre.add(new VarInsnNode(Opcodes.ALOAD,3));
                        pre.add(new FieldInsnNode(Opcodes.GETFIELD,P+"CombatMemory","dealt","D"));
                        pre.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL,P+"InitialCombatController","beforeMelee","(D)V",false));m.instructions.insertBefore(c,pre);before++;
                        var post=new InsnList();controller(post,1);post.add(new VarInsnNode(Opcodes.ALOAD,3));post.add(new VarInsnNode(Opcodes.ALOAD,1));
                        post.add(new VarInsnNode(Opcodes.ALOAD,0));post.add(new FieldInsnNode(Opcodes.GETFIELD,MAIN,"tick","J"));
                        post.add(new MethodInsnNode(Opcodes.INVOKESTATIC,P+"CombatInputHooks","afterMelee","(L"+P+"InitialCombatController;L"+P+"CombatMemory;Lorg/bukkit/entity/Player;J)V",false));m.instructions.insert(c,post);after++;
                        var actual=new InsnList();controller(actual,1);m.instructions.insertBefore(c,actual);
                        m.instructions.set(c,new MethodInsnNode(Opcodes.INVOKESTATIC,P+"NativeMeleeReceipt","attack","(Lorg/bukkit/entity/Player;Lorg/bukkit/entity/Entity;L"+P+"InitialCombatController;)V",false));
                    }
                    if(c.owner.equals(P+"CounterFollow")&&c.name.equals("acceptedCounter")) {
                        var code=new InsnList();controller(code,1);code.add(new VarInsnNode(Opcodes.ALOAD,0));code.add(new FieldInsnNode(Opcodes.GETFIELD,MAIN,"tick","J"));
                        code.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL,P+"InitialCombatController","confirmedCounterHop","(J)V",false));m.instructions.insert(c,code);confirmed++;
                    }
                }
            }
            if(m.name.equals("executeCombatFrame")||m.name.equals("resumeRetreatInputs")) {
                for(var insn:m.instructions.toArray())if(insn instanceof FieldInsnNode f&&f.getOpcode()==Opcodes.PUTFIELD&&f.owner.equals(P+"CombatMemory")&&f.name.equals("lastJump")) {
                    var code=new InsnList();controller(code,1);code.add(new VarInsnNode(Opcodes.ALOAD,0));code.add(new FieldInsnNode(Opcodes.GETFIELD,MAIN,"tick","J"));
                    code.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL,P+"InitialCombatController","jumpInputSubmitted","(J)V",false));m.instructions.insert(f,code);jumps++;
                }
            }
            if(m.name.equals("precisionFootwork")) {
                for(var insn:m.instructions.toArray())if(insn instanceof MethodInsnNode c&&c.owner.equals(P+"SpacingRules")&&c.name.equals("headingMotion")) {
                    var first=insn.getNext();while(first.getOpcode()<0)first=first.getNext();
                    var speed=first.getNext();while(speed.getOpcode()<0)speed=speed.getNext();
                    if(first.getOpcode()!=Opcodes.ICONST_0||speed.getOpcode()!=Opcodes.ICONST_1)throw new IllegalStateException("Unexpected ground movement operands");
                    var code=new InsnList();code.add(new VarInsnNode(Opcodes.ILOAD,8));controller(code,1);
                    code.add(new MethodInsnNode(Opcodes.INVOKESTATIC,P+"CombatInputHooks","footworkSprint","(ZL"+P+"InitialCombatController;)Z",false));
                    m.instructions.insertBefore(speed,code);m.instructions.remove(speed);motion++;
                }
            }
            if(m.name.equals("executeCombatFrame")||m.name.equals("tickBrain")) {
                for(var insn:m.instructions.toArray())if(insn instanceof MethodInsnNode c&&c.owner.equals(MAIN)&&c.name.equals("selectWeapon")&&c.desc.endsWith(";Z)V")) {
                    var force=previous(c);if(force.getOpcode()!=Opcodes.ICONST_1)throw new IllegalStateException("Unexpected force argument in "+m.name);
                    var code=new InsnList();
                    if(m.name.equals("executeCombatFrame")) {
                        code.add(new VarInsnNode(Opcodes.ALOAD,1));code.add(new VarInsnNode(Opcodes.ALOAD,4));code.add(new VarInsnNode(Opcodes.ALOAD,5));
                        code.add(new MethodInsnNode(Opcodes.INVOKESTATIC,P+"CombatInputHooks","airborneGuardWeapon","(L"+P+"Weapon;Lorg/bukkit/entity/Player;L"+P+"CombatView;L"+P+"NeuralLearner$Senses;)L"+P+"Weapon;",false));guard++;
                    } else {
                        code.add(new VarInsnNode(Opcodes.ALOAD,2));code.add(new VarInsnNode(Opcodes.ALOAD,3));
                        code.add(new MethodInsnNode(Opcodes.INVOKESTATIC,P+"CombatInputHooks","keepGuardDuringTakeoff","(L"+P+"Weapon;Lorg/bukkit/entity/Player;Lorg/bukkit/entity/Player;)L"+P+"Weapon;",false));restore++;
                    }
                    m.instructions.insertBefore(force,code);
                }
            }
            if(m.name.equals("executeCombatFrame")) {
                for(var insn:m.instructions.toArray())if(insn.getOpcode()==Opcodes.RETURN) {
                    var restoreLine=new InsnList();restoreLine.add(new VarInsnNode(Opcodes.ALOAD,0));
                    restoreLine.add(new VarInsnNode(Opcodes.ALOAD,1));restoreLine.add(new VarInsnNode(Opcodes.ALOAD,3));
                    restoreLine.add(new FieldInsnNode(Opcodes.GETFIELD,MAIN+"$Brain","memory","L"+P+"CombatMemory;"));controller(restoreLine,1);
                    restoreLine.add(new VarInsnNode(Opcodes.ALOAD,2));restoreLine.add(new VarInsnNode(Opcodes.ALOAD,4));restoreLine.add(new VarInsnNode(Opcodes.ALOAD,5));
                    restoreLine.add(new MethodInsnNode(Opcodes.INVOKESTATIC,P+"CombatInputHooks","finishFrame","(L"+MAIN+";Lorg/bukkit/entity/Player;L"+P+"CombatMemory;L"+P+"InitialCombatController;Lorg/bukkit/entity/Player;L"+P+"CombatView;L"+P+"NeuralLearner$Senses;)V",false));
                    m.instructions.insertBefore(insn,restoreLine);finalized++;
                }
                var code=new InsnList();code.add(new VarInsnNode(Opcodes.ALOAD,0));code.add(new VarInsnNode(Opcodes.ALOAD,1));code.add(new VarInsnNode(Opcodes.ALOAD,2));
                code.add(new VarInsnNode(Opcodes.ALOAD,3));code.add(new FieldInsnNode(Opcodes.GETFIELD,MAIN+"$Brain","memory","L"+P+"CombatMemory;"));controller(code,1);
                code.add(new VarInsnNode(Opcodes.ALOAD,4));code.add(new VarInsnNode(Opcodes.ALOAD,5));code.add(new VarInsnNode(Opcodes.ALOAD,6));
                code.add(new VarInsnNode(Opcodes.ALOAD,0));code.add(new FieldInsnNode(Opcodes.GETFIELD,MAIN,"tick","J"));
                code.add(new MethodInsnNode(Opcodes.INVOKESTATIC,P+"OffhandRangedSupport","execute","(L"+MAIN+";Lorg/bukkit/entity/Player;Lorg/bukkit/entity/Player;L"+P+"CombatMemory;L"+P+"InitialCombatController;L"+P+"CombatView;L"+P+"NeuralLearner$Senses;L"+P+"CombatDecision;J)Z",false));
                var original=new LabelNode();code.add(new JumpInsnNode(Opcodes.IFEQ,original));code.add(new InsnNode(Opcodes.RETURN));code.add(original);code.add(new FrameNode(Opcodes.F_SAME,0,null,0,null));
                m.instructions.insert(code);offhand++;
            }
        }
        if(sprint!=1||confirmed!=1||jumps!=3||motion!=1||before!=1||after!=1||guard!=5||restore!=1||position!=1
                ||swordFlags!=5||weaponGate!=1||equipped!=1||retreatWeapon!=1||chargeGates!=2||preload!=1||kitCapture!=1||offhand!=1||criticalKind!=1||noTimedFollow!=1||finalized<1)
            throw new IllegalStateException("Hook counts "+sprint+"/"+confirmed+"/"+jumps+"/"+motion+"/"+before+"/"+after+"/"+guard+"/"+restore);
        write(n,Path.of(args[1]));
        var turn=read(Path.of(args[2]));int ready=0,critical=0;
        for(var m:turn.methods)if(m.name.equals("readyBeforeTurn"))for(var insn:m.instructions.toArray()) {
            if(insn instanceof MethodInsnNode c&&c.owner.equals(P+"OpportunityStrike")&&c.name.equals("chargeAllowed")) {
                var code=new InsnList();captured(code,"val$bot","Lorg/bukkit/entity/Player;");captured(code,"val$target","Lorg/bukkit/entity/Player;");turnController(code);
                m.instructions.insertBefore(c,code);m.instructions.set(c,new MethodInsnNode(Opcodes.INVOKESTATIC,P+"CombatInputHooks","chargeAllowed","(FZLorg/bukkit/entity/Player;Lorg/bukkit/entity/Entity;L"+P+"InitialCombatController;)Z",false));ready++;
            }
            if(insn instanceof LdcInsnNode ldc&&ldc.cst.equals(.999f)) {
                var compare=ldc.getNext();while(compare.getOpcode()<0)compare=compare.getNext();
                var jump=compare.getNext();while(jump.getOpcode()<0)jump=jump.getNext();
                if(compare.getOpcode()!=Opcodes.FCMPL||!(jump instanceof JumpInsnNode j)||j.getOpcode()!=Opcodes.IFLT)throw new IllegalStateException("Critical threshold shape changed");
                var code=new InsnList();captured(code,"val$bot","Lorg/bukkit/entity/Player;");turnController(code);code.add(new MethodInsnNode(Opcodes.INVOKESTATIC,P+"CombatInputHooks","criticalCharge","(FLorg/bukkit/entity/Player;L"+P+"InitialCombatController;)Z",false));
                m.instructions.insertBefore(ldc,code);m.instructions.remove(ldc);m.instructions.remove(compare);j.setOpcode(Opcodes.IFEQ);critical++;
            }
        }
        if(ready!=1||critical!=1)throw new IllegalStateException("Expected exactly one turn charge gate and one critical threshold");
        write(turn,Path.of(args[3]));
        System.out.println("PASS: exact native sprint, confirmed counter/single-hop, real damage recovery, three actual jump notifications, learned sprint execution and shield-preserving weapon hooks");
    }
    static void captured(InsnList code,String name,String type) {
        code.add(new VarInsnNode(Opcodes.ALOAD,0));code.add(new FieldInsnNode(Opcodes.GETFIELD,MAIN+"$1",name,type));
    }
    static void turnController(InsnList code) {
        captured(code,"val$brain","L"+MAIN+"$Brain;");
        code.add(new FieldInsnNode(Opcodes.GETFIELD,MAIN+"$Brain","learner","L"+P+"NeuralLearner;"));
        code.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL,P+"NeuralLearner","groundController","()L"+P+"InitialCombatController;",false));
    }
}

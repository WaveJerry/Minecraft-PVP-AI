/*
 * Decompiled with CFR 0.152.
 */
package local.pvpbot.ai;

import java.util.Random;
import local.pvpbot.ai.AttackTiming;
import local.pvpbot.ai.CenterBias;
import local.pvpbot.ai.CombatDecision;
import local.pvpbot.ai.CombatView;
import local.pvpbot.ai.ConstrainedTactics;
import local.pvpbot.ai.Motion;
import local.pvpbot.ai.NeuralLearner;
import local.pvpbot.ai.OffhandMode;
import local.pvpbot.ai.OpportunityStrike;
import local.pvpbot.ai.PrecisionSpacing;
import local.pvpbot.ai.RangeControl;
import local.pvpbot.ai.RangedReadiness;
import local.pvpbot.ai.Technique;
import local.pvpbot.ai.Weapon;

final class InitialCombatController {
    private final Random random;
    private final CounterEscapeHop counterHop = new CounterEscapeHop();
    record FlightLook(float yaw,float pitch) {}
    private FlightLook flightLook;
    void rememberFlightLook(float yaw,float pitch) {
        this.flightLook=this.counterHop.active()&&this.meleeRequested()?new FlightLook(yaw,pitch):null;
    }
    FlightLook takeFlightLook() { var result=this.flightLook;this.flightLook=null;return result; }
    private final GroundCombo groundCombo = new GroundCombo();
    private boolean targetGrounded;
    private int targetImmunity=20,targetMaximumImmunity=20;
    private long decisionTick, contactReplyAt=-1000, contactReplyRequestedAt=-1000;
    void combatObservation(boolean grounded,int immunity,int maximum) {
        this.targetGrounded=grounded;
        this.targetImmunity=immunity;this.targetMaximumImmunity=maximum;
    }
    boolean comboStrike() { return this.phase==Phase.COMBO_EDGE; }
    boolean contactReply() { return this.phase==Phase.CONTACT_REPLY; }
    private boolean emergencyJump;
    private boolean groundSprint = true;
    private boolean sprintKnockback;
    private final PressureRecovery pressureRecovery = new PressureRecovery();
    private boolean escapeSwordHeld, axeSwitchPending, axeSwitchRecovery;
    private float hopNativeCharge = Float.NaN;
    private double hopNativeVelocityY = Double.NaN;
    private OpportunityStrike.Kind hopCriticalOpportunity = OpportunityStrike.Kind.NONE;
    private boolean targetLoadingCrossbow;
    private long wallReplyRequestedAt=-1000, wallReplyHandledAt=-1000;
    private boolean closeReplyUsed;
    private boolean hopFinishPending, hopCriticalAtExit;
    private TradeJump.Plan tradePlan, activeTrade, tradePlanAfterHit;
    private boolean landingTradePending;
    private boolean restartTradeHop;
    private ExchangeFootwork.Heading exchangeHeading;
    private long tradeStarted=-1000, lastCriticalTaken=-1000, nextAdvance;
    private long synchronizedAttackAt=-1000;
    private long exchangeShieldRecoveredAt=-1000;
    private boolean synchronizedCritical;
    private boolean tradeAirborne, tradeJumpSubmitted, tradeRestore, tradeLastWindow, tradeBlocked, tradeShieldHold, shortAdvanceAvailable;
    private long advanceUntil=-1000;
    private boolean advanceGuarded, advanceShieldRace;
    private int advanceContactTicks=-1, targetShieldDelay=-1;
    boolean mayPlanTrade() { return this.landingTradePending && !this.counterHop.active() && this.activeTrade==null; }
    boolean mayPlanLandingTrade(boolean grounded) {
        return this.mayPlanTrade() || grounded && this.counterHop.active() && this.counterHop.wasAirborne();
    }
    boolean landingTradePending() { return this.landingTradePending; }
    boolean synchronizedExchange() { return this.landingTradePending||this.activeTrade!=null; }
    boolean exchangeShieldGrace() {
        return this.exchangeShieldRecoveredAt>=0&&this.decisionTick-this.exchangeShieldRecoveredAt<6;
    }
    private void updateExchangeShield(CombatView view) {
        if(!view.ownShieldAvailable()){this.exchangeShieldRecoveredAt=-1000;return;}
        if(this.synchronizedExchange()&&this.exchangeShieldRecoveredAt<0)this.exchangeShieldRecoveredAt=view.tick();
        if(this.exchangeShieldRecoveredAt>=0&&view.tick()-this.exchangeShieldRecoveredAt>=6) {
            this.exchangeShieldRecoveredAt=-1000;this.landingTradePending=false;
            this.activeTrade=this.tradePlanAfterHit=null;this.tradeRestore=false;
            this.counterHop.blocked();this.counterFlight=this.escapeObserved=false;
            this.exitControl=false;this.escapeSwordHeld=false;this.pressureRecovery.reset();
        }
    }
    void opponentAttack(long tick,boolean critical) { this.synchronizedAttackAt=tick;this.synchronizedCritical=critical; }
    CombatDecision synchronizedAttack(CombatView view,boolean critical) {
        if(!this.synchronizedExchange())return null;
        this.sprintKnockback=!critical;
        return this.input(critical?Phase.TRADE_CRIT:Phase.CONTACT_REPLY,view,critical?1:2,false,true,
            this.currentMelee,false,critical?Technique.FALL_CRIT:Technique.AXE_EARLY);
    }
    boolean exchangeWaiting() { return this.phase==Phase.TRADE_WAIT&&this.landingTradePending; }
    ExchangeFootwork.Heading exchangeHeading() { return this.exchangeHeading; }
    boolean consumeTradeHopRestart() { boolean value=this.restartTradeHop;this.restartTradeHop=false;return value; }
    void exchangeHeading(ExchangeFootwork.Heading heading) { this.exchangeHeading=heading; }
    boolean synchronizeTrade(TradeJump.Plan plan,long tick) {
        if(!this.mayPlanTrade()||plan==null)return false;
        this.activeTrade=plan;this.tradeStarted=tick;
        this.tradeAirborne=this.tradeJumpSubmitted=false;this.pressureRecovery.reset();return true;
    }
    void cancelSynchronizedTrade() { this.activeTrade=null;this.tradeJumpSubmitted=false; }
    void shortAdvanceAvailable(boolean value) { this.shortAdvanceAvailable=value; }
    void shortAdvanceTiming(int contactTicks,int shieldDelay) {
        this.advanceContactTicks=contactTicks;this.targetShieldDelay=shieldDelay;
    }
    void tradeObservation(TradeJump.Plan plan,long critical,boolean lastWindow,boolean shield) {
        this.tradePlan=plan;this.lastCriticalTaken=critical;this.tradeLastWindow=lastWindow;this.tradeBlocked=shield;
        if(!shield)this.tradeShieldHold=false;
    }
    boolean proactiveStrike() { return this.phase==Phase.ACTIVE_STRIKE; }
    boolean exchangeCritical() { return this.phase==Phase.TRADE_CRIT; }
    boolean exchangeAttack() { return this.exchangeCritical() || this.phase==Phase.CONTACT_REPLY && this.tradeRestore; }
    boolean criticalIntent() { return this.phase==Phase.HOP_CRIT || this.phase==Phase.TRADE_CRIT; }
    String phaseName() { return this.phase.name(); }
    boolean shieldPressure() { return this.phase==Phase.SHIELD_PRESS; }
    boolean exchangeMotion() { return this.activeTrade!=null||this.tradeRestore; }
    boolean exchangeSucceeded() { return this.tradeRestore; }
    boolean advanceActive() { return this.phase==Phase.ACTIVE_ADVANCE||this.phase==Phase.ACTIVE_STRIKE; }
    TradeJump.Plan exchangePlan() { return this.activeTrade!=null?this.activeTrade:this.tradePlanAfterHit; }
    void frameRestored() { this.tradeRestore=false;this.tradePlanAfterHit=null; }
    private double damageBeforeMelee;
    private boolean nativeOutcomeKnown, nativeDamage, nativeCritical;
    void nativeMeleeOutcome(boolean damage,boolean critical) {
        this.nativeOutcomeKnown=true;this.nativeDamage=damage;this.nativeCritical=damage&&critical;
    }
    private int guardPositionPrior, guardSidePrior;
    private final int profile;
    private ConstrainedTactics tactics;
    private int drawRequired = 20;
    private Weapon rangedSelection;
    private Weapon currentMelee = Weapon.AXE;
    private int rangedSelectionShot = -1;
    private long nextRouteChoice;
    private boolean learnedControl;
    private boolean counterFlight;
    private boolean escapeObserved;
    private boolean exitControl;
    private long observedCounterAxe = -1000L;
    private Phase phase = Phase.SEARCH;
    private long since;
    private long consumedBlock = -1000L;
    private long requestedBlock = -1000L;
    private long sideUntil;
    private int lastMove;
    private double centerDistance;
    private double centerSide;
    private boolean left;
    private boolean reloadSeeking;
    private boolean openingSeen;
    private boolean takeOpening;
    private long reloadStarted;
    private long nextReloadTry;
    private long nextSuppressionTry;
    private long nextOrbit;
    private long orbitUntil;
    private long lastOpeningSample = -1000L;
    private CombatDecision decision;
    private double orbitGoal;
    static final int ORBIT_MAX_TICKS = 5;
    static final double ORBIT_CHANCE = 0.45;
    static final int ORBIT_RETRY_TICKS = 8;

    boolean controlAfterExit() {
        return this.exitControl && !this.pressureRecovering();
    }

    boolean groundSprint() { return this.groundSprint; }
    void guardPositionPrior(int advance, int side) { this.guardPositionPrior = advance; this.guardSidePrior = side; }
    boolean sprintKnockbackInput() { return this.sprintKnockback; }
    boolean pressureRecovering() { return this.pressureRecovery.activeSince() != PressureRecovery.NO_TICK; }
    void beforeMelee(double damageDealt) {
        this.damageBeforeMelee = damageDealt;
        this.nativeOutcomeKnown=this.nativeDamage=this.nativeCritical=false;
    }
    boolean keepEscapeSword() { return this.escapeSwordHeld; }
    boolean needsAxeSwitch() { return this.axeSwitchPending; }
    boolean closeRechargeReply() { return this.phase == Phase.RECHARGE_REPLY && !this.closeReplyUsed; }
    boolean wallDamageReply() { return this.phase==Phase.WALL_TRADE && this.wallReplyRequestedAt>this.wallReplyHandledAt; }
    boolean hopCriticalCharge(float charge) { return (this.phase == Phase.HOP_CRIT || this.phase==Phase.TRADE_CRIT) && Float.isFinite(charge) && charge > .9f; }
    OpportunityStrike.Kind criticalOpportunity(OpportunityStrike.Kind requested) {
        return this.phase == Phase.HOP_CRIT && requested == OpportunityStrike.Kind.NONE ? this.hopCriticalOpportunity : requested;
    }
    void meleeAttemptFinished(long tick, double damageDealt, boolean followAlsoExit) {
        boolean ordinaryLandingTrade=this.landingTradePending&&this.phase==Phase.CONTACT_REPLY;
        boolean damage=this.nativeOutcomeKnown?this.nativeDamage:damageDealt>this.damageBeforeMelee;
        boolean critical=damage&&this.nativeOutcomeKnown&&this.nativeCritical;
        if(this.phase==Phase.HOP_CRIT&&critical)this.counterHop.criticalSubmitted();
        if(damage && (this.phase==Phase.ACTIVE_STRIKE
                || this.phase==Phase.PRESSURE_STRIKE || this.phase==Phase.EDGE_HIT
                || this.phase==Phase.CONTACT_REPLY || this.phase==Phase.COMBO_EDGE))this.groundCombo.hit(tick);
        if(damage&&this.phase==Phase.CONTACT_REPLY) {
            this.contactReplyAt=Math.max(this.contactReplyAt,this.contactReplyRequestedAt);
            this.pressureRecovery.confirmedHit(tick);this.exitControl=true;
            this.landingTradePending=false;
        }
        if(this.activeTrade!=null && (this.phase==Phase.TRADE_CRIT && critical || this.phase==Phase.CONTACT_REPLY && damage)) {
            this.tradePlanAfterHit=this.activeTrade;this.tradeRestore=true;this.activeTrade=null;
            this.counterFlight=this.escapeObserved=false;this.exitControl=true;this.pressureRecovery.reset();
            this.landingTradePending=false;
        }
        if(this.phase==Phase.TRADE_CRIT&&critical)this.landingTradePending=false;
        if(this.phase==Phase.ACTIVE_STRIKE) {
            this.advanceUntil=-1000;this.nextAdvance=tick+12;
            if(damageDealt>this.damageBeforeMelee&&!this.advanceGuarded) {
                this.pressureRecovery.confirmedHit(tick);this.exitControl=true;
            }
        }
        if (this.phase == Phase.WALL_TRADE) this.wallReplyHandledAt=this.wallReplyRequestedAt;
        if (this.phase == Phase.RECHARGE_REPLY) this.closeReplyUsed = true;
        if (this.counterHop.active() && damage
                && (this.phase == Phase.TURN_EXIT || this.phase == Phase.COUNTER_EXIT && followAlsoExit
                     || this.phase == Phase.HOP_CRIT && critical && (this.hopCriticalAtExit || followAlsoExit))) this.hopFinishPending = true;
        if(ordinaryLandingTrade&&damage) {
            this.confirmedCounterHop(tick);this.restartTradeHop=true;
        }
    }
    void hopCriticalObservation(float charge, double velocityY) { this.hopNativeCharge = charge; this.hopNativeVelocityY = velocityY; }
    void axeEquipped(long tick) {
        if (!this.axeSwitchPending) return;
        this.axeSwitchPending = false;
        this.pressureRecovery.weaponChanged(tick);
    }
    void confirmedPressureDamage(long tick, double damageDealt) {
        if (this.phase != Phase.PRESSURE_STRIKE || !(damageDealt > this.damageBeforeMelee)) return;
        this.pressureRecovery.confirmedHit(tick);
        this.closeReplyUsed = false;
        this.exitControl = true;
        this.counterFlight = this.escapeObserved = false;
    }

    boolean allowJumpInput(long counterTick) {
        if(this.activeTrade!=null)return !this.tradeJumpSubmitted;
        return this.counterHop.allowsJump() && (this.emergencyJump || !this.exitControl || counterTick > this.observedCounterAxe);
    }

    void confirmedCounterHop(long tick) {
        this.groundCombo.reset();
        this.landingTradePending=false;this.restartTradeHop=false;this.exchangeHeading=null;
        this.synchronizedAttackAt=-1000;this.synchronizedCritical=false;
        this.activeTrade=this.tradePlanAfterHit=null;this.tradeRestore=false;this.advanceUntil=-1000;
        this.pressureRecovery.reset();
        this.counterHop.arm(tick);
        this.escapeSwordHeld = true;
        this.hopFinishPending = this.hopCriticalAtExit = false;
        this.closeReplyUsed = false;
        this.axeSwitchPending = this.axeSwitchRecovery = false;
        this.observedCounterAxe = tick;
        this.counterFlight = true;
        this.escapeObserved = true;
        this.exitControl = false;
    }

    void jumpInputSubmitted(long tick) { this.counterHop.jumpSubmitted(tick);if(this.activeTrade!=null)this.tradeJumpSubmitted=true; }
    boolean counterHopActive() { return this.counterHop.active(); }
    void targetLoadingCrossbow(boolean loading) { this.targetLoadingCrossbow = loading; }
    boolean meleeRequested() { return this.decision != null && this.decision.attack(); }


    boolean allowPlannedJump(NeuralLearner.Senses s) {
        if(this.activeTrade!=null)return !this.tradeJumpSubmitted;
        if (!this.counterHop.allowsJump()) return false;
        if (this.counterHop.active()) return !s.retreatBlocked;
        if (s.ownShieldCooldown > 0 && s.targetMotionFresh && s.targetAirborne && s.targetY > 0
                && !s.retreatBlocked && s.jumpSpace != null && s.jumpSpace.threat() && s.jumpSpace.jump()) return true;
        boolean newCounter=s.counterAxeHitTick>=0 && s.counterAxeHitTick>this.observedCounterAxe;
        boolean escaping=newCounter || this.counterFlight || this.escapeObserved || s.withdrawing;
        boolean crossed=s.estimateAge<=1 && Double.isFinite(s.ownReachDistance)
            && Double.isFinite(s.targetReachDistance) && s.ownReachDistance>3 && s.targetReachDistance>3;
        return escaping && (newCounter || !this.exitControl) && !crossed;
    }

    private void observeDisengagement(CombatView combatView, NeuralLearner.Senses senses) {
        boolean completingHop = this.counterHop.active();
        if (this.hopFinishPending) { this.counterHop.acceptExit(); this.hopFinishPending = false; }
        this.counterHop.observe(combatView.tick(), senses.onGround);
        if (completingHop && !this.counterHop.active()) {
            // Exactly one complete hop, even when a pursuer remains close on landing.
            this.counterFlight = this.escapeObserved = false;
            this.exitControl = true;
            this.orbitUntil = 0L;
            // The only entry into this exchange mode: the one counter-escape hop
            // physically ended and the target is still inside our real 3-block reach.
            this.landingTradePending=this.counterHop.wasAirborne()&&senses.onGround
                &&combatView.visible()&&senses.estimateAge<=1
                &&Double.isFinite(senses.ownReachDistance)&&senses.ownReachDistance<=3;
        }
        if(this.landingTradePending&&senses.estimateAge<=1&&Double.isFinite(senses.ownReachDistance)&&senses.ownReachDistance>3)
            this.landingTradePending=false;
        if (senses.counterAxeHitTick >= 0L && senses.counterAxeHitTick > this.observedCounterAxe) {
            this.observedCounterAxe = senses.counterAxeHitTick;
            this.counterFlight = true;
            this.escapeObserved = true;
            this.exitControl = false;
        }
        if (!this.counterHop.active() && (this.counterFlight || this.escapeObserved || senses.withdrawing) && combatView.visible() && senses.estimateAge <= 1.0 && Double.isFinite(senses.ownReachDistance) && Double.isFinite(senses.targetReachDistance) && senses.ownReachDistance > 3.0 && senses.targetReachDistance > 3.0) {
            this.counterFlight = false;
            this.escapeObserved = false;
            this.exitControl = true;
            this.orbitUntil = 0L;
        }
        if (this.escapeSwordHeld && !this.counterHop.active() && senses.onGround
                && combatView.visible() && senses.estimateAge <= 1
                && Double.isFinite(senses.ownReachDistance) && Double.isFinite(senses.targetReachDistance)
                && senses.ownReachDistance > 3 && senses.targetReachDistance > 3) {
            this.escapeSwordHeld = false;
            this.axeSwitchPending = this.axeSwitchRecovery = true;
            this.pressureRecovery.weaponChanged(combatView.tick());
        }
    }

    void setTactics(ConstrainedTactics constrainedTactics) {
        this.tactics = constrainedTactics;
    }

    PrecisionFootwork.Heading groundHeading(PrecisionFootwork.Body own, PrecisionFootwork.Body target,
            boolean sprint, double minX, double maxX, double minZ, double maxZ,
            java.util.function.BiPredicate<Double,Double> clear, CombatView view, NeuralLearner.Senses senses) {
        var choice = GroundFootwork.chooseMotion(own,target,sprint,minX,maxX,minZ,maxZ,clear,view,senses,this.tactics);
        this.groundSprint = choice != null && choice.sprint();
        return choice == null ? null : choice.heading();
    }

    int requiredDrawTicks() {
        return this.drawRequired;
    }

    private int soft(int n, int n2) {
        return this.tactics == null ? n2 : this.tactics.choose(n, n2);
    }

    InitialCombatController(long l) {
        this(l, (int)(l & 1L));
    }

    InitialCombatController(long l, int n) {
        this.random = new Random(l);
        this.profile = n & 1;
    }

    void reset() {
        this.flightLook=null;
        this.groundCombo.reset();
        this.landingTradePending=false;this.restartTradeHop=false;this.exchangeHeading=null;
        this.synchronizedAttackAt=-1000;this.synchronizedCritical=false;
        this.exchangeShieldRecoveredAt=-1000;
        this.tradeShieldHold=false;this.contactReplyRequestedAt=-1000;
        this.targetGrounded=false;this.targetImmunity=this.targetMaximumImmunity=20;
        this.decisionTick=0;this.contactReplyAt=this.contactReplyRequestedAt=-1000;
        this.tradePlan=this.activeTrade=this.tradePlanAfterHit=null;
        this.tradeStarted=this.lastCriticalTaken=this.advanceUntil=-1000;
        this.nextAdvance=0;
        this.advanceContactTicks=this.targetShieldDelay=-1;this.advanceShieldRace=false;
        this.tradeAirborne=this.tradeJumpSubmitted=this.tradeRestore=this.tradeLastWindow=this.tradeBlocked=this.shortAdvanceAvailable=false;
        this.counterHop.reset();
        this.pressureRecovery.reset();
        this.escapeSwordHeld = this.axeSwitchPending = this.axeSwitchRecovery = false;
        this.closeReplyUsed = false;
        this.hopFinishPending = this.hopCriticalAtExit = false;
        this.hopNativeCharge = Float.NaN;
        this.hopNativeVelocityY = Double.NaN;
        this.hopCriticalOpportunity = OpportunityStrike.Kind.NONE;
        this.wallReplyRequestedAt=this.wallReplyHandledAt=-1000;
        this.targetLoadingCrossbow = false;
        this.emergencyJump = this.sprintKnockback = false;
        this.groundSprint = true;
        this.guardPositionPrior = this.guardSidePrior = 0;
        this.phase = Phase.SEARCH;
        this.since = 0L;
        this.exitControl = false;
        this.escapeObserved = false;
        this.counterFlight = false;
        this.observedCounterAxe = -1000L;
        this.nextRouteChoice = 0L;
        this.learnedControl = false;
        this.drawRequired = 20;
        this.rangedSelection = null;
        this.rangedSelectionShot = -1;
        this.requestedBlock = -1000L;
        this.consumedBlock = -1000L;
        this.sideUntil = 0L;
        this.lastMove = 0;
        this.takeOpening = false;
        this.openingSeen = false;
        this.reloadSeeking = false;
        this.decision = null;
        this.orbitUntil = 0L;
        this.nextOrbit = 0L;
        this.nextSuppressionTry = 0L;
        this.nextReloadTry = 0L;
        this.reloadStarted = 0L;
        this.lastOpeningSample = -1000L;
    }

    String name() {
        return this.phase.name();
    }

    long age(long l) {
        return Math.max(0L, l - this.since);
    }

    boolean passBurst() {
        return false;
    }

    boolean passActive() {
        return false;
    }

    int passChoice() {
        return 1;
    }

    boolean briefOrbit(long l) {
        return this.phase == Phase.ORBIT_BURST && l < this.orbitUntil;
    }

    void finishOrbit() {
        this.orbitUntil = 0L;
    }

    int movementAction() {
        return this.lastMove;
    }

    boolean turnToStrike() {
        return this.decision != null && (this.decision.attack() || this.decision.shield());
    }

    boolean retreatTurn() {
        return this.phase == Phase.TURN_EXIT || this.phase == Phase.COUNTER_EXIT || this.phase == Phase.COUNTER || this.phase == Phase.TURN_TRADE;
    }

    void attackSubmitted() {
        if (this.requestedBlock >= 0L) {
            this.consumedBlock = Math.max(this.consumedBlock, this.requestedBlock);
        }
        this.requestedBlock = -1000L;
    }

    private void stage(Phase phase, long l) {
        if (this.phase != phase) {
            this.phase = phase;
            this.since = l;
        }
    }

    private int side(long l) {
        if (l >= this.sideUntil) {
            int n = CenterBias.preferredSide(this.centerDistance, this.centerSide);
            int n2 = this.soft(0, n != 2 && this.random.nextDouble() < 0.7 ? n : 2);
            this.left = n2 == 2 ? this.random.nextBoolean() : n2 == 0;
            this.sideUntil = l + 8L + (long)this.random.nextInt(9);
        }
        return this.left ? 4 : 5;
    }

    private boolean contact(CombatView combatView, NeuralLearner.Senses senses) {
        return combatView.visible() && senses.estimateAge <= 1.0 && Double.isFinite(senses.ownReachDistance) && senses.ownReachDistance >= 0.0 && senses.ownReachDistance <= 3.0 && senses.weaponInputReady && senses.ownWeapon == (this.escapeSwordHeld || senses.escapeSword && !this.exitControl ? 1 : 0);
    }

    private boolean interruptReady(CombatView combatView, NeuralLearner.Senses senses) {
        return this.contact(combatView, senses) && (combatView.ownAttackCharge() >= 0.999f || senses.opportunity == OpportunityStrike.Kind.RISE_INTERRUPT || senses.opportunity == OpportunityStrike.Kind.ENTRY
                || !combatView.ownShieldAvailable() && senses.opportunity != OpportunityStrike.Kind.NONE);
    }

    private CombatDecision interrupt(CombatView combatView, NeuralLearner.Senses senses) {
        this.orbitUntil = 0L;
        return this.input(Phase.AIR_INTERRUPT, combatView, 2, false, true, Weapon.AXE, false, Technique.AXE_EARLY);
    }

    private boolean ready(CombatView combatView, NeuralLearner.Senses senses) {
        return this.contact(combatView, senses) && combatView.ownAttackCharge() >= 0.999f;
    }

    private boolean blockPending(NeuralLearner.Senses senses) {
        return senses.lastBlockTick >= 0L && senses.lastBlockTick > this.consumedBlock && senses.blockedMeleeAge >= 0.0 && senses.blockedMeleeAge <= 6.0;
    }

    private boolean exposed(CombatView combatView, NeuralLearner.Senses senses) {
        return !senses.targetShieldRaised && !combatView.targetBlocking() || senses.targetFacingDot < -0.05;
    }
    private static boolean canDodge(ArrowDodgePlanner.Result plan) {
        for (int i=0;i<plan.safeMoves().length;i++) if (plan.safeMoves()[i] && plan.viableMoves()[i]) return true;
        return false;
    }

    private boolean fair(NeuralLearner.Senses senses) {
        return !senses.targetCritThreat || senses.comboPursuit;
    }

    private int spacing(CombatView combatView, NeuralLearner.Senses senses, boolean bl) {
        if (!combatView.ownShieldAvailable() && !AirborneEnvelope.relevant(senses)) {
            // Actual ground heading is selected at the movement boundary, after hard rules.
            return 0;
        }
        if (senses.retreatBlocked) {
            return RangeControl.center(senses);
        }
        int n = this.side(combatView.tick());
        int n2 = RangeControl.choose(combatView, senses, bl, n);
        if (bl) {
            return n2;
        }
        int n3 = PrecisionSpacing.refine(combatView, senses, n2, n);
        if (!combatView.ownShieldAvailable() && Math.min(senses.ownReachDistance, senses.targetReachDistance)
                + Math.min(0.0, senses.separationSpeed) * 3.0 <= 3.05) {
            return n3; // A learned route must not overwrite immediate boundary control.
        }
        int n4 = this.soft(8, 1);
        if (n4 == 0 && !senses.targetCritThreat && senses.ownReachDistance > 3.1 && senses.ownReachDistance < 4.2) {
            return n == 4 ? 6 : 7;
        }
        if (n4 == 2 && senses.separationSpeed < -0.02) {
            return n == 4 ? 10 : 11;
        }
        return n3;
    }

    private int pressureMove(CombatView combatView, NeuralLearner.Senses senses) {
        if (senses.retreatBlocked) {
            return RangeControl.center(senses);
        }
        int n = this.guardSidePrior != 0 ? this.guardSidePrior : this.side(combatView.tick());
        if (senses.collisionOverlap || senses.ownReachDistance <= 0.65) {
            return n;
        }
        int n2 = this.soft(10, 1);
        return n2 == 0 ? (this.guardPositionPrior != 0 ? this.guardPositionPrior : 1)
            : (n2 == 2 && senses.ownReachDistance < 1.5 ? n
            : this.guardPositionPrior != 0 ? this.guardPositionPrior : (n == 4 ? 6 : 7));
    }

    private CombatDecision input(Phase phase, CombatView combatView, int n, boolean bl, boolean bl2, Weapon weapon, boolean bl3, Technique technique) {
        if(phase!=Phase.ACTIVE_ADVANCE&&phase!=Phase.ACTIVE_STRIKE)this.advanceUntil=-1000;
        bl3 &= this.activeTrade!=null ? !this.tradeJumpSubmitted : this.counterHop.allowsJump() && (this.emergencyJump || !this.exitControl && (this.counterFlight || this.escapeObserved));
        if (weapon == Weapon.AXE) {
            weapon = this.currentMelee;
        }
        this.stage(phase, combatView.tick());
        this.lastMove = n;
        Motion motion = switch (n) {
            case 1, 2, 12, 17 -> Motion.FORWARD;
            case 3, 15 -> Motion.BACKWARD;
            case 4, 13 -> Motion.LEFT;
            case 5, 14 -> Motion.RIGHT;
            case 6, 8 -> Motion.FORWARD_LEFT;
            case 7, 9 -> Motion.FORWARD_RIGHT;
            case 10 -> Motion.BACKWARD_LEFT;
            case 11 -> Motion.BACKWARD_RIGHT;
            default -> Motion.HOLD;
        };
        this.decision = CombatDecision.of(motion, weapon, bl && !bl2, bl2, (n == 2 || n == 8 || n == 9 || n == 17) && !bl, n >= 12 && n <= 16, bl3, n == 17, OffhandMode.SHIELD, bl2 ? 0.999f : 1.0f, technique);
        return this.decision;
    }

    private CombatDecision wait(Phase phase, CombatView combatView, int n, boolean bl) {
        return this.input(phase, combatView, n, bl, false, Weapon.AXE, false, Technique.AXE_WAIT);
    }

    private CombatDecision strike(Phase phase, CombatView combatView, NeuralLearner.Senses senses, int n) {
        this.orbitUntil = 0L;
        if (phase == Phase.COUNTER && !combatView.ownShieldAvailable()) {
            // This counter is a sprint knockback input, never a falling-critical conversion.
            this.sprintKnockback = true;
            return this.input(phase, combatView, 2, false, true, Weapon.AXE, false, Technique.AXE_READY);
        }
        if (this.counterHop.active() && (phase==Phase.COUNTER_EXIT||phase==Phase.TURN_EXIT)) {
            // A normal close escape hit briefly faces forward with sprint input, then the
            // existing same-call finally restores the original hop. Native crit is chosen above.
            this.sprintKnockback=true;
            return this.input(phase,combatView,2,false,true,Weapon.SWORD,false,Technique.AXE_READY);
        }
        if (!combatView.ownShieldAvailable() && phase == Phase.EDGE_HIT && senses.onGround
                && !this.escapeSwordHeld && !AirborneEnvelope.relevant(senses) && combatView.ownAttackCharge() >= .999f) {
            this.currentMelee = Weapon.AXE;
            this.sprintKnockback = true;
            return this.input(Phase.PRESSURE_STRIKE, combatView, 2, false, true, Weapon.AXE, false, Technique.AXE_READY);
        }
        int n2 = senses.ownCriticalReady && phase != Phase.TURN_EXIT && phase != Phase.COUNTER_EXIT ? 1 : n;
        return this.input(phase, combatView, n2, false, true, Weapon.AXE, false, senses.ownCriticalReady ? Technique.FALL_CRIT : Technique.AXE_READY);
    }

    private CombatDecision escape(Phase phase, CombatView combatView, NeuralLearner.Senses senses) {
        this.escapeObserved = true;
        this.orbitUntil = 0L;
        return this.input(phase, combatView, 17, false, false, Weapon.AXE, senses.onGround && (senses.escapeJumpEligible || senses.retreatJumpEligible), Technique.AXE_WAIT);
    }

    private boolean opening(CombatView combatView, NeuralLearner.Senses senses) {
        if (!this.exposed(combatView, senses)) {
            this.openingSeen = false;
            this.takeOpening = false;
            return false;
        }
        if (!this.openingSeen || combatView.tick() - this.lastOpeningSample >= 2L) {
            this.openingSeen = true;
            this.lastOpeningSample = combatView.tick();
            double d = senses.targetFacingDot < -0.05 ? 0.85 : (senses.targetShieldDisabled ? 0.55 : 0.3);
            d *= (new double[]{0.35, 1.0, 1.6, 2.3})[this.soft(1, 1)];
            d = Math.min(0.98, d);
            if (senses.targetAttackAge <= 2.0) {
                d *= 0.15;
            }
            this.takeOpening = this.random.nextDouble() < d;
        }
        return this.takeOpening;
    }

    private boolean rangedWindow(CombatView combatView, NeuralLearner.Senses senses) {
        if (!combatView.visible() || !Double.isFinite(combatView.distance()) || !combatView.hasArrows() && !combatView.ownCrossbowCharged() || combatView.nearWall() || senses.retreatBlocked || senses.collisionOverlap || senses.targetCritThreat || senses.damageAge <= 6.0 || this.blockPending(senses) || senses.rangedShotAge < 40.0 || senses.counterFollowPending || combatView.targetBlocking() && combatView.targetFacing()) {
            return false;
        }
        double d = Math.min(senses.ownReachDistance, senses.targetReachDistance);
        if (!Double.isFinite(d) || !Double.isFinite(senses.separationSpeed)) {
            return false;
        }
        double d2 = combatView.ownShieldAvailable() && senses.targetShieldDisabled ? Math.max(6.0, senses.ownShieldWarmup + 2.0) : Math.max(AttackTiming.recoveryTicks(1.0) + 2.0, senses.ownShieldWarmup + 1.0) + 2.0;
        double d3 = 3.0 + Math.max(0.65, -senses.separationSpeed) * d2;
        return d > d3 + (double)(senses.usingRanged || this.phase == Phase.RANGED || this.phase == Phase.ARROW_DODGE ? 0 : 2);
    }

    private CombatDecision ranged(CombatView combatView, NeuralLearner.Senses senses) {
        Weapon weapon = combatView.ownCrossbowCharged() ? Weapon.CROSSBOW : (senses.ownWeapon == 2 ? Weapon.BOW : (senses.ownWeapon == 3 ? Weapon.CROSSBOW : ((this.profile + senses.shotsFired & 1) == 0 ? Weapon.BOW : Weapon.CROSSBOW)));
        if (!senses.usingRanged && (this.rangedSelection == null || senses.shotsFired != this.rangedSelectionShot || this.phase != Phase.RANGED && this.phase != Phase.ARROW_DODGE)) {
            int n = this.soft(3, 2);
            if (n == 0 && senses.bowPresent) {
                weapon = Weapon.BOW;
            }
            if (n == 1 && senses.crossbowPresent) {
                weapon = Weapon.CROSSBOW;
            }
            this.rangedSelection = weapon;
            this.rangedSelectionShot = senses.shotsFired;
        } else if (!senses.usingRanged && this.rangedSelection != null) {
            weapon = this.rangedSelection;
        }
        if (weapon == Weapon.BOW && combatView.bowDrawTicks() == 0 && !senses.usingRanged) {
            int n = this.drawRequired = this.tactics == null ? 20 : this.tactics.draw(false);
        }
        if (!senses.bowPresent && senses.crossbowPresent) {
            weapon = Weapon.CROSSBOW;
        }
        if (!senses.crossbowPresent && senses.bowPresent) {
            weapon = Weapon.BOW;
        }
        Technique technique = weapon == Weapon.BOW ? (combatView.bowDrawTicks() >= this.drawRequired ? Technique.BOW_RELEASE : Technique.BOW_DRAW) : (combatView.ownCrossbowCharged() ? Technique.CROSSBOW_FIRE : Technique.CROSSBOW_LOAD);
        return this.input(Phase.RANGED, combatView, this.side(combatView.tick()), false, false, weapon, false, technique);
    }

    private CombatDecision reload(CombatView combatView, NeuralLearner.Senses senses) {
        boolean bl;
        double d = Math.min(senses.ownReachDistance, senses.targetReachDistance);
        boolean bl2 = bl = senses.crossbowCanLoad && !senses.crossbowLoaded && combatView.visible() && combatView.hasArrows() && !senses.counterFollowPending && !this.blockPending(senses) && !senses.targetCritThreat && !senses.guardSettling && senses.damageAge > 6.0;
        if (!bl || combatView.nearWall() || senses.retreatBlocked || d <= 5.0 || !Double.isFinite(d)) {
            if (this.reloadSeeking) {
                this.reloadSeeking = false;
                this.nextReloadTry = combatView.tick() + 80L;
            }
            return null;
        }
        if (!this.reloadSeeking) {
            if (combatView.tick() < this.nextReloadTry || d < 6.0) {
                return null;
            }
            int n = this.soft(5, 1);
            if (n == 0) {
                this.nextReloadTry = combatView.tick() + 40L;
                return null;
            }
            if (n == 1 && d < 7.0) {
                return null;
            }
            this.reloadSeeking = true;
            this.reloadStarted = combatView.tick();
        }
        if (combatView.tick() - this.reloadStarted > 100L) {
            this.reloadSeeking = false;
            this.nextReloadTry = combatView.tick() + 100L;
            return null;
        }
        double d2 = Math.max(0.4, Math.hypot(senses.targetForward, senses.targetSide));
        double d3 = 3.5 + d2 * (senses.crossbowLoadTicks + AttackTiming.recoveryTicks(1.0) + 4.0);
        return d > d3 ? this.backUse(Phase.RELOAD_LOAD, combatView, Weapon.CROSSBOW, Technique.CROSSBOW_LOAD) : this.escape(Phase.RELOAD_ESCAPE, combatView, senses);
    }

    private CombatDecision suppressiveShot(CombatView combatView, NeuralLearner.Senses senses) {
        double d = Math.min(senses.ownReachDistance, senses.targetReachDistance);
        double d2 = 3.5 + Math.max(0.4, Math.hypot(senses.targetForward, senses.targetSide)) * (20.0 + AttackTiming.recoveryTicks(1.0) + 4.0);
        if (!senses.bowPresent || !combatView.hasArrows() || !senses.withdrawing || !senses.retreatOpened || !combatView.visible() || combatView.targetBlocking() || senses.counterFollowPending || this.blockPending(senses) || senses.targetCritThreat || senses.damageAge <= 6.0 || senses.rangedShotAge < 8.0 || d <= d2 || combatView.nearWall() || senses.retreatBlocked || !Double.isFinite(d)) {
            return null;
        }
        if (this.phase != Phase.ESCAPE_SHOT) {
            if (combatView.tick() < this.nextSuppressionTry) {
                return null;
            }
            this.nextSuppressionTry = combatView.tick() + 80L;
            if (this.random.nextDouble() >= 0.15) {
                return null;
            }
            this.drawRequired = this.tactics == null ? 10 : this.tactics.draw(true);
        }
        return this.backUse(Phase.ESCAPE_SHOT, combatView, Weapon.BOW, combatView.bowDrawTicks() >= this.drawRequired ? Technique.BOW_RELEASE : Technique.BOW_DRAW);
    }

    private CombatDecision backUse(Phase phase, CombatView combatView, Weapon weapon, Technique technique) {
        this.stage(phase, combatView.tick());
        this.lastMove = 1;
        this.decision = CombatDecision.of(Motion.FORWARD, weapon, false, false, false, false, false, true, OffhandMode.SHIELD, 1.0f, technique);
        return this.decision;
    }

    private CombatDecision control(CombatView combatView, NeuralLearner.Senses senses, boolean bl) {
        if (!combatView.ownShieldAvailable() && this.contact(combatView, senses)
                && senses.ownReachDistance < 3.0 && this.exposed(combatView, senses)
                && senses.opportunity != OpportunityStrike.Kind.NONE) {
            if (combatView.ownAttackCharge() >= .999f && senses.onGround && !AirborneEnvelope.relevant(senses))
                return this.strike(Phase.EDGE_HIT, combatView, senses, 2);
            return this.input(Phase.EDGE_HIT, combatView, 2, false, true, Weapon.AXE, false, Technique.AXE_EARLY);
        }
        if (senses.targetReachDistance > 3.0 && this.ready(combatView, senses) && this.exposed(combatView, senses)) {
            return this.strike(Phase.EDGE_HIT, combatView, senses, 2);
        }
        if (senses.ownCriticalReady && this.ready(combatView, senses) && this.exposed(combatView, senses)) {
            return this.strike(Phase.AIR_TRADE, combatView, senses, 1);
        }
        // No independent punishment/trade jump: ground control stays on the ground.
        if (!combatView.ownShieldAvailable() && senses.targetMotionFresh && !senses.targetAirborne && senses.targetLandAge <= 2.0 && this.ready(combatView, senses) && this.exposed(combatView, senses)) {
            return this.strike(Phase.LAND_PUNISH, combatView, senses, this.spacing(combatView, senses, false));
        }
        if (this.ready(combatView, senses) && (this.fair(senses) || senses.targetAirborne && senses.targetMotionFresh && senses.targetReachDistance + Math.min(0.0, senses.separationSpeed) > 3.0) && this.exposed(combatView, senses)) {
            return this.strike(bl ? Phase.WALL_ENGAGE : Phase.EDGE_HIT, combatView, senses, this.spacing(combatView, senses, false));
        }
        return this.wait(bl ? Phase.WALL_ENGAGE : Phase.RANGE_CONTROL, combatView, this.spacing(combatView, senses, combatView.ownShieldAvailable() && !this.exitControl), combatView.ownShieldAvailable());
    }

    private CombatDecision wall(CombatView combatView, NeuralLearner.Senses senses) {
        return this.control(combatView, senses, true);
    }

    private CombatDecision shortAdvance(CombatView v,NeuralLearner.Senses s) {
        if(!this.optionalAttackSafe(v,s)||this.pressureRecovering()
                ||!this.exposed(v,s)||this.tradeBlocked||v.ownAttackCharge()<.999f) {
            this.advanceUntil=-1000;return null;
        }
        // Only the preceding advance frame can continue an opening. A defensive
        // interruption must not silently resume the old dropped-shield action.
        boolean running=v.tick()<this.advanceUntil&&this.phase==Phase.ACTIVE_ADVANCE;
        boolean contact=this.contact(v,s);
        if(!running) {
            this.advanceUntil=-1000;
            if(v.tick()<this.nextAdvance||!Double.isFinite(s.ownReachDistance)
                    ||s.ownReachDistance>3.3||s.ownReachDistance<=3.0
                    ||!this.shortAdvanceAvailable||this.advanceContactTicks<1||this.advanceContactTicks>3)return null;
            boolean race=!s.targetShieldDisabled;
            if(race&&(s.targetShieldRaised||v.targetBlocking()
                    ||this.advanceContactTicks+1>=this.targetShieldDelay))return null;
            this.nextAdvance=v.tick()+8;
            // Existing learnable opening branch scales a deliberately occasional attempt.
            double chance=Math.min(.3,.12*(new double[]{.35,1,1.6,2.3})[this.soft(1,1)]);
            if(this.random.nextDouble()>=chance)return null;
            // Up to three ordinary movement ticks, then the live edge check.
            this.advanceUntil=v.tick()+4;this.advanceGuarded=v.ownShieldAvailable();
            this.advanceShieldRace=race;
        }
        if(!s.targetShieldDisabled) {
            int elapsed=(int)(v.tick()-(this.advanceUntil-4));
            int remaining=contact?0:this.advanceContactTicks;
            if(!this.advanceShieldRace||s.targetShieldRaised||v.targetBlocking()
                    ||remaining<0||elapsed+remaining+1>=this.targetShieldDelay) {
                this.advanceUntil=-1000;return null;
            }
        }
        if(contact) {
            // Start outside reach, then take the first real legal hit. Crossing
            // farther inside during that short approach must not cause hesitation.
            this.sprintKnockback=true;
            return this.input(Phase.ACTIVE_STRIKE,v,2,false,true,Weapon.AXE,false,Technique.AXE_READY);
        }
        if(!this.shortAdvanceAvailable||this.advanceContactTicks<1||this.advanceContactTicks>3
                ||s.ownReachDistance>3.3) {this.advanceUntil=-1000;return null;}
        return this.input(Phase.ACTIVE_ADVANCE,v,2,false,false,Weapon.AXE,false,Technique.AXE_WAIT);
    }

    private boolean optionalAttackSafe(CombatView v,NeuralLearner.Senses s) {
        return !this.counterHop.active()&&!this.escapeSwordHeld&&this.activeTrade==null
            &&v.visible()&&s.onGround&&s.ownWeapon==0&&s.weaponInputReady
            &&s.targetMotionFresh&&s.estimateAge<=1&&!s.targetAirborne&&!s.targetCritThreat
            &&!AirborneEnvelope.relevant(s)&&!s.guardSettling&&!s.usingRanged
            &&!s.closeRangedGuard&&!s.shieldShouldRaise&&!s.shieldCoversRanged
            &&!(s.projectilePlan!=null&&s.projectilePlan.threat());
    }

    private CombatDecision continueCombo(CombatView v,NeuralLearner.Senses s) {
        if(!this.groundCombo.active(v.tick())||!this.optionalAttackSafe(v,s)
                ||this.tradeBlocked||!this.exposed(v,s))return null;
        if(this.contact(v,s)&&this.groundCombo.canHit(v.tick(),s.ownReachDistance,this.targetGrounded,
                s.targetLandAge,this.targetImmunity,this.targetMaximumImmunity)) {
            this.sprintKnockback=true;
            return this.input(Phase.COMBO_EDGE,v,2,false,true,Weapon.AXE,false,Technique.AXE_EARLY);
        }
        // Follow only a checked short approach while still outside real reach.
        // An opponent moving backwards does not veto a reachable continuation.
        if(s.ownReachDistance>3&&s.ownReachDistance<=3.3&&this.shortAdvanceAvailable)
            return this.input(Phase.COMBO_TRACK,v,2,v.ownShieldAvailable(),false,Weapon.AXE,false,Technique.AXE_WAIT);
        return null;
    }

    private boolean nativeExchangeWindow(NeuralLearner.Senses s) {
        return s.ownCriticalWindow&&this.hopNativeVelocityY<0
            &&Float.isFinite(this.hopNativeCharge)&&this.hopNativeCharge>.9f;
    }

    private CombatDecision contactReply(CombatView v,NeuralLearner.Senses s) {
        this.contactReplyRequestedAt=v.tick()-(long)s.damageAge;
        this.sprintKnockback=true;
        return this.input(Phase.CONTACT_REPLY,v,2,false,true,this.currentMelee,false,Technique.AXE_EARLY);
    }

    private CombatDecision recontact(CombatView v,NeuralLearner.Senses s) {
        if(!this.exitControl||v.ownShieldAvailable()&&!this.exchangeShieldGrace()||this.counterHop.active()||this.activeTrade!=null
                ||!this.contact(v,s)||!s.targetMotionFresh)return null;
        boolean hurt=s.damageAge>=0&&s.damageAge<=2&&v.tick()-(long)s.damageAge>this.contactReplyAt;
        boolean enemyCrit=this.lastCriticalTaken>=v.tick()-2;
        // Real native state may allow a reply even when no jump route was found.
        if(this.landingTradePending&&!this.tradeBlocked&&this.nativeExchangeWindow(s)&&enemyCrit)
            return this.input(Phase.TRADE_CRIT,v,1,false,true,this.currentMelee,false,Technique.FALL_CRIT);
        if(this.landingTradePending&&s.targetAirborne&&s.targetY>0&&this.tradePlan!=null&&s.onGround) {
            this.synchronizeTrade(this.tradePlan,v.tick());
            return this.exchange(v,s);
        }
        if(this.landingTradePending) {
            boolean event=v.tick()-this.synchronizedAttackAt>=0&&v.tick()-this.synchronizedAttackAt<=1;
            if(!this.tradeBlocked&&(hurt&&!enemyCrit||event&&!this.synchronizedCritical))return this.contactReply(v,s);
            return this.input(Phase.TRADE_WAIT,v,0,this.exchangeShieldGrace()&&v.ownShieldAvailable(),false,this.currentMelee,false,Technique.AXE_WAIT);
        }
        if(this.tradeBlocked)return null;
        if(AirborneEnvelope.relevant(s)||s.targetAirborne) {
            // Preserve the rising jump's charge; do not silently discard an actual
            // ordinary wound when no synchronized route was available.
            return null;
        }
        long swing=v.tick()-(long)s.targetAttackAge;
        boolean newSwing=s.targetAttackAge>=0&&s.targetAttackAge<=1&&swing>this.contactReplyAt;
        if(!hurt&&!newSwing)return null;
        this.contactReplyRequestedAt=hurt?v.tick()-(long)s.damageAge:swing;
        this.sprintKnockback=true;
        return this.input(Phase.CONTACT_REPLY,v,2,false,true,this.currentMelee,false,Technique.AXE_EARLY);
    }

    private CombatDecision exchange(CombatView v,NeuralLearner.Senses s) {
        if(this.activeTrade==null)return null;
        if(!s.onGround)this.tradeAirborne=true;
        if(v.ownShieldAvailable()&&!this.exchangeShieldGrace() || this.tradeAirborne&&s.onGround || !this.tradeAirborne&&v.tick()-this.tradeStarted>3 || v.tick()-this.tradeStarted>18
                || !v.visible() || !s.targetMotionFresh || s.estimateAge>1) {
            this.tradeShieldHold=this.tradeBlocked;
            this.landingTradePending=false;
            this.activeTrade=null;this.exitControl=true;this.counterFlight=this.escapeObserved=false;return null;
        }
        boolean nativeWindow=this.nativeExchangeWindow(s);
        boolean enemyCrit=this.lastCriticalTaken>=this.tradeStarted;
        boolean hurt=s.damageAge>=0&&s.damageAge<=1&&v.tick()-(long)s.damageAge>=this.tradeStarted
            &&v.tick()-(long)s.damageAge>this.contactReplyAt;
        if(!this.tradeBlocked&&this.contact(v,s)) {
            boolean event=v.tick()-this.synchronizedAttackAt>=0&&v.tick()-this.synchronizedAttackAt<=1;
            // This post-hop exchange mirrors the opponent, including attack type.
            // It never manufactures a first critical merely because we are falling.
            if(nativeWindow&&(enemyCrit||event&&this.synchronizedCritical))
                return this.input(Phase.TRADE_CRIT,v,1,false,true,Weapon.AXE,false,Technique.FALL_CRIT);
            if(hurt&&!enemyCrit||event&&!this.synchronizedCritical)return this.contactReply(v,s);
        }
        double x=this.exchangeHeading==null?this.activeTrade.x():this.exchangeHeading.x();
        double z=this.exchangeHeading==null?this.activeTrade.z():this.exchangeHeading.z();
        s.jumpSpace=new JumpThreatSpacing.Plan(true,2,this.activeTrade.separation(),x,z,true,!this.tradeJumpSubmitted);
        return this.input(Phase.AIR_DODGE,v,2,this.exchangeShieldGrace()&&v.ownShieldAvailable(),false,Weapon.AXE,s.onGround&&!this.tradeJumpSubmitted,Technique.AXE_WAIT);
    }

    private CombatDecision evadeJump(CombatView combatView, NeuralLearner.Senses senses) {
        if (senses.jumpSpace != null && senses.jumpSpace.threat() && senses.jumpSpace.heading()) {
            this.emergencyJump = !combatView.ownShieldAvailable() && senses.targetMotionFresh
                && senses.targetY > 0 && senses.jumpSpace.jump() && senses.onGround;
            return this.input(Phase.AIR_DODGE, combatView, senses.jumpSpace.sprint() ? 2 : 1, false, false, Weapon.AXE, senses.jumpSpace.jump() && senses.onGround && senses.escapeJumpEligible, Technique.AXE_WAIT);
        }
        if (senses.jumpSpace == null && !senses.retreatBlocked && !this.exitControl) {
            return this.escape(Phase.AIR_ESCAPE, combatView, senses);
        }
        int n = senses.jumpSpace != null && senses.jumpSpace.threat() ? senses.jumpSpace.move() : this.spacing(combatView, senses, false);
        return this.wait(Phase.AIR_CONTROL, combatView, n, false);
    }


    private CombatDecision airborneControl(CombatView combatView, NeuralLearner.Senses senses) {
        boolean bl;
        this.orbitUntil = 0L;
        boolean bl2 = senses.targetMotionFresh && senses.targetY > 0.0 && senses.targetCritEta > 1.0;
        boolean bl3 = bl = senses.risingPlan == null || senses.risingPlan.feasible() && senses.risingPlan.ticks() == 0 && senses.risingPlan.ascentLeft() > 1.0;
        // Live legal contact outranks a forecast: a future-trajectory prediction must not
        // veto an interrupt that can already be submitted in this frame.
        if (senses.targetMotionFresh && senses.targetY > 0.0
                && senses.ownReachDistance < 3.0 && this.interruptReady(combatView, senses)
                && this.exposed(combatView, senses)) {
            return this.interrupt(combatView, senses);
        }
        if (bl2 && senses.risingPlan != null && senses.risingPlan.feasible() && senses.risingPlan.ticks() > 0 && senses.risingPlan.ascentLeft() > 1.0 && this.exposed(combatView, senses) && !senses.retreatBlocked && senses.weaponInputReady) {
            return this.input(Phase.AIR_INTERRUPT, combatView, 2, false, false, Weapon.AXE, false, Technique.AXE_WAIT);
        }
        if (senses.targetMotionFresh && senses.targetY <= 0.0
                && (senses.jumpSpace == null || !senses.jumpSpace.safe())
                && senses.ownReachDistance < 3.0 && this.interruptReady(combatView, senses)
                && this.exposed(combatView, senses)) {
            // No safe dodge remains: submit the available legal hit, without a revenge jump.
            return this.input(Phase.EDGE_HIT, combatView, 2, false, true, Weapon.AXE, false, Technique.AXE_EARLY);
        }
        if (senses.targetMotionFresh && senses.targetY <= 0.0) {
            return this.evadeJump(combatView, senses);
        }
        return this.evadeJump(combatView, senses);
    }

    private CombatDecision counterFlight(CombatView combatView, NeuralLearner.Senses senses) {
        if (this.contact(combatView, senses) && this.exposed(combatView, senses)) {
            if (senses.opportunity == OpportunityStrike.Kind.COUNTER_FOLLOW) {
                return this.strike(Phase.COUNTER_EXIT, combatView, senses, 0);
            }
            if (senses.opportunity == OpportunityStrike.Kind.EXIT && !senses.exitHitDone) {
                return this.strike(Phase.TURN_EXIT, combatView, senses, 0);
            }
        }
        if (AirborneEnvelope.relevant(senses)) {
            boolean bl;
            boolean bl2 = senses.targetMotionFresh && senses.targetY > 0.0 && senses.targetCritEta > 1.0;
            boolean bl3 = bl = senses.risingPlan == null || senses.risingPlan.feasible() && senses.risingPlan.ticks() == 0 && senses.risingPlan.ascentLeft() > 1.0;
            if (bl2 && bl && this.interruptReady(combatView, senses) && this.exposed(combatView, senses)) {
                return this.interrupt(combatView, senses);
            }
            if (bl2 && senses.risingPlan != null && senses.risingPlan.feasible() && senses.risingPlan.ticks() > 0 && senses.risingPlan.ascentLeft() > 1.0 && this.exposed(combatView, senses) && !senses.retreatBlocked) {
                return this.input(Phase.AIR_INTERRUPT, combatView, 2, false, false, Weapon.AXE, false, Technique.AXE_WAIT);
            }
            if (senses.jumpSpace != null && senses.jumpSpace.threat() && !senses.escapeViable && !senses.wallEscapeAvailable) {
                return this.airborneControl(combatView, senses);
            }
        }
        if (senses.retreatBlocked || combatView.nearWall() && !senses.wallEscapeAvailable || !senses.escapeViable && !senses.wallEscapeAvailable && senses.chaseReachTicks <= 1.0) {
            return AirborneEnvelope.relevant(senses) ? this.airborneControl(combatView, senses) : this.wall(combatView, senses);
        }
        return this.escape(Phase.ESCAPE, combatView, senses);
    }

    private CombatDecision afterExit(CombatView combatView, NeuralLearner.Senses senses) {
        if (AirborneEnvelope.relevant(senses)) {
            return combatView.ownShieldAvailable() ? this.shieldAirborne(combatView, senses) : this.airborneControl(combatView, senses);
        }
        if (this.rangedWindow(combatView, senses)) {
            return this.ranged(combatView, senses);
        }
        if (combatView.ownShieldAvailable()) {
            return this.pressure(combatView, senses);
        }
        return this.control(combatView, senses, senses.retreatBlocked || combatView.nearWall());
    }

    private CombatDecision retreat(CombatView combatView, NeuralLearner.Senses senses) {
        CombatDecision combatDecision;
        if (AirborneEnvelope.relevant(senses)) {
            return this.airborne(combatView, senses);
        }
        if (!combatView.ownShieldAvailable() && senses.targetMotionFresh && !senses.targetAirborne && senses.targetLandAge <= 2.0 && this.ready(combatView, senses) && this.exposed(combatView, senses)) {
            return this.strike(Phase.LAND_PUNISH, combatView, senses, 1);
        }
        if (this.contact(combatView, senses) && this.exposed(combatView, senses)) {
            if (senses.opportunity == OpportunityStrike.Kind.EXIT) {
                return this.strike(Phase.TURN_EXIT, combatView, senses, 0);
            }
            if (this.ready(combatView, senses) && (!senses.targetCritThreat || senses.targetY >= 0.0 || senses.targetReachDistance > 3.0 || senses.ownCriticalReady)) {
                return this.strike(senses.rangeControl ? Phase.EDGE_HIT : Phase.TURN_TRADE, combatView, senses, 2);
            }
        }
        if (senses.retreatBlocked || combatView.nearWall() && !senses.wallEscapeAvailable) {
            return this.wall(combatView, senses);
        }
        if (AirborneEnvelope.relevant(senses)) {
            return this.airborne(combatView, senses);
        }
        if (combatView.ownShieldAvailable() && senses.targetReachDistance <= 3.0) {
            return this.wait(Phase.REBLOCK, combatView, this.pressureMove(combatView, senses), true);
        }
        if (senses.retreatOpened) {
            CombatDecision combatDecision2 = this.suppressiveShot(combatView, senses);
            if (combatDecision2 != null) {
                return combatDecision2;
            }
            CombatDecision combatDecision3 = this.reload(combatView, senses);
            if (combatDecision3 != null) {
                return combatDecision3;
            }
            return this.control(combatView, senses, false);
        }
        if (senses.rangeControl || !senses.escapeViable && senses.chaseReachTicks <= 6.0) {
            return this.control(combatView, senses, false);
        }
        if (this.tactics != null && this.tactics.enabled() && senses.retreatOpened && senses.escapeViable && senses.ownReachDistance > 3.3 && senses.targetReachDistance > 3.3) {
            if (combatView.tick() >= this.nextRouteChoice) {
                this.learnedControl = this.soft(7, 0) == 1;
                this.nextRouteChoice = combatView.tick() + 20L;
            }
            if (this.learnedControl) {
                return this.control(combatView, senses, false);
            }
        }
        if ((combatDecision = this.suppressiveShot(combatView, senses)) != null) {
            return combatDecision;
        }
        combatDecision = this.reload(combatView, senses);
        return combatDecision != null ? combatDecision : this.escape(Phase.ESCAPE, combatView, senses);
    }

    private CombatDecision shieldAirborne(CombatView combatView, NeuralLearner.Senses senses) {
        this.orbitUntil = 0L;
        this.currentMelee = this.escapeSwordHeld || senses.ownWeapon == 1 ? Weapon.SWORD : Weapon.AXE;
        // Shield AVAILABLE is the boundary, not whether its raise animation finished.
        // Do not drop a usable shield to interrupt a rising or falling jump attack.
        return this.wait(Phase.AIR_CONTROL, combatView, 0, true);
    }

    private CombatDecision airborne(CombatView combatView, NeuralLearner.Senses senses) {
        return combatView.ownShieldAvailable() ? this.shieldAirborne(combatView, senses) : this.airborneControl(combatView, senses);
    }

    double orbitGoalDegrees() {
        return Math.toDegrees(this.orbitGoal);
    }

    private CombatDecision pressure(CombatView combatView, NeuralLearner.Senses senses) {
        boolean bl;
        if (combatView.tick() < this.orbitUntil) {
            if (!senses.onGround) {
                this.orbitUntil = 0L;
                return this.wait(Phase.REBLOCK, combatView, this.side(combatView.tick()), true);
            }
            if (senses.damageAge <= 1.0) {
                if (this.ready(combatView, senses) && this.fair(senses) && this.exposed(combatView, senses)) {
                    return this.strike(Phase.GUARD_CLOSE, combatView, senses, 2);
                }
                this.orbitUntil = 0L;
                return this.wait(Phase.REBLOCK, combatView, this.side(combatView.tick()), true);
            }
            if (this.ready(combatView, senses) && senses.targetFacingDot < -0.05) {
                this.orbitUntil = 0L;
                return this.strike(Phase.GUARD_CLOSE, combatView, senses, 2);
            }
            return this.input(Phase.ORBIT_BURST, combatView, this.left ? 8 : 9, false, false, Weapon.AXE, false, Technique.AXE_WAIT);
        }
        if (this.phase == Phase.ORBIT_BURST) {
            return this.wait(Phase.REBLOCK, combatView, this.side(combatView.tick()), true);
        }
        if (this.ready(combatView, senses) && this.fair(senses) && (senses.enteredReach && this.exposed(combatView, senses) || this.opening(combatView, senses))) {
            return this.strike(Phase.GUARD_CLOSE, combatView, senses, 1);
        }
        boolean bl2 = bl = senses.onGround && senses.blocking && senses.orbitRadius <= 0.85 && (senses.collisionOverlap || senses.ownReachDistance < 0.85) && senses.targetShieldRaised && combatView.targetBlocking() && !senses.targetAirborne && !senses.targetCritThreat && senses.targetAttackAge > 1.0 && senses.damageAge > 1.0 && combatView.ownAttackCharge() >= 0.999f;
        if (bl && combatView.tick() >= this.nextOrbit) {
            this.nextOrbit = combatView.tick() + 8L;
            if (this.random.nextDouble() < 0.45) {
                this.left = this.random.nextBoolean();
                this.orbitGoal = Math.toRadians(150.0);
                this.orbitUntil = combatView.tick() + 5L;
                return this.input(Phase.ORBIT_BURST, combatView, this.left ? 8 : 9, false, false, Weapon.AXE, false, Technique.AXE_WAIT);
            }
        }
        return this.wait(senses.ownReachDistance > 3.15 ? Phase.GUARD_ADVANCE : Phase.GUARD_CLOSE, combatView, this.pressureMove(combatView, senses), true);
    }

    CombatDecision decide(CombatView combatView, NeuralLearner.Senses senses) {
        this.decisionTick=combatView.tick();
        this.updateExchangeShield(combatView);
        this.emergencyJump=false;
        this.sprintKnockback=false;
        this.hopCriticalAtExit = false;
        this.hopCriticalOpportunity = OpportunityStrike.Kind.NONE;
        // Retired intent is not a current opening. Normal reactive counters remain unchanged.
        senses.criticalReplyPending=false;
        if(senses.opportunity==OpportunityStrike.Kind.RECOVERY_BREAK)senses.opportunity=OpportunityStrike.Kind.NONE;
        if(senses.opportunity==OpportunityStrike.Kind.COUNTER_FOLLOW)senses.opportunity=OpportunityStrike.Kind.NONE;
        boolean bl;
        this.centerDistance = senses.centerDistance;
        this.centerSide = senses.centerSide;
        this.currentMelee = this.escapeSwordHeld || senses.escapeSword ? Weapon.SWORD : Weapon.AXE;
        this.observeDisengagement(combatView, senses);
        // A defensive input owns this whole frame. Later melee, jump, offhand and
        // learned branches must not select a different movement in the same tick.
        if(ProjectileMovementPriority.owns(senses)) {
            this.orbitUntil=0;this.advanceUntil=-1000;
            if(combatView.ownShieldAvailable())return this.wait(Phase.ARROW_GUARD,combatView,0,true);
            return this.wait(Phase.ARROW_DODGE,combatView,senses.projectilePlan.preferredMove(),false);
        }
        if (!this.axeSwitchPending) this.pressureRecovery.recoveryActive(combatView.tick(), combatView.ownAttackCharge());
        if (!this.pressureRecovering()) { this.axeSwitchRecovery = false; this.closeReplyUsed = false; }
        else if (this.closeReplyUsed && senses.estimateAge <= 1
                && Double.isFinite(senses.ownReachDistance) && Double.isFinite(senses.targetReachDistance)
                && senses.ownReachDistance > 3.3 && senses.targetReachDistance > 3.3) this.closeReplyUsed = false;
        if (this.exitControl && !this.escapeSwordHeld) {
            this.currentMelee = Weapon.AXE;
        }
        // Real contact responses precede network feature preparation and minibatch work.
        this.requestedBlock = -1000L;
        boolean counterEscape = !combatView.ownShieldAvailable() && (this.counterHop.active()
            || senses.opportunity == OpportunityStrike.Kind.BREAK_COUNTER && this.contact(combatView,senses)
            || this.blockPending(senses) && this.ready(combatView,senses));
        if (this.activeTrade==null && !counterEscape && !this.exitControl && !combatView.ownShieldAvailable() && this.contact(combatView,senses) && senses.ownReachDistance<3.0) {
            if (senses.orbitWoundPending && senses.opportunity==OpportunityStrike.Kind.ORBIT_TRADE) {
                this.orbitUntil=0L;
                return this.input(Phase.ORBIT_TRADE,combatView,2,false,true,Weapon.AXE,false,Technique.AXE_EARLY);
            }
            if (combatView.tick()>=this.advanceUntil && senses.opportunity==OpportunityStrike.Kind.ENTRY && this.exposed(combatView,senses)
                    && !senses.targetAirborne && !senses.targetCritThreat && !this.pressureRecovering()) {
                if (combatView.ownAttackCharge() >= .999f)
                    return this.strike(Phase.EDGE_HIT, combatView, senses, 2);
                return this.input(Phase.ENTRY_HIT,combatView,2,false,true,Weapon.AXE,false,Technique.AXE_EARLY);
            }
            if (senses.targetMotionFresh && senses.targetY>0 && senses.targetAirborne
                    && this.interruptReady(combatView,senses) && this.exposed(combatView,senses)) {
                return this.interrupt(combatView,senses);
            }
        }
        if (this.tactics != null) {
            this.tactics.begin(combatView, senses);
        }
        this.requestedBlock = -1000L;
        if (!this.exposed(combatView, senses)) {
            this.openingSeen = false;
        }
        boolean bl2 = senses.orbitWoundPending && senses.opportunity == OpportunityStrike.Kind.ORBIT_TRADE || senses.orbitBackPending && senses.opportunity == OpportunityStrike.Kind.ORBIT_BACK;
        // An unavoidable close shot must not force an ineffective dodge over a legal reply.
        boolean bl3 = senses.projectilePlan != null && senses.projectilePlan.threat()
            && (senses.shieldCoversRanged || senses.shieldShouldRaise || canDodge(senses.projectilePlan));
        boolean bl4 = bl3 || combatView.ownShieldAvailable() && (senses.closeRangedGuard || senses.shieldCoversRanged || senses.shieldShouldRaise);
        boolean bl5 = bl = combatView.visible() && combatView.ownShieldAvailable() && !this.exchangeShieldGrace() && AirborneEnvelope.relevant(senses);
        if (bl) {
            this.activeTrade=null;this.advanceUntil=-1000;
            return this.shieldAirborne(combatView, senses);
        }
        if (!bl3 && !combatView.ownShieldAvailable() && this.contact(combatView,senses) && !this.tradeBlocked
                && senses.ownWeapon==1 && this.counterHop.criticalAvailable(senses.ownCriticalWindow,this.hopNativeVelocityY)
                && Float.isFinite(this.hopNativeCharge) && this.hopNativeCharge>.9f) {
            this.hopCriticalAtExit=senses.opportunity==OpportunityStrike.Kind.EXIT&&!senses.exitHitDone;
            if(senses.opportunity==OpportunityStrike.Kind.EXIT||senses.opportunity==OpportunityStrike.Kind.COUNTER_FOLLOW)this.hopCriticalOpportunity=senses.opportunity;
            return this.input(Phase.HOP_CRIT,combatView,1,false,true,Weapon.SWORD,false,Technique.FALL_CRIT);
        }
        if(!bl3&&!bl4&&!combatView.ownShieldAvailable()&&this.counterHop.active()&&this.counterHop.exitAccepted())
            return this.escape(Phase.ESCAPE,combatView,senses);
        if (this.activeTrade==null && !bl3 && !combatView.ownShieldAvailable() && (senses.retreatBlocked||combatView.nearWall()&&!senses.wallEscapeAvailable)
                && this.contact(combatView,senses) && this.exposed(combatView,senses)
                && senses.damageAge>=0&&senses.damageAge<=1&&senses.targetAttackAge<=1) {
            long hurtAt=combatView.tick()-(long)senses.damageAge;
            if(hurtAt>this.wallReplyHandledAt) {
                this.wallReplyRequestedAt=hurtAt;
                return this.input(Phase.WALL_TRADE,combatView,2,false,true,Weapon.AXE,false,Technique.AXE_EARLY);
            }
        }
        if (!bl3 && this.targetLoadingCrossbow && this.ready(combatView, senses) && this.exposed(combatView, senses))
            return this.strike(Phase.RANGED_PUNISH, combatView, senses, 1);
        // Only this shield-broken counter + single hop bypass critical prediction.
        // Ranged emergencies retain their existing priority; legality still lives in meleeInput.
        if (!bl3 && !bl4 && !combatView.ownShieldAvailable()) {
            if ((senses.opportunity == OpportunityStrike.Kind.BREAK_COUNTER && this.contact(combatView, senses))
                    || this.blockPending(senses) && this.ready(combatView, senses)) {
                this.requestedBlock = senses.lastBlockTick;
                return this.strike(Phase.COUNTER, combatView, senses, 2);
            }
            if (this.counterHop.active()) {
                if (senses.retreatBlocked || combatView.nearWall() && !senses.wallEscapeAvailable) {
                    this.counterHop.blocked();
                    this.counterFlight = this.escapeObserved = false;
                    this.exitControl = true;
                    return this.wall(combatView, senses);
                }
                if (senses.ownReachDistance > 3 && senses.targetReachDistance > 3)
                    return this.escape(Phase.ESCAPE, combatView, senses);
                if (this.contact(combatView, senses) && this.exposed(combatView, senses)) {
                    if (senses.opportunity == OpportunityStrike.Kind.COUNTER_FOLLOW)
                        return this.strike(Phase.COUNTER_EXIT, combatView, senses, 0);
                    if (senses.opportunity == OpportunityStrike.Kind.EXIT && !senses.exitHitDone)
                        return this.strike(Phase.TURN_EXIT, combatView, senses, 0);
                    // Do not spend the escape sword's charge on an ordinary entry
                    // click before its descending critical. Actual wounds have their
                    // own immediate reply, and the legal final EXIT remains above.
                }
                return this.escape(Phase.ESCAPE, combatView, senses);
            }
        }
        if (bl2 && !senses.targetCriticalPossible && this.contact(combatView, senses) && (senses.opportunity == OpportunityStrike.Kind.ORBIT_TRADE || senses.targetFacingDot < -0.05)) {
            this.orbitUntil = 0L;
            return this.input(senses.opportunity == OpportunityStrike.Kind.ORBIT_TRADE ? Phase.ORBIT_TRADE : Phase.ORBIT_BACK, combatView, senses.ownCriticalReady ? 1 : 2, false, true, Weapon.AXE, false, Technique.AXE_EARLY);
        }
        if (bl4 && !bl && !this.counterFlight && !this.exitControl && RangedReadiness.axeTradeAvailable(combatView, senses) && this.opening(combatView, senses)) {
            return this.strike(Phase.RANGED_PUNISH, combatView, senses, 1);
        }
        if (bl3) {
            this.orbitUntil = 0L;
            if (senses.shieldCoversRanged || senses.shieldShouldRaise) {
                return this.wait(Phase.ARROW_GUARD, combatView, 0, true);
            }
            int n = this.tactics == null ? senses.projectilePlan.preferredMove() : this.tactics.dodge(senses.projectilePlan);
            return this.wait(Phase.ARROW_DODGE, combatView, n, false);
        }
        if (bl4) {
            return this.wait(Phase.ARROW_GUARD, combatView, this.spacing(combatView, senses, true), true);
        }
        CombatDecision exchangeDecision=this.exchange(combatView,senses);
        if(exchangeDecision!=null)return exchangeDecision;
        CombatDecision contactDecision=this.recontact(combatView,senses);
        if(contactDecision!=null)return contactDecision;
        if(this.exitControl&&!this.tradeShieldHold&&!combatView.ownShieldAvailable()&&!this.counterHop.active()&&!AirborneEnvelope.relevant(senses)&&!senses.targetAirborne&&!senses.targetCritThreat
                &&combatView.visible()&&senses.targetMotionFresh&&senses.estimateAge<=1
                &&senses.onGround&&Double.isFinite(senses.targetReachDistance)&&senses.targetReachDistance<=3
                &&Double.isFinite(senses.ownReachDistance)&&senses.ownReachDistance<=3
                &&this.tradeBlocked) {
            this.escapeSwordHeld=false;this.currentMelee=Weapon.AXE;this.orbitUntil=0;
            this.advanceUntil=-1000;
            boolean axeReady=senses.ownWeapon==0&&senses.weaponInputReady;
            return this.input(Phase.SHIELD_PRESS,combatView,this.spacing(combatView,senses,combatView.ownShieldAvailable()),false,axeReady,Weapon.AXE,false,Technique.AXE_EARLY);
        }
        CombatDecision comboDecision=this.continueCombo(combatView,senses);
        if(comboDecision!=null)return comboDecision;
        CombatDecision advanceDecision=this.shortAdvance(combatView,senses);
        if(advanceDecision!=null)return advanceDecision;
        if (this.pressureRecovering()) {
            if (combatView.ownShieldAvailable() && !this.axeSwitchRecovery) {
                this.pressureRecovery.reset();
            } else if (!AirborneEnvelope.relevant(senses)) {
                if (!this.axeSwitchPending && !this.closeReplyUsed && combatView.visible()
                        && senses.targetMotionFresh && senses.estimateAge <= 1
                        && Double.isFinite(senses.ownReachDistance) && senses.ownReachDistance <= 3.3
                        && this.exposed(combatView, senses)) {
                    if (this.contact(combatView, senses))
                        return this.input(Phase.RECHARGE_REPLY, combatView, 2, false, true, Weapon.AXE, false, Technique.AXE_EARLY);
                    if (senses.ownReachDistance > 3 && !senses.retreatBlocked && (!combatView.nearWall() || senses.wallEscapeAvailable))
                        return this.input(Phase.RECHARGE_APPROACH, combatView, 2, false, false, Weapon.AXE, false, Technique.AXE_WAIT);
                }
                if (senses.retreatBlocked || combatView.nearWall() && !senses.wallEscapeAvailable)
                    return this.wall(combatView, senses);
                return this.input(Phase.PRESSURE_RECHARGE, combatView, combatView.ownShieldAvailable() ? 3 : 17,
                    combatView.ownShieldAvailable(), false, Weapon.AXE, false, Technique.AXE_WAIT);
            }
        }
        if (bl2 && senses.targetCriticalPossible) {
            this.orbitUntil = 0L;
            return this.airborne(combatView, senses);
        }
        if (this.phase == Phase.ORBIT_BURST && combatView.tick() < this.orbitUntil) {
            return this.pressure(combatView, senses);
        }
        if (!combatView.ownShieldAvailable() && senses.opportunity == OpportunityStrike.Kind.BREAK_COUNTER && this.contact(combatView, senses)) {
            this.requestedBlock = senses.lastBlockTick;
            return this.strike(Phase.COUNTER, combatView, senses, 2);
        }
        if (!bl && senses.opportunity == OpportunityStrike.Kind.ENTRY && this.contact(combatView, senses) && this.exposed(combatView, senses)) {
            if (!combatView.ownShieldAvailable() && AirborneEnvelope.relevant(senses)) {
                return this.airborneControl(combatView, senses);
            }
            if(!combatView.ownShieldAvailable()&&combatView.ownAttackCharge()>=.999f)
                return this.strike(Phase.EDGE_HIT,combatView,senses,2);
            return this.input(Phase.ENTRY_HIT, combatView, 2, false, true, Weapon.AXE, false, Technique.AXE_EARLY);
        }
        if (combatView.visible() && !combatView.ownShieldAvailable() && AirborneEnvelope.relevant(senses) && (senses.jumpSpace != null ? senses.jumpSpace.threat() : senses.targetCritThreat)) {
            return this.airborneControl(combatView, senses);
        }
        if (this.counterFlight && !this.exitControl && !combatView.ownShieldAvailable()) {
            return this.counterFlight(combatView, senses);
        }
        if (!combatView.visible()) {
            this.orbitUntil = 0L;
            if (this.escapeObserved && !this.exitControl) {
                return this.escape(Phase.ESCAPE, combatView, senses);
            }
            return this.wait(Phase.SEARCH, combatView, 0, combatView.ownShieldAvailable());
        }
        if (bl) {
            return this.shieldAirborne(combatView, senses);
        }
        if (this.exitControl) {
            if (senses.opportunity == OpportunityStrike.Kind.BREAK_COUNTER && this.contact(combatView, senses)) {
                this.requestedBlock = senses.lastBlockTick;
                return this.strike(Phase.COUNTER, combatView, senses, 2);
            }
            if (this.blockPending(senses) && this.ready(combatView, senses)) {
                this.requestedBlock = senses.lastBlockTick;
                return this.strike(Phase.COUNTER, combatView, senses, 2);
            }
            return this.afterExit(combatView, senses);
        }
        if (senses.opportunity == OpportunityStrike.Kind.COUNTER_FOLLOW && this.contact(combatView, senses)) {
            return this.strike(Phase.COUNTER_EXIT, combatView, senses, 0);
        }
        if (senses.opportunity == OpportunityStrike.Kind.BREAK_COUNTER && this.contact(combatView, senses)) {
            this.requestedBlock = senses.lastBlockTick;
            return this.strike(Phase.COUNTER, combatView, senses, 2);
        }
        if (this.blockPending(senses) && this.ready(combatView, senses)) {
            this.requestedBlock = senses.lastBlockTick;
            return this.strike(Phase.COUNTER, combatView, senses, 2);
        }
        if (senses.comboPursuit) {
            return this.ready(combatView, senses) ? this.strike(Phase.COMBO, combatView, senses, senses.ownCriticalReady ? 1 : 2) : this.wait(Phase.COMBO, combatView, 2, combatView.ownShieldAvailable());
        }
        if (senses.withdrawing) {
            return this.retreat(combatView, senses);
        }
        if (!combatView.ownShieldAvailable() && senses.targetMotionFresh && !senses.targetAirborne && senses.targetLandAge <= 2.0 && this.ready(combatView, senses) && this.exposed(combatView, senses)) {
            return this.strike(Phase.LAND_PUNISH, combatView, senses, this.spacing(combatView, senses, false));
        }
        if (senses.synchroniseJump || senses.criticalDisadvantage) {
            return this.wait(Phase.AIR_CONTROL, combatView, this.spacing(combatView, senses, combatView.ownShieldAvailable()), combatView.ownShieldAvailable());
        }
        if (AirborneEnvelope.relevant(senses) && Math.min(senses.ownReachDistance, senses.targetReachDistance) <= 4.8) {
            return this.airborne(combatView, senses);
        }
        if (senses.opportunity != OpportunityStrike.Kind.NONE && this.contact(combatView, senses) && this.fair(senses)) {
            return this.strike(senses.opportunity == OpportunityStrike.Kind.EXIT ? Phase.TURN_EXIT : Phase.EDGE_HIT, combatView, senses, 0);
        }
        if (!combatView.ownShieldAvailable() && senses.targetMotionFresh && !senses.targetAirborne && senses.targetLandAge <= 2.0 && this.ready(combatView, senses) && this.exposed(combatView, senses)) {
            return this.strike(Phase.LAND_PUNISH, combatView, senses, this.spacing(combatView, senses, false));
        }
        if (combatView.ownShieldAvailable() && !combatView.targetAxe() && !senses.targetSword && this.ready(combatView, senses) && this.opening(combatView, senses)) {
            return this.strike(Phase.RANGED_PUNISH, combatView, senses, 1);
        }
        if (senses.guardSettling) {
            return this.wait(Phase.REBLOCK, combatView, this.pressureMove(combatView, senses), true);
        }
        if (combatView.ownShieldAvailable() && senses.targetReachDistance <= 3.35) {
            return this.pressure(combatView, senses);
        }
        CombatDecision combatDecision = this.reload(combatView, senses);
        if (combatDecision != null) {
            return combatDecision;
        }
        if (this.rangedWindow(combatView, senses)) {
            return this.ranged(combatView, senses);
        }
        if (combatView.ownShieldAvailable()) {
            return this.pressure(combatView, senses);
        }
        if (this.ready(combatView, senses) && this.exposed(combatView, senses) && (senses.enteredReach || senses.edgeThreat || senses.targetAttackAge <= 1.0 || senses.damageAge <= 1.0)) {
            return this.strike(Phase.EDGE_HIT, combatView, senses, 2);
        }
        if (!senses.retreatBlocked && (senses.escapeViable || senses.wallEscapeAvailable)) {
            return this.escape(Phase.ESCAPE, combatView, senses);
        }
        return this.control(combatView, senses, senses.retreatBlocked);
    }

    static enum Phase {
        SEARCH,
        GUARD_ADVANCE,
        GUARD_CLOSE,
        COUNTER,
        HOP_CRIT,
        WALL_TRADE,
        TRADE_CRIT,
        TRADE_WAIT,
        ACTIVE_ADVANCE,
        COMBO_EDGE,
        COMBO_TRACK,
        CONTACT_REPLY,
        ACTIVE_STRIKE,
        SHIELD_PRESS,
        PRESSURE_STRIKE,
        PRESSURE_RECHARGE,
        RECHARGE_REPLY,
        RECHARGE_APPROACH,
        COMBO,
        REBLOCK,
        ESCAPE,
        RANGE_CONTROL,
        TURN_EXIT,
        TURN_TRADE,
        EDGE_HIT,
        ENTRY_HIT,
        WALL_ENGAGE,
        RANGED,
        ARROW_GUARD,
        ARROW_DODGE,
        AIR_DODGE,
        AIR_CONTROL,
        AIR_ESCAPE,
        AIR_INTERRUPT,
        LAND_PUNISH,
        PUNISH_CRIT,
        RECOVER_BREAK,
        RECOVER_WARMUP,
        RANGED_PUNISH,
        CRIT_REPLY,
        AIR_TRADE,
        FORCED_TRADE,
        COUNTER_EXIT,
        RELOAD_ESCAPE,
        RELOAD_LOAD,
        ESCAPE_SHOT,
        ORBIT_BURST,
        ORBIT_TRADE,
        ORBIT_BACK;

    }
}


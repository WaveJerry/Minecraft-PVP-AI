package local.pvpbot.ai;

import java.util.function.BiPredicate;
import java.util.function.Consumer;

/** Ground movement only. Attacks, jump defense and projectile defense run before this chooser. */
final class GroundFootwork {
    // Reuse the existing per-bot DQN movement branch and its persistence/reward machinery.
    static final int BRANCH = 9, OFFSET = 32;
    static final int[] ACTIONS = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11};
    record Choice(PrecisionFootwork.Heading heading, boolean sprint, int action) {}

    static boolean active(CombatView view, NeuralLearner.Senses s) {
        return view.visible() && !view.ownShieldAvailable() && s.onGround
            && s.targetMotionFresh && s.estimateAge<=1.0
            && Double.isFinite(s.ownReachDistance) && Double.isFinite(s.targetReachDistance)
            && !AirborneEnvelope.relevant(s) && !s.usingRanged
            && !(s.projectilePlan != null && s.projectilePlan.threat());
    }

    static boolean[] allowGroundChoices(boolean[] mask, CombatView view, NeuralLearner.Senses s) {
        if (active(view, s)) for (int action : ACTIONS) mask[OFFSET + action] = true;
        return mask;
    }

    static double forward(int action) {
        return switch (action) {case 1,2,6,7,8,9 -> 1; case 3,10,11 -> -1; default -> 0;};
    }
    static double sideways(int action) {
        return switch (action) {case 4,6,8,10 -> -1; case 5,7,9,11 -> 1; default -> 0;};
    }

    // Match InitialCombatController.input / ArrowDodgePlanner's existing action layout.
    static boolean sprinting(int action) {return action==2 || action==8 || action==9;}

    static PrecisionFootwork.Heading control(PrecisionFootwork.Body own, PrecisionFootwork.Body target,
            boolean sprint, double minX, double maxX, double minZ, double maxZ,
            BiPredicate<Double,Double> clear, InitialCombatController controller,
            CombatView view, NeuralLearner.Senses senses) {
        return controller.groundHeading(own,target,sprint,minX,maxX,minZ,maxZ,clear,view,senses);
    }

    static PrecisionFootwork.Heading choose(PrecisionFootwork.Body own, PrecisionFootwork.Body target,
            boolean sprint, double minX, double maxX, double minZ, double maxZ,
            BiPredicate<Double,Double> clear, CombatView view, NeuralLearner.Senses s,
            ConstrainedTactics tactics) {
        return choose(own,target,sprint,minX,maxX,minZ,maxZ,clear,view,s,tactics,null);
    }

    static PrecisionFootwork.Heading choose(PrecisionFootwork.Body own, PrecisionFootwork.Body target,
            boolean sprint, double minX, double maxX, double minZ, double maxZ,
            BiPredicate<Double,Double> clear, CombatView view, NeuralLearner.Senses s,
            ConstrainedTactics tactics, Consumer<Boolean> sprintChoice) {
        Choice choice=chooseMotion(own,target,sprint,minX,maxX,minZ,maxZ,clear,view,s,tactics);
        if (choice==null) return null;
        if (sprintChoice!=null) sprintChoice.accept(choice.sprint());
        return choice.heading();
    }

    static Choice chooseMotion(PrecisionFootwork.Body own, PrecisionFootwork.Body target,
            boolean sprint, double minX, double maxX, double minZ, double maxZ,
            BiPredicate<Double,Double> clear, CombatView view, NeuralLearner.Senses s,
            ConstrainedTactics tactics) {
        if (ProjectileMovementPriority.owns(s)) return null;
        else if (!active(view,s) || !finite(own) || !finite(target)) return null;
        double dx=target.x()-own.x(), dz=target.z()-own.z(), length=Math.hypot(dx,dz);
        double fx=length>1e-8?dx/length:1, fz=length>1e-8?dz/length:0;
        boolean[] legal=new boolean[18];
        PrecisionFootwork.Heading[] headings=new PrecisionFootwork.Heading[18];
        double[] lower=new double[18], separation=new double[18], nextXs=new double[18], nextZs=new double[18];
        double reach=Math.min(s.ownReachDistance,s.targetReachDistance), bestLower=-Double.MAX_VALUE;
        for (int action : ACTIONS) {
            double f=forward(action), side=sideways(action), scale=Math.hypot(f,side);
            double x=scale==0?0:(fx*f-fz*side)/scale;
            double z=scale==0?0:(fz*f+fx*side)/scale;
            // Keep the existing physical step, arena and real-block checks.
            double nextX=own.x()+own.vx()*.546+x*.098*(sprinting(action)?1.3:1);
            double nextZ=own.z()+own.vz()*.546+z*.098*(sprinting(action)?1.3:1);
            boolean valid=action==0 || nextX>=minX && nextX<=maxX && nextZ>=minZ
                && nextZ<=maxZ && clear.test(x,z);
            if(valid) {
                legal[action]=true;headings[action]=new PrecisionFootwork.Heading(x,z,Double.NaN);
                nextXs[action]=nextX;nextZs[action]=nextZ;
                // A conservative lower bound from the LIVE eye-to-box distances and
                // our own step only. Moving away on an axis cannot shorten that axis;
                // inward components can shorten distance by at most their norm.
                // This is not a fabricated reach measurement or an opponent forecast.
                double inwardX=Math.max(0,Math.signum(dx)*(nextX-own.x()));
                double inwardZ=Math.max(0,Math.signum(dz)*(nextZ-own.z()));
                lower[action]=reach-Math.hypot(inwardX,inwardZ);
                separation[action]=Math.hypot(target.x()-nextX,target.z()-nextZ);
                bestLower=Math.max(bestLower,lower[action]);
            }
        }
        // Do not voluntarily cross legal melee reach while applying pressure. If
        // already inside, do not deepen it. If inertia makes every step unsafe,
        // retain only the least-inward physically available choices.
        boolean outside=reach>3.0, hasSafe=false;
        for(int action:ACTIONS)if(legal[action])
            hasSafe|=outside?lower[action]>3.0:lower[action]>=reach-1e-9;
        for(int action:ACTIONS)if(legal[action])
            legal[action]=hasSafe?(outside?lower[action]>3.0:lower[action]>=reach-1e-9)
                :lower[action]>=bestLower-1e-9;

        // No constant forward pressure. Only a charged weapon in the short
        // 0.3-block outer window biases a brief approach. Else all safe learned
        // directions remain available, with wall clearance as a soft prior.
        boolean seekAttack=outside && reach<=3.3 && view.ownAttackCharge()>=.999f;
        boolean canAdvance=false;
        if(seekAttack && hasSafe) for(int action:ACTIONS)
            canAdvance|=legal[action] && forward(action)>0;
        if(canAdvance) for(int action:ACTIONS)
            if(forward(action)<=0) legal[action]=false;

        int fallback=-1;
        if(outside && hasSafe) {
            // This is a prior for the existing DQN, not a forced learned answer.
            for(int action:seekAttack?new int[]{1,2,6,7,8,9,0,4,5,3,10,11}:new int[]{0,4,5,3,10,11,1,2,6,7,8,9})if(legal[action]) {fallback=action;break;}
        } else {
            double best=-Double.MAX_VALUE;
            for(int action:ACTIONS)if(legal[action] && separation[action]>best) {
                fallback=action;best=separation[action];
            }
        }
        if (fallback<0)return null;
        // This changes only the small existing fallback prior. Learned values and
        // exploration still choose among all physically/reach-safe actions above.
        boolean rearClear=!s.retreatBlocked && clear.test(-fx,-fz);
        double best=WallPositioning.preference(own.x(),own.z(),target.x(),target.z(),
            nextXs[fallback],nextZs[fallback],minX,maxX,minZ,maxZ,rearClear);
        for(int action:ACTIONS) if(legal[action]) {
            double score=WallPositioning.preference(own.x(),own.z(),target.x(),target.z(),
                nextXs[action],nextZs[action],minX,maxX,minZ,maxZ,rearClear);
            if(score>best+.01) {fallback=action;best=score;}
        }
        int chosen=tactics==null?fallback:tactics.chooseGround(view,s,fallback,legal);
        if(chosen<0 || chosen>=legal.length || !legal[chosen])chosen=fallback;
        return new Choice(headings[chosen],sprinting(chosen),chosen);
    }

    private static boolean finite(PrecisionFootwork.Body body) {
        return Double.isFinite(body.x()) && Double.isFinite(body.z())
            && Double.isFinite(body.vx()) && Double.isFinite(body.vz());
    }
}

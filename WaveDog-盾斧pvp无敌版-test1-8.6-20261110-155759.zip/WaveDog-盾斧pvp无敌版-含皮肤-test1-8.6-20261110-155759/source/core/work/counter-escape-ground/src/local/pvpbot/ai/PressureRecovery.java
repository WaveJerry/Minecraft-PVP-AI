package local.pvpbot.ai;

/**
 * Recharge state after a confirmed damaging ground-pressure hit.
 * The controller owns hit qualification, emergency priority and lifecycle reset;
 * footwork owns whether a retreat step has real collision-free space.
 */
final class PressureRecovery {
    static final double FULL_CHARGE = .999;
    static final long NO_TICK = Long.MIN_VALUE;

    private boolean active;
    private long activeSince = NO_TICK;
    private boolean hasConfirmedHit;
    private long lastConfirmedHit = NO_TICK;

    /** Arm only from the controller's confirmed damaging PRESSURE-hit hook. */
    boolean confirmedHit(long tick) {
        if (hasConfirmedHit && tick <= lastConfirmedHit) return false;
        hasConfirmedHit = true;
        lastConfirmedHit = tick;
        activeSince = tick;
        active = true;
        return true;
    }

    /** A real weapon switch also invalidates the previous weapon's charge snapshot. */
    void weaponChanged(long tick) {
        activeSince = tick;
        active = true;
    }

    /**
     * Use the current weapon's actual charge, rather than elapsed-time estimates.
     * The hit tick always recovers: its charge snapshot may precede the attack.
     * Invalid charge cannot manufacture a recharged weapon.
     */
    boolean recoveryActive(long tick, double actualWeaponCharge) {
        if (!active) return false;
        if (tick > activeSince && Double.isFinite(actualWeaponCharge)
                && actualWeaponCharge >= FULL_CHARGE) {
            active = false;
            activeSince = NO_TICK;
        }
        return active;
    }

    long activeSince() {
        return activeSince;
    }

    /** Reset alongside the controller's existing target/death/disable lifecycle. */
    void reset() {
        active = false;
        activeSince = NO_TICK;
        hasConfirmedHit = false;
        lastConfirmedHit = NO_TICK;
    }
}

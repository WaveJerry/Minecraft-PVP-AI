package local.pvpbot.ai;

import java.util.*;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.CrossbowMeta;

/** Round preparation only. A loaded projectile is debited from the finite kit. */
final class RoundCrossbowKit {
    static void preload(Player player) {
        var inv=player.getInventory();
        for(int slot=0;slot<inv.getSize();slot++) {
            var bow=inv.getItem(slot);
            if(bow==null||bow.getType()!=Material.CROSSBOW||!(bow.getItemMeta() instanceof CrossbowMeta meta)||meta.hasChargedProjectiles())continue;
            for(int ammo=0;ammo<inv.getSize();ammo++) {
                var arrows=inv.getItem(ammo);
                if(arrows==null||arrows.getType()!=Material.ARROW||arrows.getAmount()<1)continue;
                var projectile=arrows.clone();projectile.setAmount(1);
                var loaded=bow.clone();meta.setChargedProjectiles(List.of(projectile));
                if(!loaded.setItemMeta(meta))break;
                var remainder=arrows.clone();remainder.setAmount(arrows.getAmount()-1);
                inv.setItem(slot,loaded);inv.setItem(ammo,remainder.getAmount()==0?null:remainder);break;
            }
        }
    }
    static KitLayout capture(List<String> rows,int held,Player player) {
        int loaded=0;
        for(var item:player.getInventory().getContents())
            if(item!=null&&item.getType()==Material.CROSSBOW&&item.getItemMeta() instanceof CrossbowMeta meta)
                for(var projectile:meta.getChargedProjectiles())if(projectile.getType()==Material.ARROW)loaded+=projectile.getAmount();
        return KitLayout.parse(normalizeRows(rows,loaded),held);
    }
    /** Save slot layout in the old format, counting stored plus loaded ammunition once. */
    static List<String> normalizeRows(List<String> rows,int loaded) {
        if(loaded<0)throw new IllegalArgumentException("Negative loaded ammunition");
        var result=new ArrayList<>(rows);if(loaded==0)return result;
        var used=new HashSet<Integer>();
        for(int i=0;i<result.size();i++) {
            var parts=result.get(i).split(",");used.add(Integer.parseInt(parts[0]));
            if(parts[1].equals("ARROW")) {
                result.set(i,parts[0]+",ARROW,"+(Integer.parseInt(parts[2])+loaded));return result;
            }
        }
        for(int slot=0;slot<36;slot++)if(!used.contains(slot)){result.add(slot+",ARROW,"+loaded);return result;}
        throw new IllegalArgumentException("No slot for ammunition layout");
    }
}

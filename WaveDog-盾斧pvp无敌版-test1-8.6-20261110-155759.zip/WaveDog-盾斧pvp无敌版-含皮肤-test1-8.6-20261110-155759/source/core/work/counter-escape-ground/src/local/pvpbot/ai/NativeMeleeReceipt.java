package local.pvpbot.ai;

import java.util.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;

/** A planned critical is complete only after a real, uncancelled critical damage event. */
final class NativeMeleeReceipt implements Listener {
    private static final Map<UUID, Attempt> pending = new HashMap<>();
    private static final class Attempt {
        final UUID target; double damage; boolean critical;EntityDamageByEntityEvent event;
        Attempt(Entity target) { this.target=target.getUniqueId(); }
    }
    static void attack(Player own, Entity target, InitialCombatController controller) {
        controller.nativeMeleeOutcome(false, false);
        boolean critical = controller.criticalIntent();
        if (critical) {
            if(target instanceof Player guarded && CombatInputHooks.effectiveShield(own,guarded)) {
                CombatOutcomeTrace.note(own,"CRITICAL_HELD_EFFECTIVE_SHIELD");return;
            }
            own.setSprinting(false);
            if (!NativeCriticalState.read(own).now()) {
                CombatOutcomeTrace.note(own, "CRITICAL_REJECTED_NATIVE_STATE"); return;
            }
        }
        if (!(target instanceof Player victim) || !own.hasLineOfSight(victim)
                || !MeleeReach.permits(CombatInputHooks.eyeBox(own,victim),3)) {
            CombatOutcomeTrace.note(own, "ATTACK_REJECTED_LIVE_REACH_OR_LINE"); return;
        }
        var attempt = new Attempt(target);
        pending.put(own.getUniqueId(), attempt);
        try { own.attack(target); }
        finally {
            pending.remove(own.getUniqueId());
            if(attempt.event!=null) {
                attempt.damage=attempt.event.isCancelled()?0:Math.max(0,attempt.event.getFinalDamage());
                attempt.critical=attempt.event.isCritical();
            }
            controller.nativeMeleeOutcome(attempt.damage > 0, attempt.damage > 0 && attempt.critical);
            CombatOutcomeTrace.note(own, "ATTACK_RESULT damage="+attempt.damage+" critical="+attempt.critical+" requestedCritical="+critical);
        }
    }
    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void damage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player own)
                || event.getCause()!=EntityDamageEvent.DamageCause.ENTITY_ATTACK) return;
        var attempt=pending.get(own.getUniqueId());
        if (attempt==null || !attempt.target.equals(event.getEntity().getUniqueId())) return;
        attempt.damage=Math.max(0,event.getFinalDamage());
        attempt.critical=event.isCritical();
        attempt.event=event;
    }
}

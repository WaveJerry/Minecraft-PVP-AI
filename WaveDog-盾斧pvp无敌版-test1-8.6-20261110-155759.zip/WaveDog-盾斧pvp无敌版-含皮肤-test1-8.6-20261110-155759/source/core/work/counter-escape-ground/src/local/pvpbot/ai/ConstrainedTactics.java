/*
 * Decompiled with CFR 0.152.
 */
package local.pvpbot.ai;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.FileAttribute;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import local.pvpbot.ai.ArrowDodgePlanner;
import local.pvpbot.ai.CombatView;
import local.pvpbot.ai.GroundFootwork;
import local.pvpbot.ai.NeuralLearner;
import local.pvpbot.ai.TinyQNetwork;

final class ConstrainedTactics {
    static final int SIDE = 0;
    static final int OPENING = 1;
    static final int ORBIT = 2;
    static final int RANGED = 3;
    static final int DRAW = 4;
    static final int RELOAD = 5;
    static final int LEAD = 6;
    static final int ROUTE = 7;
    static final int SPACING = 8;
    static final int DODGE = 9;
    static final int PRESSURE = 10;
    static final int INPUTS = 62;
    private static final int[] SIZE = new int[]{3, 4, 3, 3, 4, 3, 7, 2, 3, 18, 3};
    private static final int[] OFFSET = new int[SIZE.length];
    static final int OUTPUTS;
    private static final double[] LEADS;
    private static final int[] DRAWS;
    private final TinyQNetwork online;
    private final TinyQNetwork target;
    private final Random random;
    private final Path file;
    private final Sample[] replay = new Sample[2048];
    private final ArrayList<String> rows = new ArrayList<>();
    private double[] state;
    private boolean[] legal;
    private boolean[] used = new boolean[SIZE.length];
    private int[] selected = new int[SIZE.length];
    private long selectedAt;
    private long nextChoice;
    private long now;
    private long updates;
    private long samples;
    private long explorations;
    private long batches;
    private int count;
    private int cursor;
    private double reward;
    private double loss;
    private double lastCenter = Double.NaN;
    private boolean enabled;
    private boolean training;
    private boolean dirty = true;

    ConstrainedTactics(Path path, long l) {
        this.file = path;
        this.random = new Random(l);
        this.online = new TinyQNetwork(62, OUTPUTS, l);
        this.target = new TinyQNetwork(62, OUTPUTS, l + 1L);
        if (Files.exists(path, new LinkOption[0])) {
            try (DataInputStream dataInputStream = new DataInputStream(new BufferedInputStream(Files.newInputStream(path, new OpenOption[0])));){
                if (!dataInputStream.readUTF().equals("PVPBOT-CONSTRAINED-DQN-5") || dataInputStream.readInt() != 62 || dataInputStream.readInt() != OUTPUTS) {
                    throw new IOException("Tactical model format");
                }
                this.updates = dataInputStream.readLong();
                this.samples = dataInputStream.readLong();
                this.explorations = dataInputStream.readLong();
                this.batches = dataInputStream.readLong();
                this.online.read(dataInputStream);
                this.dirty = false;
            }
            catch (IOException iOException) {
                throw new IllegalStateException("Cannot read tactical model " + String.valueOf(path), iOException);
            }
        }
        this.target.copyFrom(this.online);
    }

    boolean enabled() {
        return this.enabled;
    }

    boolean training() {
        return this.training;
    }

    void hardFootworkOverride() {
        this.used[0] = false;
        this.used[10] = false;
        this.used[8] = false;
    }

    void freeze() {
        if (this.training) {
            this.finish(0.0);
        }
        this.enabled = true;
        this.training = false;
        this.reset();
    }

    void enable(boolean bl) {
        if (this.enabled && !bl) {
            this.finish(0.0);
        }
        this.enabled = bl;
        this.training = bl;
        this.reset();
    }

    void reset() {
        this.state = null;
        this.legal = null;
        Arrays.fill(this.used, false);
        this.reward = 0.0;
        this.nextChoice = 0L;
        this.lastCenter = Double.NaN;
    }

    void reward(double d) {
        if (this.training && Double.isFinite(d)) {
            this.reward += d;
        }
    }

    void begin(CombatView combatView, NeuralLearner.Senses senses) {
        if (!this.enabled) {
            return;
        }
        this.now = combatView.tick();
        if (Double.isFinite(this.lastCenter) && Double.isFinite(senses.centerDistance)) {
            this.reward(0.002 * (this.lastCenter - senses.centerDistance));
        }
        this.lastCenter = senses.centerDistance;
        double[] dArray = this.features(combatView, senses);
        boolean[] blArray = this.mask(combatView, senses);
        if (!(this.state == null || this.now < this.nextChoice && Arrays.equals(blArray, this.legal))) {
            this.close(dArray, blArray, false);
        }
        if (this.state == null) {
            this.state = dArray;
            this.legal = blArray;
            this.selectedAt = this.now;
            this.nextChoice = this.now + 4L;
            Arrays.fill(this.used, false);
        }
    }

    int choose(int n, int n2) {
        return this.choose(n, n2, null);
    }

    /** Opt into one-tick observations only when ground movement is executed. */
    int chooseGround(CombatView view, NeuralLearner.Senses senses, int fallback, boolean[] choices) {
        if (this.enabled && this.state != null && this.selectedAt != view.tick()) {
            double[] next = this.features(view, senses);
            boolean[] nextLegal = this.mask(view, senses);
            this.close(next, nextLegal, false);
            this.state = next;
            this.legal = nextLegal;
            this.now = view.tick();
            this.selectedAt = this.now;
            this.nextChoice = this.now + 4L;
        }
        int action = this.choose(DODGE, fallback, choices);
        if (this.enabled && this.state != null) {
            this.nextChoice = Math.min(this.nextChoice, this.now + 1L);
        }
        return action;
    }

    int choose(int n, int n2, boolean[] blArray) {
        double d;
        if (n == 2) {
            return 1;
        }
        if (!this.enabled || this.state == null) {
            return n2;
        }
        boolean[] blArray2 = new boolean[SIZE[n]];
        int n3 = 0;
        for (int i = 0; i < blArray2.length; ++i) {
            boolean bl = blArray2[i] = this.legal[OFFSET[n] + i] && (blArray == null || i < blArray.length && blArray[i]);
            if (!blArray2[i]) continue;
            ++n3;
        }
        if (n3 == 0) {
            return n2;
        }
        if (this.used[n] && blArray2[this.selected[n]]) {
            return this.selected[n];
        }
        double[] dArray = this.online.predict(this.state);
        int n4 = -1;
        double d2 = 0.03 / Math.sqrt(1.0 + (double)this.updates / 200.0);
        for (int i = 0; i < blArray2.length; ++i) {
            if (!blArray2[i]) continue;
            if (n4 >= 0) {
                double d3 = dArray[OFFSET[n] + i] + (i == n2 ? d2 : 0.0);
                double d4 = dArray[OFFSET[n] + n4];
                double d5 = n4 == n2 ? d2 : 0.0;
                if (!(d3 > d4 + d5)) continue;
            }
            n4 = i;
        }
        double d6 = d = this.training ? Math.max(0.04, 0.18 / Math.sqrt(1.0 + (double)this.samples / 3000.0)) : 0.0;
        if (n3 > 1 && this.random.nextDouble() < d) {
            int n5 = this.random.nextInt(n3);
            for (int i = 0; i < blArray2.length; ++i) {
                if (!blArray2[i] || n5-- != 0) continue;
                n4 = i;
                break;
            }
            ++this.explorations;
        }
        this.selected[n] = n4;
        this.used[n] = n3 > 1;
        return n4;
    }

    int dodge(ArrowDodgePlanner.Result result) {
        boolean[] blArray = result.safeMoves();
        boolean[] blArray2 = result.viableMoves();
        boolean[] blArray3 = new boolean[18];
        boolean bl = false;
        for (int i = 0; i < 17; ++i) {
            blArray3[i] = i < blArray.length && i < blArray2.length && blArray[i] && blArray2[i];
            bl |= blArray3[i];
        }
        return bl ? this.choose(9, result.preferredMove(), blArray3) : result.preferredMove();
    }

    int draw(boolean bl) {
        return DRAWS[this.choose(4, bl ? 1 : 3)];
    }

    double lead() {
        return LEADS[this.choose(6, 3)];
    }

    long updates() {
        return this.updates;
    }

    long samples() {
        return this.samples;
    }

    long explorations() {
        return this.explorations;
    }

    int replaySize() {
        return this.count;
    }

    double loss() {
        return this.loss;
    }

    void finish(double d) {
        if (this.enabled) {
            this.reward(d * 2.0);
            if (this.state != null) {
                this.close(null, null, true);
            }
        }
        this.reset();
    }

    private void close(double[] dArray, boolean[] blArray, boolean bl) {
        boolean bl2 = false;
        for (boolean bl3 : this.used) {
            bl2 |= bl3;
        }
        if (bl2 && this.training) {
            double d = Math.max(-8.0, Math.min(8.0, this.reward));
            this.replay[this.cursor] = new Sample(this.state, (int[])this.selected.clone(), (boolean[])this.used.clone(), d, dArray, blArray, (int)Math.max(1L, this.now - this.selectedAt), bl);
            this.cursor = (this.cursor + 1) % this.replay.length;
            this.count = Math.min(this.replay.length, this.count + 1);
            ++this.samples;
            this.dirty = true;
            if (this.rows.size() < 4096) {
                this.rows.add(this.selectedAt + "," + d + "," + bl + "," + Arrays.toString(this.selected).replace(',', ';') + "," + Arrays.toString(this.used).replace(',', ';'));
            }
            if (this.count >= 32 && this.samples % 8L == 0L) {
                this.train();
            }
        }
        this.state = null;
        this.reward = 0.0;
        Arrays.fill(this.used, false);
    }

    private void train() {
        double d = 0.0;
        for (int i = 0; i < 8; ++i) {
            Sample sample = this.replay[this.random.nextInt(this.count)];
            double[] dArray = sample.terminal ? null : this.online.predict(sample.next);
            double[] dArray2 = sample.terminal ? null : this.target.predict(sample.next);
            int n = 0;
            for (boolean n2 : sample.used) {
                if (!n2) continue;
                ++n;
            }
            int[] objectArray = new int[n];
            double[] dArray3 = new double[n];
            int n3 = 0;
            for (int n2 = 0; n2 < SIZE.length; ++n2) {
                if (!sample.used[n2]) continue;
                double d2 = 0.0;
                int n4 = -1;
                if (!sample.terminal) {
                    for (int j = 0; j < SIZE[n2]; ++j) {
                        int n5 = OFFSET[n2] + j;
                        if (!sample.legal[n5] || n4 >= 0 && !(dArray[n5] > dArray[n4])) continue;
                        n4 = n5;
                    }
                }
                if (n4 >= 0) {
                    d2 = dArray2[n4];
                }
                objectArray[n3] = OFFSET[n2] + sample.actions[n2];
                dArray3[n3++] = sample.reward + Math.pow(0.997, sample.ticks) * d2;
            }
            d += this.online.train(sample.state, objectArray, dArray3, 5.0E-4);
            ++this.updates;
        }
        this.loss = d / 8.0;
        ++this.batches;
        if (this.batches % 128L == 0L) {
            this.target.copyFrom(this.online);
        }
    }

    private boolean[] mask(CombatView combatView, NeuralLearner.Senses senses) {
        boolean bl;
        boolean[] blArray = new boolean[OUTPUTS];
        Arrays.fill(blArray, true);
        Arrays.fill(blArray, OFFSET[2], OFFSET[2] + SIZE[2], false);
        blArray[ConstrainedTactics.OFFSET[2] + 1] = true;
        blArray[ConstrainedTactics.OFFSET[3]] = senses.bowPresent && combatView.hasArrows();
        blArray[ConstrainedTactics.OFFSET[3] + 1] = senses.crossbowPresent && (combatView.hasArrows() || senses.crossbowLoaded);
        blArray[ConstrainedTactics.OFFSET[7] + 1] = bl = senses.withdrawing && senses.targetMotionFresh && senses.escapeViable && !combatView.nearWall() && !senses.retreatBlocked && senses.ownReachDistance > 3.3 && senses.targetReachDistance > 3.3 && Math.min(senses.ownReachDistance, senses.targetReachDistance) < 9.0;
        Arrays.fill(blArray, OFFSET[9], OFFSET[9] + 18, false);
        if (senses.projectilePlan != null && senses.projectilePlan.threat()) {
            boolean[] blArray2 = senses.projectilePlan.safeMoves();
            boolean[] blArray3 = senses.projectilePlan.viableMoves();
            for (int i = 0; i < 17; ++i) {
                blArray[ConstrainedTactics.OFFSET[9] + i] = i < blArray2.length && i < blArray3.length && blArray2[i] && blArray3[i];
            }
        }
        return GroundFootwork.allowGroundChoices(blArray, combatView, senses);
    }

    private double[] features(CombatView combatView, NeuralLearner.Senses senses) {
        double[] dArray = new double[]{combatView.distance() / 32.0, senses.ownReachDistance / 6.0, senses.targetReachDistance / 6.0, senses.separationSpeed / 0.5, senses.ownShieldCooldown / 100.0, senses.targetBreakAge / 100.0, senses.targetLowerAge / 20.0, senses.targetTurnAge / 20.0, combatView.ownAttackCharge(), senses.health / 20.0, senses.food / 20.0, senses.arrows / 5.0, (double)combatView.bowDrawTicks() / 20.0, ConstrainedTactics.bit(combatView.ownCrossbowCharged()), ConstrainedTactics.bit(senses.targetCharged), ConstrainedTactics.bit(combatView.ownShieldAvailable()), ConstrainedTactics.bit(senses.targetShieldRaised), ConstrainedTactics.bit(senses.targetShieldDisabled), senses.targetFacingDot, senses.targetForward / 0.4, senses.targetSide / 0.4, senses.targetY / 0.6, senses.ownForward / 0.4, senses.ownSide / 0.4, senses.ownY / 0.6, ConstrainedTactics.bit(senses.onGround), ConstrainedTactics.bit(senses.targetAirborne), ConstrainedTactics.bit(senses.targetCritThreat), ConstrainedTactics.bit(senses.comboPursuit), ConstrainedTactics.bit(senses.withdrawing), ConstrainedTactics.bit(combatView.nearWall()), ConstrainedTactics.bit(senses.retreatBlocked), ConstrainedTactics.bit(senses.escapeViable), senses.chaseReachTicks / 17.0, senses.chaseClosingMargin / 3.0, senses.targetAttackAge / 20.0, senses.damageAge / 20.0, senses.threatEta / 30.0, senses.threatMiss / 3.0, senses.threatSide / 16.0, senses.threatForward / 16.0, senses.threatVSide / 3.0, senses.threatVForward / 3.0, ConstrainedTactics.bit(senses.usingRanged), ConstrainedTactics.bit(senses.shieldCoversRanged), ConstrainedTactics.bit(senses.shieldShouldRaise), (double)senses.opportunity.ordinal() / 4.0, ConstrainedTactics.bit(senses.closeRangedGuard), senses.centerDistance / 32.0, senses.centerForward, senses.centerSide, senses.ownKnockbackAge / 20.0, (double)senses.ownWeapon / 3.0, ConstrainedTactics.bit(!combatView.targetAxe() && !senses.targetSword), ConstrainedTactics.bit(senses.wallEscapeAvailable), ConstrainedTactics.bit(senses.enteredReach), senses.orbitRadius / 2.0, ConstrainedTactics.bit(senses.risingPlan != null && senses.risingPlan.feasible()), senses.risingPlan == null ? -1.0 : (double)senses.risingPlan.ticks() / 6.0, senses.estimatedMeleeDamage / 15.0, senses.estimatedArrowDamage / 15.0, senses.risingPlan == null ? 0.0 : senses.risingPlan.ascentLeft() / 8.0};
        if (dArray.length != 62) {
            throw new IllegalStateException("Tactical observation layout");
        }
        for (int i = 0; i < dArray.length; ++i) {
            dArray[i] = Double.isFinite(dArray[i]) ? Math.max(-2.0, Math.min(2.0, dArray[i])) : 0.0;
        }
        return dArray;
    }

    private static int bit(boolean bl) {
        return bl ? 1 : 0;
    }

    void save() throws IOException {
        Path path;
        if (this.dirty || !Files.exists(this.file, new LinkOption[0])) {
            Files.createDirectories(this.file.getParent(), new FileAttribute[0]);
            path = this.file.resolveSibling(String.valueOf(this.file.getFileName()) + ".tmp");
            try (DataOutputStream dataOutputStream = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(path, new OpenOption[0])));){
                dataOutputStream.writeUTF("PVPBOT-CONSTRAINED-DQN-5");
                dataOutputStream.writeInt(62);
                dataOutputStream.writeInt(OUTPUTS);
                dataOutputStream.writeLong(this.updates);
                dataOutputStream.writeLong(this.samples);
                dataOutputStream.writeLong(this.explorations);
                dataOutputStream.writeLong(this.batches);
                this.online.write(dataOutputStream);
            }
            try {
                Files.move(path, this.file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            }
            catch (AtomicMoveNotSupportedException atomicMoveNotSupportedException) {
                Files.move(path, this.file, StandardCopyOption.REPLACE_EXISTING);
            }
            this.dirty = false;
        }
        if (!this.rows.isEmpty()) {
            path = this.file.resolveSibling(String.valueOf(this.file.getFileName()) + ".csv");
            if (!Files.exists(path, new LinkOption[0])) {
                Files.writeString(path, (CharSequence)"tick,reward,terminal,actions,used\n", new OpenOption[0]);
            }
            Files.writeString(path, (CharSequence)(String.join((CharSequence)"\n", this.rows) + "\n"), StandardOpenOption.APPEND);
            this.rows.clear();
        }
    }

    static {
        int n = 0;
        for (int i = 0; i < SIZE.length; ++i) {
            ConstrainedTactics.OFFSET[i] = n;
            n += SIZE[i];
        }
        OUTPUTS = n;
        LEADS = new double[]{-0.25, 0.0, 0.5, 1.0, 1.25, 1.6, 2.0};
        DRAWS = new int[]{8, 10, 16, 20};
    }

    private record Sample(double[] state, int[] actions, boolean[] used, double reward, double[] next, boolean[] legal, int ticks, boolean terminal) {
    }
}


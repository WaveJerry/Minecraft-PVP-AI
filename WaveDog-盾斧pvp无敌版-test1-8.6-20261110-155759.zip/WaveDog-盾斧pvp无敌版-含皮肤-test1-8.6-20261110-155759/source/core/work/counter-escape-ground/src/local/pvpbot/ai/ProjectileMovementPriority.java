package local.pvpbot.ai;

/** One movement owner: a viable projectile defence precedes ordinary/learned footwork. */
final class ProjectileMovementPriority {
    static boolean owns(NeuralLearner.Senses s) {
        var plan=s.projectilePlan;
        if(s.ownShieldCooldown<=0&&(s.closeRangedGuard||s.shieldCoversRanged||s.shieldShouldRaise))return true;
        if(plan==null||!plan.threat())return false;
        if(s.ownShieldCooldown<=0)return true;
        for(int i=0;i<plan.safeMoves().length;i++)
            if(plan.safeMoves()[i]&&plan.viableMoves()[i])return true;
        return false;
    }
}

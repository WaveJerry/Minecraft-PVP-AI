package local.pvpbot.ai;

import java.lang.reflect.*;
import java.util.*;
import org.bukkit.plugin.java.JavaPlugin;

/** Human duels reuse WaveDog's entity, while each profile retains its own learner and bandit. */
final class DuelModels {
    private record Binding(CombatPolicy policy, NeuralLearner learner, Object bandit) {}
    private static final class State {
        final Map<String,Binding> bindings=new HashMap<>();String active="test1";
    }
    private static final Map<JavaPlugin,State> states=new WeakHashMap<>();
    static String profile(String raw) {
        String p=raw.toLowerCase(Locale.ROOT);
        return Set.of("test1","test2","uhc1","uhc2").contains(p)?p:null;
    }
    static String active(JavaPlugin plugin) {var s=states.get(plugin);return s==null?"test1":s.active;}
    private static Object read(Object host,String key) {
        try {var f=host.getClass().getDeclaredField(key);f.setAccessible(true);return f.get(host);}
        catch(ReflectiveOperationException e){throw new IllegalStateException(e);}
    }
    private static void write(Object host,String key,Object value) {
        try {var f=host.getClass().getDeclaredField(key);f.setAccessible(true);f.set(host,value);}
        catch(ReflectiveOperationException e){throw new IllegalStateException(e);}
    }
    private static Binding binding(Object brain) {return new Binding((CombatPolicy)read(brain,"policy"),(NeuralLearner)read(brain,"learner"),read(brain,"bandit"));}
    private static void save(JavaPlugin plugin) {
        try {var m=plugin.getClass().getDeclaredMethod("saveLearning");m.setAccessible(true);m.invoke(plugin);}
        catch(ReflectiveOperationException e){throw new IllegalStateException(e);}
    }
    static void activate(JavaPlugin plugin,String raw) {
        String id=profile(raw);if(id==null)throw new IllegalArgumentException("Unknown model: "+raw);
        Object bait=read(plugin,"bait"),pressure=read(plugin,"pressure");
        State state=states.computeIfAbsent(plugin,p->{var s=new State();s.bindings.put("test1",binding(bait));s.bindings.put("test2",binding(pressure));return s;});
        if(state.active.equals(id))return;
        save(plugin); // Save the departing model before replacing the active reference.
        Binding next=state.bindings.get(id);
        if(next==null) {
            CombatPolicy policy=id.equals("uhc1")?new UHC1():new UHC2();
            // Separate preview storage; do not overwrite the cold 0.11.6/UHC archives.
            var learner=new NeuralLearner(plugin.getDataFolder().toPath().resolve("models-ground-uhc-entry-v1/"+id+".nn"),id.equals("uhc1")?96121L:96122L,policy);
            learner.useInitialRules();
            try {
                var ctor=read(bait,"bandit").getClass().getDeclaredConstructor(plugin.getClass(),String.class);ctor.setAccessible(true);
                next=new Binding(policy,learner,ctor.newInstance(plugin,id));
            }catch(ReflectiveOperationException e){throw new IllegalStateException(e);}
            state.bindings.put(id,next);
        }
        String mode=plugin.getConfig().getString("tactical-policy-mode","initial");
        if(mode.equalsIgnoreCase("frozen"))next.learner.tacticalFreeze();else next.learner.tacticalLearning(mode.equalsIgnoreCase("learn"));
        write(bait,"policy",next.policy);write(bait,"learner",next.learner);write(bait,"bandit",next.bandit);state.active=id;
    }
}

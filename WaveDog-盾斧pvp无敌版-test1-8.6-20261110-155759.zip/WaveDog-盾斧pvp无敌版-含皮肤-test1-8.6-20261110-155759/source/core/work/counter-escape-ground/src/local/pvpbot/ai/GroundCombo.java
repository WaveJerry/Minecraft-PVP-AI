package local.pvpbot.ai;

/** A renewable opportunity after confirmed melee damage, never a fixed click loop. */
final class GroundCombo {
    static boolean edge(double reach) { return Double.isFinite(reach)&&reach>=2.96&&reach<=3; }
    private long hitAt=-1000;
    void hit(long tick) { hitAt=tick; }
    void reset() { hitAt=-1000; }
    boolean active(long tick) { return hitAt>=0 && tick>hitAt && tick-hitAt<=32; }
    boolean canHit(long tick,double reach,boolean targetGrounded,double landAge,
                   int immunity,int maximumImmunity) {
        return active(tick) && edge(reach) && targetGrounded
            && landAge>=0 && landAge<=4 && maximumImmunity>0
            && immunity<=maximumImmunity/2;
    }
}

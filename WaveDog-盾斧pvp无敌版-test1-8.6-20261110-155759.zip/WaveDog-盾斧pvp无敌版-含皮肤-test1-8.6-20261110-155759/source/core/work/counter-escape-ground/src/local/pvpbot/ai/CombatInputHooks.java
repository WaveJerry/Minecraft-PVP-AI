package local.pvpbot.ai;

import org.bukkit.Material;
import org.bukkit.entity.Player;

/** Native inputs only: no damage, reach, cooldown, velocity or teleport changes. */
final class CombatInputHooks {
    static boolean chargeAllowed(float charge, boolean opportunity, Player own, org.bukkit.entity.Entity target, InitialCombatController controller) {
        if(controller.comboStrike()) {
            return target instanceof Player opponent&&own.isOnGround()&&opponent.isOnGround()
                &&GroundCombo.edge(eyeBox(own,opponent))&&!effectiveShield(own,opponent)
                &&opponent.getNoDamageTicks()<=opponent.getMaximumNoDamageTicks()/2
                &&Float.isFinite(charge)&&charge>=0;
        }
        if(controller.contactReply()) {
            return target instanceof Player opponent&&!effectiveShield(own,opponent)
                &&MeleeReach.permits(eyeBox(own,opponent),3.0)&&Float.isFinite(charge)&&charge>=0;
        }
        if(controller.proactiveStrike()) {
            return target instanceof Player opponent&&own.isOnGround()&&opponent.isOnGround()
                &&MeleeReach.permits(eyeBox(own,opponent),3.0)&&!effectiveShield(own,opponent)
                &&Float.isFinite(charge)&&charge>=.999f;
        }
        if(controller.exchangeCritical() && target instanceof Player opponent && effectiveShield(own,opponent)) return false;
        if (OpportunityStrike.chargeAllowed(charge, opportunity)) return true;
        return ((controller.closeRechargeReply()||controller.wallDamageReply()
                ||controller.shieldPressure()&&target instanceof Player shielded&&effectiveShield(own,shielded)) && Float.isFinite(charge) && charge >= 0 || controller.hopCriticalCharge(own.getCooledAttackStrength(.5f)))
            && target instanceof Player opponent && own.getWorld().equals(opponent.getWorld())
            && own.hasLineOfSight(opponent) && MeleeReach.permits(eyeBox(own, opponent), 3.0);
    }
    static boolean criticalCharge(float charge, Player own, InitialCombatController controller) {
        return charge >= .999f || controller.hopCriticalCharge(own.getCooledAttackStrength(.5f));
    }
    static boolean effectiveShield(Player own,Player target) {
        if(!target.isBlocking())return false; // Native delay (normally five ticks) already elapsed.
        var direction=target.getLocation().getDirection();
        return direction.getX()*(own.getX()-target.getX())+direction.getZ()*(own.getZ()-target.getZ())>0;
    }

    static void finishFrame(PvPArenaAI plugin,Player own,CombatMemory memory,InitialCombatController controller,
                            Player target,CombatView view,NeuralLearner.Senses senses) {
        var flightLook=controller.takeFlightLook();
        // The original ARROW_GUARD/ARROW_DODGE path has already applied the
        // predicted input. No exchange, guard-grace or learned restore may overwrite it.
        if(ProjectileMovementPriority.owns(senses))return;
        if(flightLook!=null) {
            // Restore the exact pre-attack escape line even if old memory flags, a
            // same-tick retreat debounce or arena routing reject resumeRetreatInputs.
            // This is still the existing jump: no extra impulse, tick or velocity write.
            OffhandRangedSupport.invoke(plugin,"applyLook",new Class<?>[]{Player.class,float.class,float.class},own,flightLook.yaw(),flightLook.pitch());
            OffhandRangedSupport.invoke(plugin,"move",new Class<?>[]{Player.class,Motion.class,boolean.class,boolean.class,boolean.class},own,Motion.FORWARD,false,true,true);
            memory.retreatCameraActive=true;
            return;
        }
        if(controller.exchangeShieldGrace()&&!own.hasCooldown(Material.SHIELD)) {
            memory.guardReentryPending=true;
            OffhandRangedSupport.invoke(plugin,"shieldTick",new Class<?>[]{Player.class,boolean.class},own,true);
        }
        if(controller.consumeTradeHopRestart()) {
            memory.melee.requestWithdrawal();memory.melee.useEscapeSword(true);
            memory.retreatOpened=false;memory.lastStealRetreat=view.tick();
            OffhandRangedSupport.invoke(plugin,"selectWeapon",new Class<?>[]{Player.class,CombatMemory.class,Weapon.class,boolean.class},own,memory,Weapon.SWORD,true);
            OffhandRangedSupport.invoke(plugin,"resumeRetreatInputs",new Class<?>[]{Player.class,CombatMemory.class,boolean.class},own,memory,false);
            return;
        }
        if(controller.exchangeWaiting()&&controller.exchangeHeading()!=null) {
            var heading=controller.exchangeHeading();
            OffhandRangedSupport.invoke(plugin,"turnToDirection",new Class<?>[]{Player.class,org.bukkit.util.Vector.class,float.class},own,new org.bukkit.util.Vector(heading.x(),0,heading.z()),180f);
            boolean guard=controller.exchangeShieldGrace()&&!own.hasCooldown(Material.SHIELD);
            OffhandRangedSupport.invoke(plugin,"move",new Class<?>[]{Player.class,Motion.class,boolean.class,boolean.class,boolean.class},own,Motion.FORWARD,guard,!guard,true);
            return;
        }
        if(controller.shieldPressure()&&!view.ownShieldAvailable()) {
            // Clicking the opposing shield is an attack overlay; retain the normal
            // safe/learned ground movement instead of replacing it with a charge.
            var heading=controller.groundHeading(new PrecisionFootwork.Body(own.getX(),own.getZ(),memory.observedOwnVelocity.getX(),memory.observedOwnVelocity.getZ()),
                new PrecisionFootwork.Body(target.getX(),target.getZ(),memory.observedTargetVelocity.getX(),memory.observedTargetVelocity.getZ()),own.getFoodLevel()>6,
                992.4,1036.6,992.4,1036.6,(x,z)->(boolean)OffhandRangedSupport.invoke(plugin,"precisionPathClear",new Class<?>[]{Player.class,double.class,double.class},own,x,z),view,senses);
            if(heading!=null) {
                if(Math.hypot(heading.x(),heading.z())>1e-8)
                    OffhandRangedSupport.invoke(plugin,"turnToDirection",new Class<?>[]{Player.class,org.bukkit.util.Vector.class,float.class},own,new org.bukkit.util.Vector(heading.x(),0,heading.z()),180f);
                OffhandRangedSupport.invoke(plugin,"move",new Class<?>[]{Player.class,Motion.class,boolean.class,boolean.class,boolean.class},
                    own,Math.hypot(heading.x(),heading.z())>1e-8?Motion.FORWARD:Motion.HOLD,false,controller.groundSprint(),true);
            }
        }
        var plan=controller.exchangePlan();
        if(plan==null||!controller.exchangeMotion())return;
        // Native instant-turn finally has finished; restore the preselected jump line
        // in the same server call. No extra retreat, velocity setter or second jump.
        if(controller.exchangeAttack()) {
            if(controller.exchangeSucceeded()) {
                memory.melee.guardAfterCounter();memory.retreatOpened=true;memory.rangeControlActive=true;
                memory.retreatCameraActive=false;
            }
            OffhandRangedSupport.invoke(plugin,"turnToDirection",new Class<?>[]{Player.class,org.bukkit.util.Vector.class,float.class},
                own,new org.bukkit.util.Vector(plan.x(),0,plan.z()),180f);
            OffhandRangedSupport.invoke(plugin,"move",new Class<?>[]{Player.class,Motion.class,boolean.class,boolean.class,boolean.class},
                own,Motion.FORWARD,false,true,true);
            controller.frameRestored();
        }
    }
    static OpportunityStrike.Kind criticalOpportunity(OpportunityStrike.Kind requested, InitialCombatController controller) {
        return controller.criticalOpportunity(requested);
    }
    static double eyeBox(Player own, Player target) {
        var eye=own.getEyeLocation(); var box=target.getBoundingBox();
        double x=Math.max(box.getMinX()-eye.getX(),Math.max(0,eye.getX()-box.getMaxX()));
        double y=Math.max(box.getMinY()-eye.getY(),Math.max(0,eye.getY()-box.getMaxY()));
        double z=Math.max(box.getMinZ()-eye.getZ(),Math.max(0,eye.getZ()-box.getMaxZ()));
        return Math.sqrt(x*x+y*y+z*z);
    }
    static Weapon escapeWeapon(Weapon desired, InitialCombatController controller) {
        return controller.keepEscapeSword() ? Weapon.SWORD : desired;
    }
    static void escapeSword(MeleeSequence sequence, boolean desired, InitialCombatController controller) {
        sequence.useEscapeSword(desired || controller.keepEscapeSword());
    }
    static void weaponEquipped(Player player, InitialCombatController controller, long tick) {
        if (player.getInventory().getItemInMainHand().getType().name().endsWith("_AXE")) controller.axeEquipped(tick);
    }
    static boolean sprintForMelee(Player player, InitialCombatController controller) {
        return !controller.criticalIntent() && (controller.sprintKnockbackInput() || player.isSprinting());
    }

    static boolean footworkSprint(boolean orbit, InitialCombatController controller) {
        return orbit || controller.groundSprint();
    }

    static void afterMelee(InitialCombatController controller, CombatMemory memory, Player player, long tick) {
        controller.meleeAttemptFinished(tick, memory.dealt, memory.followAlsoExitTick == tick);
        if (memory.melee.lastDamageTick() != tick) return;
        controller.confirmedPressureDamage(tick, memory.dealt);
        if (controller.pressureRecovering()) {
            memory.melee.requestWithdrawal();
            memory.lastStealRetreat = tick;
            memory.retreatOpened = false;
        }
    }

    private static Weapon raisedMelee(Player player, Weapon desired) {
        if (player.hasCooldown(Material.SHIELD) || player.getActiveItem().getType() != Material.SHIELD) return desired;
        String main = player.getInventory().getItemInMainHand().getType().name();
        if (main.endsWith("_SWORD")) return Weapon.SWORD;
        if (main.endsWith("_AXE")) return Weapon.AXE;
        return desired;
    }

    static Weapon airborneGuardWeapon(Weapon desired, Player player, CombatView view, NeuralLearner.Senses senses) {
        return view.ownShieldAvailable() && AirborneEnvelope.relevant(senses) ? raisedMelee(player, desired) : desired;
    }

    static Weapon keepGuardDuringTakeoff(Weapon desired, Player player, Player target) {
        return target != null && !target.isOnGround() ? raisedMelee(player, desired) : desired;
    }
}

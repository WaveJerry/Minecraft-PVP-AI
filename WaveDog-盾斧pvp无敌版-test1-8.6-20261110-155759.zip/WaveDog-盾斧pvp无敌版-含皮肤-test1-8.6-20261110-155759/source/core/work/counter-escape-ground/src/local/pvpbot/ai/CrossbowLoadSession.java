package local.pvpbot.ai;

/** One owner for synchronized load progress. Animation duration never means loaded. */
final class CrossbowLoadSession {
    enum Phase { IDLE, FOLLOWING, VERIFYING, FINISHING }
    private Phase phase=Phase.IDLE;
    private int targetSlot=-1,restarts;
    private long releasedAt=-1000,finishUntil=-1000;
    Phase phase(){return phase;}
    boolean active(){return phase!=Phase.IDLE;}
    boolean verifying(){return phase==Phase.VERIFYING;}
    boolean finishing(){return phase==Phase.FINISHING;}
    int targetSlot(){return targetSlot;}
    void start(int slot){if(!active()){phase=Phase.FOLLOWING;targetSlot=slot;restarts=0;}}
    void reset(){phase=Phase.IDLE;targetSlot=-1;releasedAt=finishUntil=-1000;restarts=0;}
    void released(boolean loaded,int held,int duration,long tick,int ownRemaining){
        if(!active())return;
        if(loaded){finish(tick,ownRemaining);return;}
        if(held>=duration){phase=Phase.VERIFYING;releasedAt=tick;}
        else reset();
    }
    void observe(boolean loaded,boolean using,long tick,int ownRemaining){
        if(!active()||finishing())return;
        var result=CrossbowLoadSync.outcome(loaded,using,phase==Phase.VERIFYING,tick-releasedAt);
        if(result==CrossbowLoadSync.Result.FINISH)finish(tick,ownRemaining);
        else if(result==CrossbowLoadSync.Result.CANCEL)reset();
        else if(result==CrossbowLoadSync.Result.CONTINUE)phase=Phase.FOLLOWING;
    }
    private void finish(long tick,int remaining){phase=Phase.FINISHING;finishUntil=tick+Math.max(3,remaining+3);}
    boolean expired(long tick){return finishing()&&tick>finishUntil;}
    boolean restart(long tick,int duration){
        if(!finishing()||restarts++>=1)return false;
        finishUntil=tick+duration+3;return true;
    }
}

package local.pvpbot.ai;

import java.lang.reflect.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/** Ask the running game's CrossbowItem; do not approximate enchantment timing. */
final class NativeCrossbowTiming {
    private record Access(Method handle, Method copy, Method duration) {}
    private static final ClassValue<Access> ACCESS = new ClassValue<>() {
        @Override protected Access computeValue(Class<?> craftPlayer) {
            try {
                var loader = craftPlayer.getClassLoader();
                var craftItem = Class.forName("org.bukkit.craftbukkit.inventory.CraftItemStack", false, loader);
                var item = Class.forName("net.minecraft.world.item.ItemStack", false, loader);
                var living = Class.forName("net.minecraft.world.entity.LivingEntity", false, loader);
                var crossbow = Class.forName("net.minecraft.world.item.CrossbowItem", false, loader);
                return new Access(craftPlayer.getMethod("getHandle"), craftItem.getMethod("asNMSCopy", ItemStack.class),
                    crossbow.getMethod("getChargeDuration", item, living));
            } catch (ReflectiveOperationException e) { throw new IllegalStateException("Native crossbow duration unavailable", e); }
        }
    };
    static int duration(Player player, ItemStack stack) {
        try {
            var a = ACCESS.get(player.getClass());
            return ((Number) a.duration.invoke(null, a.copy.invoke(null, stack), a.handle.invoke(player))).intValue();
        } catch (ReflectiveOperationException e) { throw new IllegalStateException("Cannot read native crossbow duration", e); }
    }
}

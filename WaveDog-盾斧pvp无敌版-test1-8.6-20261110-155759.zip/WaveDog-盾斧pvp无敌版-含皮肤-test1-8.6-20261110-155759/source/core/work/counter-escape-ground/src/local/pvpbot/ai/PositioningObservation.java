package local.pvpbot.ai;

import org.bukkit.FluidCollisionMode;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/** Keep the established air observer; add only a soft guarded-positioning prior. */
final class PositioningObservation {
    static void finish(NeuralLearner.Senses senses, Player own, Player target,
                       CombatMemory memory, InitialCombatController controller) {
        controller.guardPositionPrior(0, 0);
        OffhandRangedSupport.observe(senses,own,target,memory,controller);
        // Player.attack samples 0.5 tick; displacement-based velocity and the 0.0-tick
        // general charge snapshot can both miss the last legal descending window.
        controller.hopCriticalObservation(own.getCooledAttackStrength(.5f), own.getVelocity().getY());
        var critical=NativeCriticalState.read(own);
        senses.ownCriticalWindow=critical.afterSprintRelease();
        senses.ownCriticalReady=critical.now();
        controller.targetLoadingCrossbow(target != null && target.hasActiveItem()
            && target.getActiveItem().getType() == org.bukkit.Material.CROSSBOW && !OffhandRangedSupport.charged(target.getActiveItem()));
        AirborneObservation.finish(senses, own, target, memory, controller);
        TradeObservation.finish(senses,own,target,memory,controller);
        if (target == null || !senses.targetMotionFresh || senses.estimateAge > 1
                || senses.ownShieldCooldown > 0 || senses.targetAirborne || senses.targetCritThreat
                || own.getX() < 992.4 || own.getX() > 1036.6 || own.getZ() < 992.4 || own.getZ() > 1036.6) return;
        double dx=target.getX()-own.getX(), dz=target.getZ()-own.getZ(), length=Math.hypot(dx,dz);
        if(length < 1e-8) return;
        double fx=dx/length, fz=dz/length;
        boolean rearClear=!senses.retreatBlocked && clear(own,-fx,-fz);
        int advance=0,side=0;double bestAdvance=.01,bestSide=-Double.MAX_VALUE;
        for(int action:new int[]{1,6,7,4,5}) {
            double f=GroundFootwork.forward(action),s=GroundFootwork.sideways(action),norm=Math.hypot(f,s);
            double x=(fx*f-fz*s)/norm,z=(fz*f+fx*s)/norm;
            if(!clear(own,x,z)) continue;
            double score=WallPositioning.preference(own.getX(),own.getZ(),target.getX(),target.getZ(),
                own.getX()+x*.04,own.getZ()+z*.04,992.4,1036.6,992.4,1036.6,rearClear);
            if(f>0 && score>bestAdvance) {bestAdvance=score;advance=action;}
            if(f==0 && score>bestSide+.01) {bestSide=score;side=action;}
        }
        // A symmetric/neutral position keeps the old learned/random side choice.
        if(Math.abs(bestSide)<.01) side=0;
        controller.guardPositionPrior(advance,side);
    }

    private static boolean clear(Player player,double x,double z) {
        var direction=new Vector(x,0,z);
        for(double side:new double[]{-.29,0,.29})for(double height:new double[]{.1,1.5}) {
            var origin=player.getLocation().clone().add(-z*side,height,x*side);
            if(player.getWorld().rayTraceBlocks(origin,direction,.75,FluidCollisionMode.NEVER,true)!=null) return false;
        }
        return true;
    }
}

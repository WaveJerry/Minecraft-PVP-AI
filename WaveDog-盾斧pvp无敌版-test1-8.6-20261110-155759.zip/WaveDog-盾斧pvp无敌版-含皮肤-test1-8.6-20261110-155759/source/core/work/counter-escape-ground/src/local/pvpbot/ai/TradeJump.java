package local.pvpbot.ai;

/** Optional post-escape exchange: predictions select inputs, never change physics. */
final class TradeJump {
    @FunctionalInterface interface Clear { boolean at(double x, double y, double z); }
    record Plan(double x, double z, int hitTick, double separation, boolean separates) {}

    static Plan plan(AirborneEnvelope.Body own, AirborneEnvelope.Body target,
                     double minX, double maxX, double minZ, double maxZ, Clear clear) {
        if (!AirborneEnvelope.finite(own) || !AirborneEnvelope.finite(target)
                || !own.grounded() || target.grounded() || target.vy() <= 0) return null;
        double away=Math.atan2(own.z()-target.z(),own.x()-target.x());
        Plan best=null; double bestScore=-Double.MAX_VALUE;
        // A rear wall must not rule out a legal sideways/centerward exchange route.
        for (int candidate=-8;candidate<8;candidate++) {
            double angle=away+candidate*Math.PI/8, fx=Math.cos(angle),fz=Math.sin(angle);
            double ox=own.x(),oy=own.y(),oz=own.z(),vx=own.vx()+fx*.2,vz=own.vz()+fz*.2,vy=.42;
            double tx=target.x(),ty=target.y(),tz=target.z(),tvx=target.vx(),tvy=target.vy(),tvz=target.vz();
            int hit=-1; boolean valid=true; double endReach=0;
            for(int tick=1;tick<=14;tick++) {
                // Native sprint-jump impulse, air acceleration, gravity and drag.
                vx+=fx*.02548;vz+=fz*.02548;
                double nx=ox+vx,ny=oy+vy,nz=oz+vz;
                if(ny<own.y())ny=own.y();
                if(nx<minX||nx>maxX||nz<minZ||nz>maxZ){valid=false;break;}
                // Sweep the whole player volume along each segment, not just its endpoint.
                int samples=Math.max(1,(int)Math.ceil(Math.sqrt(vx*vx+vy*vy+vz*vz)/.15));
                for(int j=1;j<=samples;j++) if(!clear.at(ox+(nx-ox)*j/samples,
                        oy+(ny-oy)*j/samples,oz+(nz-oz)*j/samples)){valid=false;break;}
                if(!valid)break;
                ox=nx;oy=ny;oz=nz;
                double towardX=ox-tx,towardZ=oz-tz,n=Math.hypot(towardX,towardZ);
                // Assume the opponent keeps pursuing at full available air input.
                double accel=ty<=own.y()&&tvy<=0?.1274:.02548;
                if(n>1e-8){tvx+=towardX/n*accel;tvz+=towardZ/n*accel;}
                tx+=tvx;tz+=tvz;ty+=tvy;
                if(ty<own.y() && tvy<0) {ty=own.y();tvy=0;}
                double ownRay=distance(ox,oy+own.eye(),oz,tx,ty,tz,target.halfX(),target.halfZ(),target.height());
                if(vy<0 && oy>own.y()+1e-6 && ownRay<=3)hit=tick;
                endReach=distance(tx,ty+target.eye(),tz,ox,oy,oz,own.halfX(),own.halfZ(),own.height());
                vx*=.91;vz*=.91;vy=(vy-.08)*.98;
                tvx*=ty<=own.y()&&tvy<=0?.546:.91;tvz*=ty<=own.y()&&tvy<=0?.546:.91;
                if(tvy!=0)tvy=(tvy-.08)*.98;
            }
            if(!valid)continue;
            double room=WallPositioning.margin(ox,oz,minX,maxX,minZ,maxZ);
            double before=WallPositioning.margin(own.x(),own.z(),minX,maxX,minZ,maxZ);
            boolean separates=endReach>3.05;
            double score=(separates?100:0)+(hit>=0?2:0)+Math.min(6,endReach)*3+Math.min(4,room)-Math.min(4,before);
            if(score>bestScore){bestScore=score;best=new Plan(fx,fz,hit,endReach,separates);}
        }
        return best;
    }

    static double distance(double ex,double ey,double ez,double x,double y,double z,double hx,double hz,double height) {
        double dx=Math.max(0,Math.abs(ex-x)-hx),dz=Math.max(0,Math.abs(ez-z)-hz);
        double dy=Math.max(0,Math.max(y-ey,ey-y-height));
        return Math.sqrt(dx*dx+dy*dy+dz*dz);
    }
}

package local.pvpbot.ai;

import java.lang.reflect.Field;
import java.util.*;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.util.Vector;
import local.pvpbot.sense.ArrowSenseService;

/** One shared trajectory/input plan for tick, shot and movement arbitration. */
final class ProjectileDefence {
    record Plan(ArrowDodgePlanner.Result path, Vector forward, Vector guard, boolean shield, int action, boolean jump) {
        boolean owns() { return path.threat() && (shield || action >= 0); }
    }
    private record Commitment(Vector heading,int until,Set<Integer> arrows,int primary,double eta) {}
    private static final Map<UUID,Commitment> escapes=new HashMap<>();
    private static Field senseField;
    static boolean hasShield(Player p) {
        if(p.hasCooldown(Material.SHIELD))return false;
        for(var i:p.getInventory().getContents())if(i!=null&&i.getType()==Material.SHIELD)return true;
        return false;
    }
    private static ArrowSenseService sensor(PvPArenaAI plugin) {
        try {
            if(senseField==null){senseField=PvPArenaAI.class.getDeclaredField("arrowSense");senseField.setAccessible(true);}
            return (ArrowSenseService)senseField.get(plugin);
        }catch(ReflectiveOperationException e){throw new IllegalStateException("Projectile perception unavailable",e);}
    }
    static Plan plan(PvPArenaAI plugin,Player p,int intended,AbstractArrow incoming) {
        Vector forward=p.getLocation().getDirection().setY(0);
        if(forward.lengthSquared()<1e-8)forward=new Vector(0,0,1);else forward.normalize();
        var shots=new ArrayList<ArrowDodgePlanner.Shot>();var ids=new HashSet<Integer>();
        for(var a:sensor(plugin).observe(p).arrows()) {
            // The sense service provides swept, gravity/drag-aware paths clipped at blocks.
            if(incoming!=null&&a.id()==incoming.getEntityId())continue;
            ids.add(a.id());
            shots.add(new ArrowDodgePlanner.Shot(a.id(),new ArrowDodgePlanner.Vec(a.x(),a.y(),a.z()),
                new ArrowDodgePlanner.Vec(a.vx(),a.vy(),a.vz()),a.gravity(),a.drag(),a.piercing()==0,
                a.path().stream().map(v->new ArrowDodgePlanner.Vec(v.x(),v.y(),v.z())).toList()));
        }
        // A shoot event can occur after this tick's sensor cache. Include its actual
        // projectile now, rather than waiting for the next tick to see a fast arrow.
        if(incoming!=null&&ids.add(incoming.getEntityId())) {
            var pos=incoming.getLocation().toVector();var vel=incoming.getVelocity();
            shots.add(new ArrowDodgePlanner.Shot(incoming.getEntityId(),vec(pos),vec(vel),incoming.hasGravity(),
                incoming.isInWater()?.6:.99,incoming.getPierceLevel()==0,trajectory(p,incoming)));
        }
        var box=p.getBoundingBox();var feet=p.getLocation().toVector();
        var attribute=p.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED);
        double acceleration=attribute==null?.1:attribute.getValue()/(p.isSprinting()?1.3:1);
        boolean arena=p.getX()>=992&&p.getX()<=1037&&p.getZ()>=992&&p.getZ()<=1037;
        boolean shield=hasShield(p);
        var support=p.getWorld().rayTraceBlocks(p.getLocation().clone().add(0,.01,0),new Vector(0,-1,0),8,FluidCollisionMode.NEVER,true);
        double floor=arena?221:support==null?feet.getY()-8:support.getHitPosition().getY();
        // Shield available => guard only. No shield => cancel item use and evaluate
        // the full-speed input we will actually submit, including current inertia.
        var body=new ArrowDodgePlanner.Body(vec(feet),vec(p.getVelocity()),vec(forward),
            Math.max(box.getWidthX(),box.getWidthZ())/2,box.getHeight(),acceleration,shield?.2:1,
            p.isOnGround(),p.getFoodLevel()>6,arena?992:feet.getX()-32,arena?1037:feet.getX()+32,
            arena?992:feet.getZ()-32,arena?1037:feet.getZ()+32,floor);
        int action=intended>=0&&intended<17?intended:0;
        var path=evaluate(body,shots,0,false,shield?0:action);
        int now=Bukkit.getCurrentTick();
        var committed=escapes.get(p.getUniqueId());
        Set<Integer> priorArrows=committed==null?Set.of():committed.arrows();
        if(committed!=null&&(committed.until()<now||shots.stream().noneMatch(s->priorArrows.contains(s.id())))) {
            escapes.remove(p.getUniqueId());committed=null;
        }
        if(shield){escapes.remove(p.getUniqueId());committed=null;}
        if(!path.threat()&&committed==null)return new Plan(path,forward,null,false,-1,false);
        if(shield) {
            Vector guard=forward.clone();
            for(var shot:shots)if(shot.id()==path.primaryId()) {
                guard=new Vector(shot.position().x()-p.getX(),0,shot.position().z()-p.getZ());
                if(guard.lengthSquared()<1e-8)guard=new Vector(-shot.velocity().x(),0,-shot.velocity().z());
                if(guard.lengthSquared()<1e-8)guard=forward.clone();else guard.normalize();
                break;
            }
            return new Plan(path,forward,guard,true,-1,false);
        }
        if(committed!=null&&!path.threat())path=new ArrowDodgePlanner.Result(true,Math.max(0,committed.until()-now-2),path.miss(),
            path.preferredMove(),path.safeMoves(),path.viableMoves(),false,true,committed.primary());
        var route=escape(p,body,shots,path,committed==null?null:vec(committed.heading()));
        if(route!=null) {
            var heading=new Vector(route.heading().x(),0,route.heading().z());
            int selected=route.sprint()?2:1;boolean[] safe=new boolean[18],viable=new boolean[18];safe[selected]=viable[selected]=true;
            path=new ArrowDodgePlanner.Result(true,path.eta(),path.miss(),selected,safe,viable,false,true,path.primaryId());
            return new Plan(path,heading,null,false,selected,route.jump());
        }
        escapes.remove(p.getUniqueId());
        path=new ArrowDodgePlanner.Result(path.threat(),path.eta(),path.miss(),0,
            new boolean[18],new boolean[18],false,false,path.primaryId());
        return new Plan(path,forward,null,false,-1,false);
    }
    static ArrowDodgePlanner.Result evaluate(ArrowDodgePlanner.Body body,List<ArrowDodgePlanner.Shot> shots,
                                             double shieldTicks,boolean shield,int action) {
        // Native ProjectileUtil expands arrow targets by .3; legacy contributes .1.
        var feet=body.feet();
        var expanded=new ArrowDodgePlanner.Body(new ArrowDodgePlanner.Vec(feet.x(),feet.y()-.22,feet.z()),
            body.velocity(),body.forward(),body.halfWidth()+.22,body.height()+.44,body.acceleration(),body.useScale(),
            body.onGround(),body.canSprint(),body.minX(),body.maxX(),body.minZ(),body.maxZ(),body.floorY()-.22);
        return ArrowDodgePlanner.evaluate(expanded,shots,shieldTicks,shield,action);
    }
    static boolean canEvade(Player p,ArrowDodgePlanner.Body body,List<ArrowDodgePlanner.Shot> shots,ArrowDodgePlanner.Result path) {
        return escape(p,body,shots,path,null)!=null;
    }
    private static ArrowEscapePlanner.Route escape(Player p,ArrowDodgePlanner.Body body,List<ArrowDodgePlanner.Shot> shots,
                                                   ArrowDodgePlanner.Result path,ArrowDodgePlanner.Vec committed) {
        var obstacles=new HashMap<String,List<org.bukkit.util.BoundingBox>>();
        ArrowEscapePlanner.Space space=(from,to,half,height)->clear(p,from,to,half,height,obstacles);
        double friction=switch(p.getWorld().getBlockAt(p.getLocation().clone().add(0,-.1,0)).getType()) {
            case ICE,PACKED_ICE,FROSTED_ICE->.98*.91;case BLUE_ICE->.989*.91;case SLIME_BLOCK->.8*.91;default->.546;
        };
        var jumpAttribute=p.getAttribute(Attribute.GENERIC_JUMP_STRENGTH);
        double power=jumpAttribute==null?.42:jumpAttribute.getValue();
        var boost=p.getPotionEffect(org.bukkit.potion.PotionEffectType.JUMP_BOOST);if(boost!=null)power+=.1*(boost.getAmplifier()+1);
        // Native onGround can remain true until the first movement step after a
        // jump input. Positive Y velocity rules out adding another jump impulse.
        boolean canJump=p.isOnGround()&&p.getVelocity().getY()<=0&&!p.isInWater()&&!p.isInLava()&&!p.isClimbing()&&!p.isGliding()&&!p.isInsideVehicle();
        if(p.getWorld().getBlockAt(p.getLocation().clone().add(0,-.1,0)).getType()==Material.HONEY_BLOCK)power*=.5;
        return ArrowEscapePlanner.choose(new ArrowEscapePlanner.Motion(body,friction,power,canJump),shots,path.eta(),path.primaryId(),
            committed,space);
    }
    static void submitted(Player p,Plan plan) {
        if(plan.shield()||!plan.owns())return;
        int now=Bukkit.getCurrentTick();var prior=escapes.get(p.getUniqueId());
        int until=prior!=null&&prior.primary()==plan.path().primaryId()?prior.until():
            now+Math.max(2,Math.min(24,(int)Math.ceil(plan.path().eta())+2));
        escapes.put(p.getUniqueId(),new Commitment(plan.forward().clone(),until,Set.of(plan.path().primaryId()),plan.path().primaryId(),plan.path().eta()));
    }
    private static boolean clear(Player p,ArrowDodgePlanner.Vec from,ArrowDodgePlanner.Vec to,double half,double height,
                                 Map<String,List<org.bukkit.util.BoundingBox>> cache) {
        // Swept body, not a point ray: includes ceilings and diagonal wall corners.
        var swept=new org.bukkit.util.BoundingBox(Math.min(from.x(),to.x())-half,Math.min(from.y(),to.y())+.001,
            Math.min(from.z(),to.z())-half,Math.max(from.x(),to.x())+half,Math.max(from.y(),to.y())+height-.001,
            Math.max(from.z(),to.z())+half);
        for(int x=(int)Math.floor(swept.getMinX());x<=Math.floor(swept.getMaxX());x++)
            for(int y=(int)Math.floor(swept.getMinY());y<=Math.floor(swept.getMaxY());y++)
                for(int z=(int)Math.floor(swept.getMinZ());z<=Math.floor(swept.getMaxZ());z++) {
                    if(!p.getWorld().isChunkLoaded(x>>4,z>>4))return false;
                    String key=x+":"+y+":"+z;var parts=cache.get(key);
                    if(parts==null) {
                        var block=p.getWorld().getBlockAt(x,y,z);parts=new ArrayList<>();
                        if(!block.isPassable())for(var part:block.getCollisionShape().getBoundingBoxes())parts.add(part.clone().shift(x,y,z));
                        cache.put(key,parts);
                    }
                    for(var part:parts)if(swept.overlaps(part))return false;
                }
        return true;
    }
    private static List<ArrowDodgePlanner.Vec> trajectory(Player p,AbstractArrow a) {
        var path=new ArrayList<ArrowDodgePlanner.Vec>();var pos=a.getLocation().toVector();var vel=a.getVelocity();
        path.add(vec(pos));double drag=a.isInWater()?.6:.99;
        for(int i=0;i<ArrowDodgePlanner.HORIZON;i++) {
            double length=vel.length();if(length<1e-8)break;
            var hit=p.getWorld().rayTraceBlocks(pos.toLocation(p.getWorld()),vel.clone().normalize(),length,FluidCollisionMode.NEVER,true);
            if(hit!=null){path.add(vec(hit.getHitPosition()));break;}
            pos=pos.clone().add(vel);path.add(vec(pos));vel.multiply(drag);if(a.hasGravity())vel.setY(vel.getY()-.05);
        }
        return path;
    }
    static double forward(int action) { return switch(action){case 1,2,6,7,8,9,12->1;case 3,10,11,15->-1;default->0;}; }
    static double side(int action) { return switch(action){case 4,6,8,10,13->-1;case 5,7,9,11,14->1;default->0;}; }
    private static ArrowDodgePlanner.Vec vec(Vector v){return new ArrowDodgePlanner.Vec(v.getX(),v.getY(),v.getZ());}
}

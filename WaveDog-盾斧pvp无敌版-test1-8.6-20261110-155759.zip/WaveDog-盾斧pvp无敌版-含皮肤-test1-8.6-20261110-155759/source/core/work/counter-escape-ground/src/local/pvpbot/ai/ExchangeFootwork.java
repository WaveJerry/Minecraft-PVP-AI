package local.pvpbot.ai;

/** Native input headings that track the exchange's 2.8-block eye-to-box target. */
final class ExchangeFootwork {
    static final double TARGET_REACH=2.8;
    record Heading(double x,double z) {}
    static Heading choose(AirborneEnvelope.Body own,AirborneEnvelope.Body target,
                          double minX,double maxX,double minZ,double maxZ,TradeJump.Clear clear) {
        if(!AirborneEnvelope.finite(own)||!AirborneEnvelope.finite(target))return null;
        Heading best=null;double bestScore=-Double.MAX_VALUE;
        double away=Math.atan2(own.z()-target.z(),own.x()-target.x());
        for(int i=0;i<16;i++) {
            double a=away+i*Math.PI/8,x=Math.cos(a),z=Math.sin(a);
            double accel=own.grounded()?.1274:.02548;
            double nx=own.x()+own.vx()+x*accel,nz=own.z()+own.vz()+z*accel,ny=own.y()+own.vy();
            if(nx<minX||nx>maxX||nz<minZ||nz>maxZ||!clear.at(nx,ny,nz))continue;
            double reach=TradeJump.distance(nx,ny+own.eye(),nz,
                target.x()+target.vx(),target.y()+target.vy(),target.z()+target.vz(),target.halfX(),target.halfZ(),target.height());
            double room=WallPositioning.margin(nx,nz,minX,maxX,minZ,maxZ);
            // Distance is the hard movement target. Room resolves close choices.
            double score=-Math.abs(reach-TARGET_REACH)*100+Math.min(2,room)*.4;
            if(score>bestScore){bestScore=score;best=new Heading(x,z);}
        }
        return best;
    }
}

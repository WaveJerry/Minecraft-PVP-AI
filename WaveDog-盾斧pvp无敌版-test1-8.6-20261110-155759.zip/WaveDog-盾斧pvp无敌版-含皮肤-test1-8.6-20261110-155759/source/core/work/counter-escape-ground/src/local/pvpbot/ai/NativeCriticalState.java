package local.pvpbot.ai;

import java.lang.reflect.*;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffectType;

/** Minecraft Java 1.21.1 Player.attack prerequisites, sampled at partial tick 0.5. */
final class NativeCriticalState {
    record Snapshot(float charge, float fall, double vy, boolean grounded, boolean climbing,
                    boolean water, boolean blind, boolean passenger, boolean sprint, boolean disabled) {
        boolean afterSprintRelease() {
            return Float.isFinite(charge) && charge > .9f && fall > 0 && Double.isFinite(vy) && vy < 0
                && !grounded && !climbing && !water && !blind && !passenger && !disabled;
        }
        boolean now() { return afterSprintRelease() && !sprint; }
    }
    private record Access(Method handle, Method config, Field entities, Field behavior, Field disabled) {}
    private static final ClassValue<Access> ACCESS = new ClassValue<>() {
        @Override protected Access computeValue(Class<?> craftWorld) {
            try {
                Method handle = craftWorld.getMethod("getHandle");
                Method config = handle.getReturnType().getMethod("paperConfig");
                Field entities = config.getReturnType().getField("entities");
                Field behavior = entities.getType().getField("behavior");
                return new Access(handle, config, entities, behavior, behavior.getType().getField("disablePlayerCrits"));
            } catch (ReflectiveOperationException e) { throw new IllegalStateException("Paper critical configuration unavailable", e); }
        }
    };
    static boolean disabled(Player player) {
        try {
            var a = ACCESS.get(player.getWorld().getClass());
            return a.disabled.getBoolean(a.behavior.get(a.entities.get(a.config.invoke(a.handle.invoke(player.getWorld())))));
        } catch (ReflectiveOperationException e) { throw new IllegalStateException("Cannot read effective critical configuration", e); }
    }
    static Snapshot read(Player p) {
        return new Snapshot(p.getCooledAttackStrength(.5f), p.getFallDistance(), p.getVelocity().getY(),
            p.isOnGround(), p.isClimbing(), p.isInWater(), p.hasPotionEffect(PotionEffectType.BLINDNESS),
            p.isInsideVehicle(), p.isSprinting(), disabled(p));
    }
}

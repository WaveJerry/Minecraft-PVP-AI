package local.pvpbot.ai;
/** Independent UHC foundation entry; utility actions are deliberately not claimed by this axe package. */
public final class UHC2 implements CombatPolicy {
    public String name(){return "UHC2";}
    public InitialCombatController createInitialController(long seed){return new test1().createInitialController(seed);}
    public CombatDecision decide(CombatView view,CombatMemory memory,int variant){return new test1().decide(view,memory,variant);}
}

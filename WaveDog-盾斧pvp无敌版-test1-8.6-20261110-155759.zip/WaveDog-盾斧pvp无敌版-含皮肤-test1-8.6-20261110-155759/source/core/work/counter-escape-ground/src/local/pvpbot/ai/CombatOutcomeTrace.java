package local.pvpbot.ai;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.server.PluginDisableEvent;

/** Complete compact frames for ten rounds, including real damage and cancelled inputs. */
final class CombatOutcomeTrace implements Listener {
    private static final Map<UUID, Round> rounds=new HashMap<>();
    private static PvPArenaAI plugin;
    private static String session;
    private static long sequence;
    private static final Deque<List<Path>> retained=new ArrayDeque<>();
    private static final class Round {
        CombatMemory memory; Player own,target; InitialCombatController controller;
        BufferedWriter writer; long tick; int frames;
    }
    static void install(PvPArenaAI p) {
        if(plugin==p)return;
        for(var r:rounds.values())close(r);
        rounds.clear();retained.clear();sequence=0;plugin=p;session=Long.toString(System.currentTimeMillis());
        p.getServer().getPluginManager().registerEvents(new NativeMeleeReceipt(),p);
        p.getServer().getPluginManager().registerEvents(new CombatOutcomeTrace(),p);
    }
    static void begin(Player own,Player target,CombatMemory memory,InitialCombatController controller,long tick,
                      NeuralLearner.Senses senses,CombatDecision frame) {
        var r=rounds.get(own.getUniqueId());
        try {
            if(r==null||r.memory!=memory) {
                if(r!=null)close(r);
                r=new Round();r.memory=memory;r.own=own;r.target=target;r.controller=controller;
                Path dir=plugin.getDataFolder().toPath().resolve("diagnostics").resolve("last-10-rounds");
                Files.createDirectories(dir);
                Path file=dir.resolve(session+"-"+(++sequence)+"-"+own.getName()+".jsonl");
                r.writer=Files.newBufferedWriter(file,StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
                rounds.put(own.getUniqueId(),r);retained.addLast(List.of(file));
                while(retained.size()>10)for(Path old:retained.removeFirst())Files.deleteIfExists(old);
            }
            r.tick=tick;
            write(r,"FRAME", "phase="+controller.phaseName()+" opportunity="+senses.opportunity
                +" requestedAttack="+frame.attack()+" motion="+frame.motion()+" sprintInput="+frame.sprint()
                +" targetReach="+senses.targetReachDistance+" damageAge="+senses.damageAge
                +" tradePlan="+(controller.exchangePlan()!=null)+" own="+state(own)+" target="+state(target),false);
            if(++r.frames%20==0)r.writer.flush();
        }catch(IOException e){fail(r,e);}
    }
    static String state(Player p) {
        return "{pos="+p.getX()+","+p.getY()+","+p.getZ()+",critical="+NativeCriticalState.read(p)
            +",main="+p.getInventory().getItemInMainHand().getType()+",off="+p.getInventory().getItemInOffHand().getType()
            +",active="+p.getActiveItem().getType()+",heldTicks="+p.getHandRaisedTime()
            +",loaded="+OffhandRangedSupport.charged(p)+",blocking="+p.isBlocking()+"}";
    }
    static void note(Player p,String detail) {
        var r=rounds.get(p.getUniqueId());if(r==null||r.writer==null)return;
        try {write(r,"INPUT",detail,true);}catch(IOException e){fail(r,e);}
    }
    private static String escape(String s){return s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r");}
    private static void write(Round r,String type,String detail,boolean flush)throws IOException {
        if(r.writer==null)return;
        r.writer.write("{\"tick\":"+r.tick+",\"type\":\""+type+"\",\"detail\":\""+escape(detail)+"\"}\n");
        if(flush)r.writer.flush();
    }
    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void damage(EntityDamageByEntityEvent event) {
        if(event.getFinalDamage()<=0)return;
        for(var r:List.copyOf(rounds.values())) {
            if(r.writer==null||!r.own.isOnline())continue;
            boolean taken=event.getEntity().equals(r.own),dealt=event.getDamager().equals(r.own);
            if(!taken&&!dealt)continue;
            try {write(r,taken?"TAKEN":"DEALT","damage="+event.getFinalDamage()+" critical="+event.isCritical()
                +" cause="+event.getCause()+" phase="+r.controller.phaseName()+" reach="+CombatInputHooks.eyeBox(r.own,r.target)
                +" own="+state(r.own)+" target="+state(r.target),true);}catch(IOException e){fail(r,e);}
        }
    }
    @EventHandler public void disabled(PluginDisableEvent e){if(e.getPlugin()==plugin)for(var r:rounds.values())close(r);}
    private static void close(Round r){try{if(r.writer!=null)r.writer.close();}catch(IOException ignored){}finally{r.writer=null;}}
    private static void fail(Round r,Exception e){if(r!=null)close(r);plugin.getLogger().warning("Combat diagnostic write failed: "+e.getMessage());}
}

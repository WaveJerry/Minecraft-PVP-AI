package local.pvpbot.ai;

import java.lang.reflect.Field;
import java.util.Map;
import java.util.UUID;
import io.github.hello09x.fakeplayer.api.spi.ActionType;
import io.github.hello09x.fakeplayer.api.spi.ActionSetting;
import io.github.hello09x.fakeplayer.api.spi.ActionTicker;
import io.github.hello09x.fakeplayer.core.manager.action.ActionManager;
import org.bukkit.entity.Player;

/** Drain only the fakeplayer USE queue before starting a new native offhand use. */
final class NativeUseSession {
    private static Field actions, managers;
    static void detachQueuedUse(PvPArenaAI plugin, Player player) {
        try {
            if (actions == null) {
                actions = PvPArenaAI.class.getDeclaredField("actions"); actions.setAccessible(true);
                managers = actions.getType().getDeclaredField("managers"); managers.setAccessible(true);
            }
            detach((Map<?,?>) managers.get(actions.get(plugin)), player.getUniqueId());
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException("Cannot drain the old fakeplayer USE input", e);
        }
    }
    // The old active use is already cleared by cancelCombatUse. Calling ticker.stop()
    // later would release the NEW bow/crossbow, so remove that queued action now.
    static void detach(Map<?,?> queues, UUID player) {
        Object queue = queues.get(player);
        if (queue instanceof Map<?,?> inputs) inputs.remove(ActionType.USE);
    }
    static boolean jumpNow(PvPArenaAI plugin,Player player) {
        if(!player.isOnGround())return false;
        try {
            // Bind once and execute the very same once-JUMP ticker that the normal
            // fakeplayer scheduler uses. No velocity setter or extra jump impulse.
            detachQueuedUse(plugin,player);
            var manager=(ActionManager)actions.get(plugin);
            manager.setAction(player,ActionType.JUMP,ActionSetting.once());
            var queues=(Map<?,?>)managers.get(manager);
            var queue=(Map<?,?>)queues.get(player.getUniqueId());
            var ticker=(ActionTicker)queue.remove(ActionType.JUMP);
            if(ticker==null)return false;
            ticker.tick();return player.getVelocity().getY()>0;
        }catch(ReflectiveOperationException e){throw new IllegalStateException("Cannot submit the normal jump input",e);}
    }
}

package local.pvpbot.ai;

/** Actual charged item wins over animation ending; elapsed use time is not completion. */
final class CrossbowLoadSync {
    enum Result { CONTINUE, VERIFY, FINISH, CANCEL }
    static Result outcome(boolean loaded,boolean stillUsing,boolean finalRelease,long age) {
        if(loaded)return Result.FINISH;
        if(stillUsing)return Result.CONTINUE;
        // Stop-use events can precede the native item-meta write in this server call.
        if(finalRelease&&age>=0&&age<=1)return Result.VERIFY;
        return Result.CANCEL;
    }
}

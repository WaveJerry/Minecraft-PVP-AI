package local.pvpbot.ai;

import org.bukkit.entity.Player;
import org.bukkit.util.BoundingBox;

/** Live geometry for short advances and the separately authorized exchange jump. */
final class TradeObservation {
    static void finish(NeuralLearner.Senses s,Player own,Player target,CombatMemory memory,InitialCombatController controller) {
        controller.exchangeHeading(null);
        controller.shortAdvanceAvailable(false);
        controller.shortAdvanceTiming(-1,-1);
        controller.combatObservation(target!=null&&target.isOnGround(),
            target==null?20:target.getNoDamageTicks(),target==null?20:target.getMaximumNoDamageTicks());
        if(target==null||!s.targetMotionFresh||s.estimateAge>1) {
            controller.tradeObservation(null,memory.lastCriticalTaken,false,false);return;
        }
        double dx=target.getX()-own.getX(),dz=target.getZ()-own.getZ(),length=Math.hypot(dx,dz);
        double fx=length>1e-8?dx/length:1,fz=length>1e-8?dz/length:0;
        boolean blocked=CombatInputHooks.effectiveShield(own,target);
        // A three-tick maximum at ordinary sprint input; the final attack still uses live reach.
        double px=own.getX(),pz=own.getZ(),vx=own.getVelocity().getX(),vz=own.getVelocity().getZ();
        boolean route=own.getFoodLevel()>6;
        var tv=memory.observedTargetVelocity;
        int firstContact=-1,contactTicks=-1;
        for(int i=0;i<3;i++) {
            vx=vx*.546+fx*.1274;vz=vz*.546+fz*.1274;px+=vx;pz+=vz;
            route&=clear(own,px,own.getY(),pz);
            double reach=TradeJump.distance(px,own.getEyeLocation().getY(),pz,
                target.getX()+tv.getX()*(i+1),target.getY(),target.getZ()+tv.getZ()*(i+1),
                target.getBoundingBox().getWidthX()/2,target.getBoundingBox().getWidthZ()/2,target.getBoundingBox().getHeight());
            if(firstContact<0&&reach<=3) {
                firstContact=i+1;
                if(route)contactTicks=i+1;
            }
        }
        double finalReach=TradeJump.distance(px,own.getEyeLocation().getY(),pz,
            target.getX()+tv.getX()*3,target.getY(),target.getZ()+tv.getZ()*3,
            target.getBoundingBox().getWidthX()/2,target.getBoundingBox().getWidthZ()/2,target.getBoundingBox().getHeight());
        controller.shortAdvanceAvailable(route&&finalReach<=3&&!blocked);
        // Use this target's effective Paper delay, including per-entity overrides.
        // Forecasts only authorize an input; actual strikes recheck live legal reach.
        controller.shortAdvanceTiming(route&&!blocked?contactTicks:-1,target.getShieldBlockingDelay());

        // Whether another native descending tick remains: support and target motion matter.
        var ov=own.getVelocity();double nextY=own.getY()+ov.getY();
        double nextReach=TradeJump.distance(own.getX()+ov.getX(),nextY+own.getEyeHeight(),own.getZ()+ov.getZ(),
            target.getX()+tv.getX(),target.getY()+tv.getY(),target.getZ()+tv.getZ(),
            target.getBoundingBox().getWidthX()/2,target.getBoundingBox().getWidthZ()/2,target.getBoundingBox().getHeight());
        boolean last=ov.getY()<0&&(!clear(own,own.getX()+ov.getX(),nextY,own.getZ()+ov.getZ())||nextReach>3);
        TradeJump.Plan plan=null;
        if(controller.mayPlanLandingTrade(s.onGround)&&s.onGround&&(s.ownWeapon==0||controller.keepEscapeSword()&&s.ownWeapon==1)&&s.weaponInputReady
                &&own.getFoodLevel()>6
                &&own.getFallDistance()==0&&!own.isInWater()&&!own.isClimbing()
                &&!own.isInsideVehicle()&&!own.hasPotionEffect(org.bukkit.potion.PotionEffectType.BLINDNESS)
                &&s.targetAirborne&&s.targetY>0&&s.targetCritThreat) {
            boolean arena=own.getX()>=992&&own.getX()<=1037&&own.getZ()>=992&&own.getZ()<=1037;
            plan=TradeJump.plan(AirborneObservation.body(own,own.getVelocity()),AirborneObservation.body(target,tv),
                arena?992.4:own.getX()-16,arena?1036.6:own.getX()+16,
                arena?992.4:own.getZ()-16,arena?1036.6:own.getZ()+16,(x,y,z)->clear(own,x,y,z));
        }
        controller.tradeObservation(plan,memory.lastCriticalTaken,last,blocked);
        if(controller.exchangeMotion()||controller.landingTradePending()) {
            boolean arena=own.getX()>=992&&own.getX()<=1037&&own.getZ()>=992&&own.getZ()<=1037;
            controller.exchangeHeading(ExchangeFootwork.choose(AirborneObservation.body(own,own.getVelocity()),
                AirborneObservation.body(target,tv),arena?992.4:own.getX()-16,arena?1036.6:own.getX()+16,
                arena?992.4:own.getZ()-16,arena?1036.6:own.getZ()+16,(x,y,z)->clear(own,x,y,z)));
        }
    }

    static boolean clear(Player own,double x,double y,double z) {
        var b=own.getBoundingBox();double hx=b.getWidthX()/2,hz=b.getWidthZ()/2;
        var box=new BoundingBox(x-hx,y+.001,z-hz,x+hx,y+b.getHeight()-.001,z+hz);
        for(int bx=(int)Math.floor(box.getMinX());bx<=Math.floor(box.getMaxX());bx++)
            for(int by=(int)Math.floor(box.getMinY());by<=Math.floor(box.getMaxY());by++)
                for(int bz=(int)Math.floor(box.getMinZ());bz<=Math.floor(box.getMaxZ());bz++) {
                    var block=own.getWorld().getBlockAt(bx,by,bz);
                    if(!block.isPassable()&&block.getBoundingBox().overlaps(box))return false;
                }
        return true;
    }
}

package local.pvpbot.ai;

import java.util.*;
import static local.pvpbot.ai.ArrowDodgePlanner.*;

/** World-space native-input search. No Bukkit state, velocity writes or random dodge choice. */
final class ArrowEscapePlanner {
    interface Space { boolean clear(Vec from, Vec to, double halfWidth, double height); }
    record Motion(Body body, double friction, double jumpPower, boolean canJump) {}
    record Route(Vec heading, boolean jump, boolean sprint, double exitTime, double clearance) {}
    private record Trial(Route route, double score) {}
    // 1.21.1 AbstractArrow -> ProjectileUtil expands the target AABB by 0.3.
    // The small additional margin covers float rounding without changing any hitbox.
    private static final double PAD=.32;

    static Route choose(Motion motion,List<Shot> shots,double eta,int primaryId,Vec committed,Space space) {
        if(shots.isEmpty())return null;
        double[][][] arrows=paths(shots);
        int primary=0;for(int i=0;i<shots.size();i++)if(shots.get(i).id()==primaryId)primary=i;
        // Preserve a still-safe escape. A new threat or obstacle can invalidate it immediately.
        if(committed!=null) {
            Trial keep=trial(motion,arrows,primary,committed,false,space);
            if(keep!=null)return keep.route();
        }
        List<Vec> directions=new ArrayList<>();
        int at=Math.max(0,Math.min(HORIZON-1,(int)Math.floor(eta)));
        var line=arrows[primary];while(at>0&&!Double.isFinite(line[at+1][0]))at--;
        double dx=line[at+1][0]-line[at][0],dz=line[at+1][2]-line[at][2];
        add(directions,-dz,dx);add(directions,dz,-dx);
        add(directions,motion.body().velocity().x(),motion.body().velocity().z());
        add(directions,motion.body().forward().x(),motion.body().forward().z());
        for(int i=0;i<24;i++)add(directions,Math.cos(i*Math.PI/12),Math.sin(i*Math.PI/12));
        Trial best=null;
        for(Vec heading:directions)for(boolean jump:new boolean[]{false,true}) {
            if(jump&&!motion.canJump())continue;
            Trial candidate=trial(motion,arrows,primary,heading,jump,space);
            if(candidate!=null&&(best==null||candidate.score()<best.score()))best=candidate;
        }
        return best==null?null:best.route();
    }

    private static void add(List<Vec> directions,double x,double z) {
        double length=Math.hypot(x,z);if(length<1e-8)return;
        Vec heading=new Vec(x/length,0,z/length);
        for(Vec old:directions)if(old.x()*heading.x()+old.z()*heading.z()>.99999)return;
        directions.add(heading);
    }

    private static Trial trial(Motion motion,double[][][] arrows,int primary,Vec heading,boolean jump,Space space) {
        Body b=motion.body();boolean sprint=b.canSprint();
        double x=b.feet().x(),y=b.feet().y(),z=b.feet().z();
        double vx=b.velocity().x(),vy=b.velocity().y(),vz=b.velocity().z();
        boolean grounded=b.onGround();
        if(jump) {
            if(!grounded||!motion.canJump())return null;
            vy=Math.max(vy,motion.jumpPower());
            if(sprint){vx+=heading.x()*.2;vz+=heading.z()*.2;}
        }
        double clearance=Double.POSITIVE_INFINITY,exit=Double.POSITIVE_INFINITY;
        double[][] reference=arrows[primary];
        double nx=-(reference[1][2]-reference[0][2]),nz=reference[1][0]-reference[0][0];
        double norm=Math.hypot(nx,nz);if(norm>1e-8){nx/=norm;nz/=norm;}
        double width=(b.halfWidth()+PAD)*(Math.abs(nx)+Math.abs(nz));
        double prior=Math.abs((x-reference[0][0])*nx+(z-reference[0][2])*nz);
        if(prior>width+.03)exit=0;
        for(int t=0;t<HORIZON;t++) {
            boolean wasGrounded=grounded;
            double acceleration=wasGrounded?b.acceleration()*.21600002/Math.pow(motion.friction()/.91,3):.02;
            if(sprint)acceleration*=1.3;
            if(Math.abs(vx)<.003)vx=0;if(Math.abs(vz)<.003)vz=0;
            vx+=heading.x()*.98*acceleration;vz+=heading.z()*.98*acceleration;
            double px=x,py=y,pz=z;x+=vx;z+=vz;y+=vy;
            grounded=y<=b.floorY()&&vy<=0;
            if(grounded){y=b.floorY();vy=0;}
            if(x-b.halfWidth()<b.minX()||x+b.halfWidth()>b.maxX()||z-b.halfWidth()<b.minZ()||z+b.halfWidth()>b.maxZ())return null;
            if(!space.clear(new Vec(px,py,pz),new Vec(x,y,z),b.halfWidth(),b.height()))return null;
            for(double[][] arrow:arrows) {
                if(!Double.isFinite(arrow[t+1][0]))continue;
                double ax=arrow[t][0]-px,ay=arrow[t][1]-py,az=arrow[t][2]-pz;
                double bx=arrow[t+1][0]-x,by=arrow[t+1][1]-y,bz=arrow[t+1][2]-z;
                double margin=segmentBoxDistance(ax,ay,az,bx,by,bz,b.halfWidth()+PAD,-PAD,b.height()+PAD);
                // Entity iteration can advance the arrow before the fakeplayer's
                // next physics step. A safe continuous crossing alone is insufficient.
                margin=Math.min(margin,segmentBoxDistance(ax,ay,az,arrow[t+1][0]-px,arrow[t+1][1]-py,
                    arrow[t+1][2]-pz,b.halfWidth()+PAD,-PAD,b.height()+PAD));
                if(margin<=1e-12)return null;
                clearance=Math.min(clearance,Math.sqrt(margin));
            }
            double lateral=Math.abs((x-reference[0][0])*nx+(z-reference[0][2])*nz);
            if(!Double.isFinite(exit)&&lateral>width+.03)
                exit=t+Math.max(0,Math.min(1,(width+.03-prior)/Math.max(1e-8,lateral-prior)));
            prior=lateral;
            vx*=wasGrounded?motion.friction():.91;vz*=wasGrounded?motion.friction():.91;
            vy=(vy-.08)*.98;
        }
        // Safety is a hard gate above. Among safe paths leave the arrow corridor
        // first; use clearance and retained momentum to break close ties.
        double time=Double.isFinite(exit)?exit:HORIZON;
        double speed=Math.hypot(b.velocity().x(),b.velocity().z());
        double inertia=speed<.01?0:(heading.x()*b.velocity().x()+heading.z()*b.velocity().z())/speed;
        double score=time-Math.min(.5,clearance)*.12-inertia*.03+(jump?.025:0);
        return new Trial(new Route(heading,jump,sprint,time,clearance),score);
    }

    static double[][][] paths(List<Shot> shots) {
        double[][][] result=new double[shots.size()][HORIZON+1][3];
        for(int i=0;i<shots.size();i++) {
            Shot s=shots.get(i);double x=s.position().x(),y=s.position().y(),z=s.position().z();
            double vx=s.velocity().x(),vy=s.velocity().y(),vz=s.velocity().z();
            for(int t=0;t<=HORIZON;t++) {
                if(!s.observedPath().isEmpty()) {
                    Vec p=t<s.observedPath().size()?s.observedPath().get(t):new Vec(Double.NaN,Double.NaN,Double.NaN);
                    result[i][t]=new double[]{p.x(),p.y(),p.z()};
                }else {
                    result[i][t]=new double[]{x,y,z};x+=vx;y+=vy;z+=vz;
                    vx*=s.drag();vy=vy*s.drag()-(s.gravity()?.05:0);vz*=s.drag();
                }
            }
        }
        return result;
    }

    // Exact minimum distance between a relative-motion segment and the expanded
    // body box. Break at every slab boundary; each interval is a quadratic.
    static double segmentBoxDistance(double ax,double ay,double az,double bx,double by,double bz,double half,double low,double high) {
        double[] start={ax,ay,az},delta={bx-ax,by-ay,bz-az},min={-half,low,-half},max={half,high,half};
        double[] cuts=new double[8];int n=2;cuts[0]=0;cuts[1]=1;
        for(int axis=0;axis<3;axis++)if(Math.abs(delta[axis])>1e-12)for(double boundary:new double[]{min[axis],max[axis]}) {
            double t=(boundary-start[axis])/delta[axis];if(t>0&&t<1)cuts[n++]=t;
        }
        Arrays.sort(cuts,0,n);double best=Double.POSITIVE_INFINITY;
        for(int i=0;i<n-1;i++) {
            double mid=(cuts[i]+cuts[i+1])/2,numerator=0,denominator=0;
            for(int axis=0;axis<3;axis++) {
                double v=start[axis]+mid*delta[axis];
                if(v>=min[axis]&&v<=max[axis])continue;
                double base=start[axis]-(v<min[axis]?min[axis]:max[axis]);
                numerator+=base*delta[axis];denominator+=delta[axis]*delta[axis];
            }
            double t=denominator<1e-15?cuts[i]:Math.max(cuts[i],Math.min(cuts[i+1],-numerator/denominator));
            double distance=0;
            for(int axis=0;axis<3;axis++) {double v=start[axis]+t*delta[axis];double d=Math.max(0,Math.max(min[axis]-v,v-max[axis]));distance+=d*d;}
            best=Math.min(best,distance);
        }
        return best;
    }
}

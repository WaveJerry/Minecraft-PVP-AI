package local.pvpbot.ai;

import java.lang.reflect.*;
import java.util.*;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import io.papermc.paper.event.player.PlayerStopUsingItemEvent;
import io.papermc.paper.event.player.PrePlayerAttackEntityEvent;
import com.destroystokyo.paper.event.player.PlayerJumpEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.CrossbowMeta;
import org.bukkit.util.Vector;

/** Offhand inventory transfers and native use inputs. Never creates projectiles or modifies physics. */
final class OffhandRangedSupport implements Listener {
    private static final Map<UUID,Context> contexts=new HashMap<>();
    private static PvPArenaAI registered;
    private static final Map<String,Method> methods=new HashMap<>();
    private static final class Context {
        PvPArenaAI plugin;Player own,target;CombatMemory memory;InitialCombatController controller;
        NeuralLearner.Senses senses;long tick,defendedUntil=-1000;
        CombatView view;
        boolean bowMirror,firing,responding;Material drawing;
        final CrossbowLoadSession load=new CrossbowLoadSession();
    }
    static Object invoke(PvPArenaAI plugin,String name,Class<?>[] types,Object...args) {
        try {
            String key=name+Arrays.toString(types);var m=methods.get(key);
            if(m==null){m=PvPArenaAI.class.getDeclaredMethod(name,types);m.setAccessible(true);methods.put(key,m);}
            return m.invoke(plugin,args);
        }catch(ReflectiveOperationException e){throw new IllegalStateException("Offhand input bridge: "+name,e);}
    }
    static boolean charged(ItemStack item) {
        return item!=null&&item.getType()==Material.CROSSBOW&&item.getItemMeta() instanceof CrossbowMeta meta&&meta.hasChargedProjectiles();
    }
    static boolean charged(Player p) {for(var i:p.getInventory().getContents())if(charged(i))return true;return false;}
    private static boolean activeRanged(Player p) {return p.hasActiveItem()&&(p.getActiveItem().getType()==Material.BOW||p.getActiveItem().getType()==Material.CROSSBOW);}
    private static boolean drawing(Player p,Material material) {return p.hasActiveItem()&&p.getActiveItem().getType()==material;}
    private static boolean ammo(Context c) {return c.memory.shotsFired<c.memory.ammoBudget;}
    private static long now(PvPArenaAI plugin) {
        try {var f=PvPArenaAI.class.getDeclaredField("tick");f.setAccessible(true);return f.getLong(plugin);}
        catch(ReflectiveOperationException e){throw new IllegalStateException(e);}
    }
    private static boolean active(Context c) {return now(c.plugin)-c.tick<=2&&c.own.isOnline()&&!c.own.isDead();}
    private static boolean live(Context c) {return active(c)&&c.target!=null&&c.target.isOnline()&&!c.target.isDead();}
    private static void install(PvPArenaAI plugin) {
        if(registered==plugin)return;
        contexts.clear();methods.clear();registered=plugin;
        Bukkit.getPluginManager().registerEvents(new OffhandRangedSupport(),plugin);CombatOutcomeTrace.install(plugin);
    }
    static boolean ambientDefence(PvPArenaAI plugin,Player own,CombatMemory memory) {
        install(plugin);
        var c=contexts.get(own.getUniqueId());
        if(c==null||c.memory!=memory){c=new Context();contexts.put(own.getUniqueId(),c);}
        var brain=invoke(plugin,"brainFor",new Class<?>[]{Player.class},own);
        try {
            var learner=brain.getClass().getDeclaredField("learner");learner.setAccessible(true);
            c.controller=((NeuralLearner)learner.get(brain)).groundController();
        }catch(ReflectiveOperationException e){throw new IllegalStateException(e);}
        c.plugin=plugin;c.own=own;c.target=null;c.memory=memory;c.tick=now(plugin);
        c.senses=new NeuralLearner.Senses();
        return c.tick<=c.defendedUntil||defend(c,null);
    }
    static void observe(NeuralLearner.Senses s,Player own,Player target,CombatMemory memory,InitialCombatController controller) {
        if(target==null)return;
        var c=contexts.get(own.getUniqueId());
        if(c==null||c.memory!=memory)return;
        boolean inReach=s.targetMotionFresh&&s.estimateAge<=1&&CombatInputHooks.eyeBox(own,target)<=3&&own.hasLineOfSight(target);
        boolean critical=(controller.counterHopActive()||controller.exchangeMotion())&&s.ownCriticalWindow;
        boolean loadPunish=drawing(target,Material.CROSSBOW)&&own.getCooledAttackStrength(0)>=.999f;
        boolean wallHurt=s.retreatBlocked&&s.damageAge>=0&&s.damageAge<=1&&s.targetAttackAge<=1;
        if(activeRanged(own)&&inReach&&(critical||loadPunish||wallHurt)) {
            cancel(c,true);s.usingRanged=false;
            long tick=now(c.plugin);
            s.weaponInputReady=memory.pendingOffhandSlot<0&&memory.restoreMainSlot<0&&tick>=memory.weaponReadyUntil&&tick-memory.lastWeaponSwitch>=1;
        }
        c.tick=now(c.plugin);c.senses=s;
        refreshDefence(c,null);
        verifyTargetLoad(c);
        if(c.bowMirror&&!drawing(target,Material.BOW)) {
            cancel(c,true);
            s.usingRanged=false;s.weaponInputReady=memory.pendingOffhandSlot<0&&memory.restoreMainSlot<0;
        }
    }
    /** Returns true only when this helper has fully executed the frame. Melee stays in the original path. */
    static boolean execute(PvPArenaAI plugin,Player own,Player target,CombatMemory memory,InitialCombatController controller,
                           CombatView view,NeuralLearner.Senses s,CombatDecision frame,long tick) {
        install(plugin);
        var c=contexts.get(own.getUniqueId());
        if(c==null||c.memory!=memory){c=new Context();contexts.put(own.getUniqueId(),c);}
        c.plugin=plugin;c.own=own;c.target=target;c.memory=memory;c.controller=controller;c.senses=s;c.view=view;c.tick=tick;
        CombatOutcomeTrace.begin(own,target,memory,controller,tick,s,frame);
        if(tick<=c.defendedUntil)return true; // Do not overwrite an event-time successful dodge later in the same tick.
        if(defend(c,null))return true;
        if(ProjectileMovementPriority.owns(s)){cancel(c,true);return false;}
        verifyTargetLoad(c);
        boolean projectile=s.projectilePlan!=null&&s.projectilePlan.threat();
        boolean mirrorCrossbow=view.visible()&&drawing(target,Material.CROSSBOW)&&!charged(target.getActiveItem())&&!charged(own)&&view.hasArrows()&&ammo(c);
        boolean mirrorBow=view.visible()&&s.targetMotionFresh&&!view.ownShieldAvailable()&&s.ownReachDistance<=3.3&&drawing(target,Material.BOW)&&view.hasArrows()&&ammo(c);
        boolean mustDefend=projectile&&ProjectileMovementPriority.owns(s);
        // Save the existing escape line before any instant-turn attack changes look.
        controller.rememberFlightLook(own.getYaw(),own.getPitch());
        if(frame.attack()||controller.exchangeMotion()||controller.advanceActive()||projectile&&(!mirrorBow||mustDefend)||!mirrorCrossbow&&view.ownShieldAvailable()&&AirborneEnvelope.relevant(s)) {cancel(c,true);return false;}
        if(c.load.finishing()) {
            if(finishLoad(c)){move(c,frame,true);review(c,view,frame,"FINISH_MIRROR_LOAD");return true;}
        }
        if(c.load.verifying()){move(c,frame,true);review(c,view,frame,"VERIFY_MIRROR_LOAD_RESULT");return true;}
        if(view.visible()&&drawing(target,Material.CROSSBOW)&&!charged(target.getActiveItem())&&charged(own)&&ammo(c)&&cannotDodgeOutgoing(c)) {
            if(fireCrossbow(c,controller.counterHopActive())) {
                if(view.hasArrows()&&begin(c,Material.CROSSBOW))c.load.start(target.getActiveItemHand()==org.bukkit.inventory.EquipmentSlot.OFF_HAND?40:target.getInventory().getHeldItemSlot());
                review(c,view,frame,"LOAD_REPLY_AND_MIRROR");return true;
            }
        }
        if(c.bowMirror&&!mirrorBow)cancel(c,true);
        if(mirrorCrossbow||mirrorBow) {
            Material desired=mirrorCrossbow?Material.CROSSBOW:Material.BOW;
            int loadSlot=desired==Material.CROSSBOW?(target.getActiveItemHand()==org.bukkit.inventory.EquipmentSlot.OFF_HAND?40:target.getInventory().getHeldItemSlot()):-1;
            if(begin(c,desired)){if(desired==Material.CROSSBOW)c.load.start(loadSlot);else c.bowMirror=true;move(c,frame,true);review(c,view,frame,"MIRROR_"+desired);return true;}
        }
        if(!controller.counterHopActive()&&!charged(own)&&view.visible()&&s.ownReachDistance>8&&s.targetReachDistance>8&&view.hasArrows()&&ammo(c)) {
            if(begin(c,Material.CROSSBOW)){move(c,frame,true);review(c,view,frame,"DISTANT_CROSSBOW_LOAD");return true;}
        }
        if(frame.shield()){cancel(c,true);return false;}
        boolean ranged=frame.weapon()==Weapon.BOW||frame.weapon()==Weapon.CROSSBOW;
        if(!ranged){cancel(c,true);return false;}
        if(controller.counterHopActive()&&frame.weapon()==Weapon.CROSSBOW) {
            cancel(c,true);
            invoke(plugin,"resumeRetreatInputs",new Class<?>[]{Player.class,CombatMemory.class,boolean.class},own,memory,false);
            review(c,view,frame,"ESCAPE_HOLD_CROSSBOW");return true;
        }
        // Autonomous fire is disabled. Only shot-event and specified loading replies fire.
        cancel(c,true);melee(c);
        if(view.ownShieldAvailable())invoke(plugin,"shieldTick",new Class<?>[]{Player.class,boolean.class},own,true);
        move(c,frame,false);review(c,view,frame,"AUTONOMOUS_RANGED_DISABLED");return true;
    }
    private static void melee(Context c) {
        Weapon weapon=c.controller.keepEscapeSword()?Weapon.SWORD:Weapon.AXE;
        invoke(c.plugin,"selectWeapon",new Class<?>[]{Player.class,CombatMemory.class,Weapon.class,boolean.class},c.own,c.memory,weapon,true);
    }
    private static boolean swap(Context c,Material material) {
        var inv=c.own.getInventory();if(inv.getItemInOffHand().getType()==material)return true;
        int source=-1;for(int i=0;i<36;i++){var item=inv.getItem(i);if(i!=inv.getHeldItemSlot()&&item!=null&&item.getType()==material){source=i;break;}}
        if(source<0)return false;
        if(c.own.hasActiveItem())c.own.clearActiveItem();
        var item=inv.getItem(source);var off=inv.getItemInOffHand();inv.setItem(source,off);inv.setItemInOffHand(item);
        c.memory.lastOffhandSwitch=c.tick;c.own.updateInventory();return true;
    }
    private static boolean begin(Context c,Material material) {
        if(c.drawing!=null&&c.drawing!=material)cancel(c,true);
        melee(c);if(!swap(c,material))return false;
        c.drawing=material;
        if(material==Material.CROSSBOW&&charged(c.own.getInventory().getItemInOffHand()))return true;
        if(material==Material.CROSSBOW&&drawing(c.own,material)) {
            int duration=NativeCrossbowTiming.duration(c.own,c.own.getInventory().getItemInOffHand());
            if(c.own.getHandRaisedTime()>=duration)VanillaUseRelease.release(c.own);
            if(charged(c.own.getInventory().getItemInOffHand()))return true;
        }
        if(!drawing(c.own,material)) {
            invoke(c.plugin,"cancelCombatUse",new Class<?>[]{Player.class,CombatMemory.class},c.own,c.memory);
            NativeUseSession.detachQueuedUse(c.plugin,c.own);
            NativeOffhandUse.use(c.own);
            CombatOutcomeTrace.note(c.own,"USE_START material="+material);
            c.memory.chargeStart=c.tick;c.memory.chargingWeapon=material==Material.BOW?Weapon.BOW:Weapon.CROSSBOW;
        }
        return drawing(c.own,material)||material==Material.CROSSBOW&&charged(c.own);
    }
    private static void cancel(Context c,boolean restore) {
        if(c.load.active())CombatOutcomeTrace.note(c.own,"LOAD_CANCEL phase="+c.load.phase()+" ownLoaded="+charged(c.own));
        c.load.reset();
        if(c.drawing!=null||activeRanged(c.own)) {
            c.drawing=null;c.bowMirror=false;
            invoke(c.plugin,"cancelCombatUse",new Class<?>[]{Player.class,CombatMemory.class},c.own,c.memory);
        }
        // cancelCombatUse queues a USE stop; remove it before a new native shield
        // or ranged use, or that old stop can release the newly raised item.
        NativeUseSession.detachQueuedUse(c.plugin,c.own);
        if(restore&&c.own.getInventory().getItemInOffHand().getType()!=Material.SHIELD)swap(c,Material.SHIELD);
    }
    @EventHandler(priority=EventPriority.MONITOR)
    public void stopUsing(PlayerStopUsingItemEvent event) {
        if(event.getItem().getType()!=Material.CROSSBOW)return;
        int duration=NativeCrossbowTiming.duration(event.getPlayer(),event.getItem());
        for(var c:List.copyOf(contexts.values())) {
            if(!live(c)||c.firing||!c.load.active()||!event.getPlayer().getUniqueId().equals(c.target.getUniqueId()))continue;
            c.tick=now(c.plugin);
            c.load.released(charged(event.getItem())||targetLoadCharged(c),event.getTicksHeldFor(),duration,c.tick,remainingLoad(c));
            CombatOutcomeTrace.note(c.own,"TARGET_LOAD_RELEASE state="+c.load.phase()+" held="+event.getTicksHeldFor()+" duration="+duration);
            if(!c.load.active())cancel(c,true);
        }
    }
    private static boolean targetLoadCharged(Context c) {
        return c.load.targetSlot()>=0&&charged(c.target.getInventory().getItem(c.load.targetSlot()));
    }
    private static int remainingLoad(Context c) {
        if(charged(c.own))return 0;
        return Math.max(0,NativeCrossbowTiming.duration(c.own,c.own.getInventory().getItemInOffHand())
            -(drawing(c.own,Material.CROSSBOW)?c.own.getHandRaisedTime():0));
    }
    private static void verifyTargetLoad(Context c) {
        if(!c.load.active())return;
        c.load.observe(targetLoadCharged(c),drawing(c.target,Material.CROSSBOW),c.tick,remainingLoad(c));
        if(!c.load.active())cancel(c,true);
    }
    private static boolean finishLoad(Context c) {
        if(!c.load.finishing())return false;
        if(charged(c.own)){CombatOutcomeTrace.note(c.own,"LOAD_CONFIRMED_REAL_CHARGED_ITEM");cancel(c,true);return false;}
        if(c.load.expired(c.tick)){CombatOutcomeTrace.note(c.own,"LOAD_FAILED_TIMEOUT");cancel(c,true);return false;}
        if(!drawing(c.own,Material.CROSSBOW)) {
            int duration=NativeCrossbowTiming.duration(c.own,c.own.getInventory().getItemInOffHand());
            if(!c.load.restart(c.tick,duration)||!begin(c,Material.CROSSBOW)){cancel(c,true);return false;}
        }
        int duration=NativeCrossbowTiming.duration(c.own,c.own.getInventory().getItemInOffHand());
        if(c.own.getHandRaisedTime()<duration)return true;
        VanillaUseRelease.release(c.own);
        if(!charged(c.own))return true;
        CombatOutcomeTrace.note(c.own,"LOAD_CONFIRMED_REAL_CHARGED_ITEM");cancel(c,true);return false;
    }
    private static void aim(Context c,Weapon weapon) {
        var brain=invoke(c.plugin,"brainFor",new Class<?>[]{Player.class},c.own);
        try {
            var f=brain.getClass().getDeclaredField("learner");f.setAccessible(true);var learner=f.get(brain);
            var lead=learner.getClass().getDeclaredMethod("leadMultiplier");lead.setAccessible(true);
            invoke(c.plugin,"rotateToward",new Class<?>[]{Player.class,Player.class,CombatMemory.class,Weapon.class,double.class,boolean.class},
                c.own,c.target,c.memory,weapon,((Number)lead.invoke(learner)).doubleValue(),false);
            if(c.memory.rangedAimGoal!=null)invoke(c.plugin,"turnToDirection",new Class<?>[]{Player.class,Vector.class,float.class},c.own,c.memory.rangedAimGoal.clone().subtract(c.own.getEyeLocation().toVector()),180f);
        }catch(ReflectiveOperationException e){throw new IllegalStateException(e);}
    }
    private static void resume(Context c,boolean retreat,float yaw,float pitch) {
        if(retreat)invoke(c.plugin,"resumeRetreatInputs",new Class<?>[]{Player.class,CombatMemory.class,boolean.class},c.own,c.memory,false);
        else c.own.setRotation(yaw,pitch);
    }
    private static boolean fireCrossbow(Context c,boolean retreat) {
        if(c.firing||!ammo(c)||!charged(c.own)||!c.own.hasLineOfSight(c.target))return false;
        float yaw=c.own.getYaw(),pitch=c.own.getPitch();c.firing=true;
        try {melee(c);if(!swap(c,Material.CROSSBOW))return false;cancelUseOnly(c);aim(c,Weapon.CROSSBOW);NativeOffhandUse.use(c.own);return true;}
        finally{c.firing=false;c.drawing=null;c.bowMirror=false;swap(c,Material.SHIELD);resume(c,retreat,yaw,pitch);}
    }
    private static boolean releaseBow(Context c,boolean retreat) {
        if(c.firing||!drawing(c.own,Material.BOW)||!ammo(c)||!c.own.hasLineOfSight(c.target))return false;
        float yaw=c.own.getYaw(),pitch=c.own.getPitch();c.firing=true;
        try {aim(c,Weapon.BOW);return VanillaUseRelease.release(c.own);}
        finally{c.firing=false;cancel(c,true);resume(c,retreat,yaw,pitch);}
    }
    private static void cancelUseOnly(Context c) {invoke(c.plugin,"cancelCombatUse",new Class<?>[]{Player.class,CombatMemory.class},c.own,c.memory);NativeUseSession.detachQueuedUse(c.plugin,c.own);}
    private static void move(Context c,CombatDecision frame,boolean using) {
        if(frame.faceAway()) {
            var delta=c.own.getLocation().toVector().subtract(c.target.getLocation().toVector()).setY(0);
            if(delta.lengthSquared()>1e-8)invoke(c.plugin,"turnToDirection",new Class<?>[]{Player.class,Vector.class,float.class},c.own,delta,180f);
            invoke(c.plugin,"move",new Class<?>[]{Player.class,Motion.class,boolean.class,boolean.class,boolean.class},c.own,Motion.FORWARD,false,frame.sprint()&&!using,true);
        } else invoke(c.plugin,"move",new Class<?>[]{Player.class,Motion.class,boolean.class,boolean.class,boolean.class},c.own,frame.motion(),false,frame.sprint()&&!using,true);
    }
    private static void review(Context c,CombatView view,CombatDecision frame,String phase) {
        var brain=invoke(c.plugin,"brainFor",new Class<?>[]{Player.class},c.own);
        try {
            var f=brain.getClass().getDeclaredField("review");f.setAccessible(true);var review=(CombatReview)f.get(brain);
            review.decision(c.tick,phase,frame,false,c.own.isBlocking(),c.senses.projectilePlan==null?60:c.senses.projectilePlan.eta(),c.senses.ownReachDistance,-1,frame.motion());
        }catch(ReflectiveOperationException e){throw new IllegalStateException(e);}
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void attack(PrePlayerAttackEntityEvent event) {
        if(!event.willAttack())return;
        for(var c:List.copyOf(contexts.values())) {
            if(!live(c)||c.responding||ProjectileMovementPriority.owns(c.senses)||c.tick<=c.defendedUntil||!event.getPlayer().getUniqueId().equals(c.target.getUniqueId())
                    ||!event.getAttacked().getUniqueId().equals(c.own.getUniqueId())
                    ||!c.controller.synchronizedExchange()||c.controller.counterHopActive()
                    ||!c.own.hasCooldown(Material.SHIELD)&&!c.controller.exchangeShieldGrace()
                    ||CombatInputHooks.eyeBox(c.own,c.target)>3||!c.own.hasLineOfSight(c.target))continue;
            c.tick=now(c.plugin);
            boolean critical=NativeCriticalState.read(c.target).now();
            c.controller.opponentAttack(c.tick,critical);
            if(CombatInputHooks.effectiveShield(c.own,c.target))continue;
            if(critical&&!NativeCriticalState.read(c.own).afterSprintRelease()) {
                CombatOutcomeTrace.note(c.own,"SYNC_CRITICAL_WAIT own="+NativeCriticalState.read(c.own));continue;
            }
            var frame=c.controller.synchronizedAttack(c.view,critical);if(frame==null)continue;
            c.responding=true;
            try {
                cancel(c,true);
                var brain=invoke(c.plugin,"brainFor",new Class<?>[]{Player.class},c.own);
                invoke(c.plugin,"executeCombatFrame",new Class<?>[]{Player.class,Player.class,brain.getClass(),CombatView.class,NeuralLearner.Senses.class,CombatDecision.class},
                    c.own,c.target,brain,c.view,c.senses,frame);
                CombatOutcomeTrace.note(c.own,"SYNCHRONIZED_ATTACK sameOpponentEvent=true critical="+critical);
            } finally {c.responding=false;}
        }
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void jump(PlayerJumpEvent event) {
        for(var c:List.copyOf(contexts.values())) {
            if(!live(c)||ProjectileMovementPriority.owns(c.senses)||!event.getPlayer().getUniqueId().equals(c.target.getUniqueId())
                    ||!c.controller.landingTradePending()||!c.controller.mayPlanTrade()
                    ||!c.own.hasCooldown(Material.SHIELD)&&!c.controller.exchangeShieldGrace()||!c.own.isOnGround()
                    ||CombatInputHooks.eyeBox(c.own,c.target)>3||c.own.getFoodLevel()<=6
                    ||c.own.isInWater()||c.own.isClimbing()||c.own.isInsideVehicle()
                    ||now(c.plugin)-c.memory.lastJump<10||c.tick<=c.defendedUntil)continue;
            c.tick=now(c.plugin);
            // PlayerJumpEvent runs before the opponent's own native jumpFromGround.
            // Forecast that ordinary jump for direction choice; actual hits remain live.
            var target=AirborneObservation.body(c.target,c.memory.observedTargetVelocity);
            var anticipated=new AirborneEnvelope.Body(target.x(),target.y(),target.z(),target.vx(),.42,target.vz(),
                target.eye(),target.halfX(),target.halfZ(),target.height(),false);
            boolean arena=c.own.getX()>=992&&c.own.getX()<=1037&&c.own.getZ()>=992&&c.own.getZ()<=1037;
            var plan=TradeJump.plan(AirborneObservation.body(c.own,c.own.getVelocity()),anticipated,
                arena?992.4:c.own.getX()-16,arena?1036.6:c.own.getX()+16,
                arena?992.4:c.own.getZ()-16,arena?1036.6:c.own.getZ()+16,(x,y,z)->TradeObservation.clear(c.own,x,y,z));
            if(!c.controller.synchronizeTrade(plan,c.tick))continue;
            cancel(c,true);
            invoke(c.plugin,"turnToDirection",new Class<?>[]{Player.class,Vector.class,float.class},c.own,new Vector(plan.x(),0,plan.z()),180f);
            invoke(c.plugin,"move",new Class<?>[]{Player.class,Motion.class,boolean.class,boolean.class,boolean.class},c.own,Motion.FORWARD,false,true,true);
            if(NativeUseSession.jumpNow(c.plugin,c.own)) {
                c.memory.lastJump=c.tick;c.controller.jumpInputSubmitted(c.tick);
                CombatOutcomeTrace.note(c.own,"SYNCHRONIZED_NATIVE_JUMP sameOpponentEvent=true");
            } else c.controller.cancelSynchronizedTrade();
        }
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void interact(PlayerInteractEvent event) {
        if(event.useItemInHand()==Event.Result.DENY||event.getAction()!=Action.RIGHT_CLICK_AIR&&event.getAction()!=Action.RIGHT_CLICK_BLOCK)return;
        var item=event.getItem();if(item==null||item.getType()!=Material.CROSSBOW&&item.getType()!=Material.BOW||charged(item))return;
        for(var c:List.copyOf(contexts.values())) {
            if(!live(c)||c.firing||!event.getPlayer().getUniqueId().equals(c.target.getUniqueId())||!ammo(c)||!c.own.hasLineOfSight(c.target))continue;
            c.tick=now(c.plugin);
            if(c.tick<=c.defendedUntil)continue;
            if(ProjectileMovementPriority.owns(c.senses))continue;
            if(c.controller.meleeRequested())continue;
            if(item.getType()==Material.CROSSBOW&&charged(c.own)&&cannotDodgeOutgoing(c))fireCrossbow(c,c.controller.counterHopActive());
            boolean crossbow=item.getType()==Material.CROSSBOW&&!charged(c.own);
            boolean bow=item.getType()==Material.BOW&&c.own.hasCooldown(Material.SHIELD)&&CombatInputHooks.eyeBox(c.own,c.target)<=3.3;
            if((crossbow||bow)&&!(c.senses.projectilePlan!=null&&c.senses.projectilePlan.threat())&&begin(c,item.getType())) {
                if(crossbow)c.load.start(event.getHand()==org.bukkit.inventory.EquipmentSlot.OFF_HAND?40:c.target.getInventory().getHeldItemSlot());
                else c.bowMirror=true;
            }
        }
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void shot(EntityShootBowEvent event) {
        if(event.getBow()==null||!(event.getProjectile() instanceof AbstractArrow arrow))return;
        for(var c:List.copyOf(contexts.values())) {
            if(!active(c)||c.firing||event.getEntity().getUniqueId().equals(c.own.getUniqueId()))continue;
            c.tick=now(c.plugin);
            if(defend(c,arrow))continue;
            if(!live(c)||!event.getEntity().getUniqueId().equals(c.target.getUniqueId()))continue;
            if(!ammo(c))continue; // Ammunition limits retaliation, never projectile defence.
            if(event.getBow().getType()==Material.CROSSBOW&&charged(c.own))fireCrossbow(c,c.controller.counterHopActive());
            else if(event.getBow().getType()==Material.BOW&&c.own.hasCooldown(Material.SHIELD))
                releaseBow(c,c.controller.counterHopActive());
        }
    }
    private static ProjectileDefence.Plan refreshDefence(Context c,AbstractArrow incoming) {
        var plan=ProjectileDefence.plan(c.plugin,c.own,c.controller.movementAction(),incoming);
        c.senses.projectilePlan=plan.path();
        c.senses.ownShieldCooldown=ProjectileDefence.hasShield(c.own)?0:Math.max(1,c.own.getCooldown(Material.SHIELD));
        if(plan.path().threat()) {
            c.senses.shieldCoversRanged=plan.shield()&&c.own.isBlocking();
            c.senses.shieldShouldRaise=plan.shield();
        } else if(!ProjectileDefence.hasShield(c.own)) {
            c.senses.shieldCoversRanged=c.senses.shieldShouldRaise=false;
        } // Preserve the current tick's pre-shot close bow/crossbow guard warning.
        return plan;
    }
    /** Tick and shot callbacks submit exactly the same evaluated input. */
    private static boolean defend(Context c,AbstractArrow incoming) {
        var plan=refreshDefence(c,incoming);
        if(!plan.path().threat())return incoming!=null;
        if(!plan.owns())return false; // No legal successful dodge: keep the close reply available.
        var p=c.own;
        cancel(c,true);
        if(plan.shield()) {
            p.setSneaking(false);
            invoke(c.plugin,"turnToDirection",new Class<?>[]{Player.class,Vector.class,float.class},p,plan.guard(),180f);
            invoke(c.plugin,"shieldTick",new Class<?>[]{Player.class,boolean.class},p,true);
            invoke(c.plugin,"applyMovementInput",new Class<?>[]{Player.class,float.class,float.class,boolean.class,boolean.class},p,0f,0f,false,false);
        } else {
            // Shield absent/broken only. Cancel USE before submitting the full-speed
            // path; shield or bow slow-down cannot invalidate the chosen dodge.
            invoke(c.plugin,"cancelCombatUse",new Class<?>[]{Player.class,CombatMemory.class},p,c.memory);
            NativeUseSession.detachQueuedUse(c.plugin,p);
            invoke(c.plugin,"turnToDirection",new Class<?>[]{Player.class,Vector.class,float.class},p,plan.forward(),180f);
            int action=plan.action();p.setSneaking(action>=12&&action<=16);
            invoke(c.plugin,"applyMovementInput",new Class<?>[]{Player.class,float.class,float.class,boolean.class,boolean.class},
                p,(float)ProjectileDefence.forward(action),(float)ProjectileDefence.side(action),false,GroundFootwork.sprinting(action));
            // Turn and sprint input first: vanilla's sprint-jump impulse must point
            // along the escape route. Execute the ordinary jump in this callback.
            if(plan.jump())NativeUseSession.jumpNow(c.plugin,p);
            ProjectileDefence.submitted(p,plan);
            c.memory.arrowDodgeTicks++;c.memory.arrowDodgeSubmittedAt=c.tick;
        }
        c.defendedUntil=c.tick;
        CombatOutcomeTrace.note(p,"PROJECTILE_OWNER shield="+plan.shield()+" action="+plan.action()+" jump="+plan.jump()+" eta="+plan.path().eta()+" arrow="+plan.path().primaryId());
        return true;
    }
    private static boolean clear(Player p,Vector d) {
        if(d.lengthSquared()<1e-8)return true;d=d.clone().normalize();
        for(double side:new double[]{-.29,0,.29})for(double y:new double[]{.1,1.5})
            if(p.getWorld().rayTraceBlocks(p.getLocation().clone().add(-d.getZ()*side,y,d.getX()*side),d,.75,FluidCollisionMode.NEVER,true)!=null)return false;
        return true;
    }
    private static boolean cannotDodgeOutgoing(Context c) {
        if(!c.own.hasLineOfSight(c.target))return false;
        var p=c.target;var feet=p.getLocation().toVector();var forward=p.getLocation().getDirection().setY(0);
        if(forward.lengthSquared()<1e-8)forward=new Vector(1,0,0);else forward.normalize();
        float yaw=c.own.getYaw(),pitch=c.own.getPitch();Vector launch;
        try {aim(c,Weapon.CROSSBOW);launch=c.own.getEyeLocation().getDirection().multiply(3.15);}
        finally {c.own.setRotation(yaw,pitch);}
        var box=p.getBoundingBox();var attribute=p.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED);
        double acceleration=attribute==null?.1:attribute.getValue()/(p.isSprinting()?1.3:1);
        boolean arena=p.getX()>=992&&p.getX()<=1037&&p.getZ()>=992&&p.getZ()<=1037;
        var body=new ArrowDodgePlanner.Body(vec(feet),vec(p.getVelocity()),vec(forward),Math.max(box.getWidthX(),box.getWidthZ())/2,
            box.getHeight(),acceleration,1,p.isOnGround(),p.getFoodLevel()>6,arena?992:feet.getX()-32,arena?1037:feet.getX()+32,
            arena?992:feet.getZ()-32,arena?1037:feet.getZ()+32,arena?221:feet.getY());
        var shot=new ArrowDodgePlanner.Shot(-1,vec(c.own.getEyeLocation().toVector().add(new Vector(0,-.1,0))),vec(launch),true,.99,true);
        var plan=ProjectileDefence.evaluate(body,List.of(shot),5,!p.hasCooldown(Material.SHIELD)&&has(p,Material.SHIELD),0);
        return plan.threat()&&!plan.shieldSafe()&&!ProjectileDefence.canEvade(p,body,List.of(shot),plan);
    }
    private static boolean safePlan(Player p,ArrowDodgePlanner.Result plan) {
        var forward=p.getLocation().getDirection().setY(0);if(forward.lengthSquared()<1e-8)forward=new Vector(1,0,0);else forward.normalize();
        return safeMove(p,plan,forward)>=0;
    }
    private static double dodgeForward(int action) {
        return switch(action){case 1,2,6,7,8,9,12->1;case 3,10,11,15->-1;default->0;};
    }
    private static double dodgeSide(int action) {
        return switch(action){case 4,6,8,10,13->-1;case 5,7,9,11,14->1;default->0;};
    }
    private static boolean safeMove(Player p,ArrowDodgePlanner.Result plan,Vector forward,int action) {
        if(action<0||action>=plan.safeMoves().length||!plan.safeMoves()[action]||!plan.viableMoves()[action])return false;
        return clear(p,forward.clone().multiply(dodgeForward(action)).add(new Vector(-forward.getZ(),0,forward.getX()).multiply(dodgeSide(action))));
    }
    private static int safeMove(Player p,ArrowDodgePlanner.Result plan,Vector forward) {
        if(safeMove(p,plan,forward,plan.preferredMove()))return plan.preferredMove();
        for(int action=0;action<plan.safeMoves().length;action++)if(plan.safeMoves()[action]&&plan.viableMoves()[action]) {
            if(safeMove(p,plan,forward,action))return action;
        }
        return -1;
    }
    private static boolean has(Player p,Material material){for(var i:p.getInventory().getContents())if(i!=null&&i.getType()==material)return true;return false;}
    private static ArrowDodgePlanner.Vec vec(Vector v){return new ArrowDodgePlanner.Vec(v.getX(),v.getY(),v.getZ());}
}

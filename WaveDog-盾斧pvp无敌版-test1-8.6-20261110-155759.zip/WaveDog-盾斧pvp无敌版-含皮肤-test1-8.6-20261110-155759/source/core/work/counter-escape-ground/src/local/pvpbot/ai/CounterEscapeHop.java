package local.pvpbot.ai;

/** One vanilla jump input after one confirmed, shield-broken counter hit. */
final class CounterEscapeHop {
    private long counterAt = -1000, submittedAt = -1000;
    private boolean active, spent, airborne, criticalSubmitted, exitAccepted;

    void reset() { counterAt = submittedAt = -1000; active = spent = airborne = criticalSubmitted = exitAccepted = false; }
    void arm(long tick) {
        if (tick <= counterAt) return;
        counterAt = tick; submittedAt = -1000; active = true; spent = airborne = criticalSubmitted = exitAccepted = false;
    }
    void observe(long tick, boolean onGround) {
        if (!active) return;
        if (!onGround) {
            airborne = true;
            spent = true; // Already in air: never manufacture another jump or queue one on landing.
        } else if (airborne) {
            active = false;
        } else if (submittedAt >= 0 && tick - submittedAt > 3 || submittedAt < 0 && tick - counterAt > 3) {
            // Vanilla restrictions or a blocked route prevented takeoff. Return to normal safe control.
            active = false; spent = true;
        }
    }
    void jumpSubmitted(long tick) {
        if (!active || spent || tick < counterAt) return;
        submittedAt = tick; spent = true;
    }
    boolean active() { return active; }
    boolean wasAirborne() { return airborne; }
    boolean allowsJump() { return !active || !spent; }
    boolean belongsTo(long tick) { return counterAt >= 0 && tick == counterAt; }
    boolean criticalAvailable(boolean nativeCriticalWindow, double velocityY) {
        // Take the first real native window. A fixed height cutoff can remove the entire
        // window while a newly equipped sword is still charging during this same jump.
        // Seek the critical BEFORE the last-boundary fallback. Once that final
        // blow really hits, this escape's attack sequence is complete.
        return active && airborne && !criticalSubmitted && !exitAccepted && nativeCriticalWindow
            && Double.isFinite(velocityY) && velocityY < 0;
    }
    void criticalSubmitted() { criticalSubmitted = true; }
    void acceptExit() { exitAccepted = true; }
    boolean exitAccepted() { return exitAccepted; }
    void blocked() { active = false; spent = true; }
}

package local.pvpbot.ai;

import java.lang.reflect.*;
import org.bukkit.entity.Player;

/** Normal server game-mode useItem(OFF_HAND), preserving item cooldowns and native ammo use. */
final class NativeOffhandUse {
    private record Access(Method handle,Field gameMode,Method level,Method stack,Method use,Object hand) {}
    private static final ClassValue<Access> ACCESS=new ClassValue<>() {
        protected Access computeValue(Class<?> craft) {
            try {
                var handle=craft.getMethod("getHandle");var loader=craft.getClassLoader();
                var server=Class.forName("net.minecraft.server.level.ServerPlayer",false,loader);
                var level=Class.forName("net.minecraft.world.level.Level",false,loader);var item=Class.forName("net.minecraft.world.item.ItemStack",false,loader);
                var hand=Class.forName("net.minecraft.world.InteractionHand",false,loader);
                var mode=server.getField("gameMode");
                @SuppressWarnings({"rawtypes","unchecked"}) Object off=Enum.valueOf((Class)hand,"OFF_HAND");
                return new Access(handle,mode,server.getMethod("serverLevel"),server.getMethod("getOffhandItem"),
                    mode.getType().getMethod("useItem",server,level,item,hand),off);
            }catch(ReflectiveOperationException e){throw new IllegalStateException("Native offhand input unavailable",e);}
        }
    };
    static void use(Player player) {
        try {
            var a=ACCESS.get(player.getClass());var handle=a.handle.invoke(player);
            a.use.invoke(a.gameMode.get(handle),handle,a.level.invoke(handle),a.stack.invoke(handle),a.hand);
        }catch(ReflectiveOperationException e){throw new IllegalStateException("Native offhand use failed",e);}
    }
}

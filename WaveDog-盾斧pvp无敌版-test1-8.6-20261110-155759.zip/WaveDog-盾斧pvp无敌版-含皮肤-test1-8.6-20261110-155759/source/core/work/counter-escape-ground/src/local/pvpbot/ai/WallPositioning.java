package local.pvpbot.ai;

/** Soft arena geometry preferences; never grants collision, reach or jump permission. */
final class WallPositioning {
    // Positioning aims, not a change to vanilla speed or a claim about jump distance.
    static final double WALL_RESERVE = 2.0, REAR_RESERVE = 4.0;

    static double margin(double x, double z, double minX, double maxX, double minZ, double maxZ) {
        return Math.max(0, Math.min(Math.min(x-minX,maxX-x),Math.min(z-minZ,maxZ-z)));
    }

    /** Arena room directly away from the opponent, in blocks; real blocks are probed separately. */
    static double rearRunway(double x, double z, double targetX, double targetZ,
            double minX, double maxX, double minZ, double maxZ) {
        double dx=x-targetX,dz=z-targetZ,length=Math.hypot(dx,dz);
        if(length<1e-8) return margin(x,z,minX,maxX,minZ,maxZ);
        dx/=length;dz/=length;
        double tx=dx>1e-8?(maxX-x)/dx:dx< -1e-8?(minX-x)/dx:Double.POSITIVE_INFINITY;
        double tz=dz>1e-8?(maxZ-z)/dz:dz< -1e-8?(minZ-z)/dz:Double.POSITIVE_INFINITY;
        return Math.max(0,Math.min(tx,tz));
    }

    /**
     * Score a legal own step as a prior only. Restore our wall/rear reserve first;
     * once our own retreat has room, prefer knockback toward the opponent's wall/corner.
     * rearClear is the current native rear probe, not a forecast of the hop path.
     */
    static double preference(double ownX, double ownZ, double targetX, double targetZ,
            double nextX, double nextZ, double minX, double maxX, double minZ, double maxZ,
            boolean rearClear) {
        double span=Math.min(maxX-minX,maxZ-minZ);
        if(!Double.isFinite(span) || span<=0 || !Double.isFinite(ownX) || !Double.isFinite(ownZ)
            || !Double.isFinite(targetX) || !Double.isFinite(targetZ)
            || !Double.isFinite(nextX) || !Double.isFinite(nextZ)) return 0;
        double step=Math.hypot(nextX-ownX,nextZ-ownZ);
        if(step<1e-8) return 0;
        double wallGoal=Math.min(WALL_RESERVE,span*.25),rearGoal=Math.min(REAR_RESERVE,span*.5);
        double before=space(ownX,ownZ,targetX,targetZ,minX,maxX,minZ,maxZ,wallGoal,rearGoal,rearClear);
        double after=space(nextX,nextZ,targetX,targetZ,minX,maxX,minZ,maxZ,wallGoal,rearGoal,rearClear);
        double score=after-before;
        // A full reserve is 1 wall + 2 rear. A blocked rear gives no reserve credit.
        // Never sacrifice our missing escape room just to corner the opponent.
        if(before>=3-1e-9 && after>=3-1e-9) {
            double cx=(minX+maxX)*.5,cz=(minZ+maxZ)*.5;
            score+=.25*(inwardPush(ownX,ownZ,targetX,targetZ,cx,cz)
                -inwardPush(nextX,nextZ,targetX,targetZ,cx,cz));
        }
        return score/Math.max(.05,step);
    }

    private static double space(double x,double z,double tx,double tz,
            double minX,double maxX,double minZ,double maxZ,double wallGoal,double rearGoal,boolean rearClear) {
        double walls=Math.min(1,margin(x,z,minX,maxX,minZ,maxZ)/wallGoal);
        double rear=rearClear?Math.min(1,rearRunway(x,z,tx,tz,minX,maxX,minZ,maxZ)/rearGoal):0;
        return walls+2*rear;
    }

    private static double inwardPush(double x,double z,double tx,double tz,double cx,double cz) {
        double px=tx-x,pz=tz-z,ix=cx-tx,iz=cz-tz;
        double norm=Math.hypot(px,pz)*Math.hypot(ix,iz);
        return norm>1e-8?(px*ix+pz*iz)/norm:0;
    }
}

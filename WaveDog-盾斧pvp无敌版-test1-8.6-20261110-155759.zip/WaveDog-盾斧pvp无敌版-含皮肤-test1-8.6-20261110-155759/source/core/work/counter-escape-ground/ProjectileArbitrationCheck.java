import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;

/** Exercise simultaneous threats against both packaged model controllers. */
public final class ProjectileArbitrationCheck {
    static int checks;static RestartCheck.Archive a;
    static void check(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}
    static Object call(Object o,String name,Class<?>[] types,Object...args)throws Exception{var m=o.getClass().getDeclaredMethod(name,types);m.setAccessible(true);return m.invoke(o,args);}
    static Object get(Object o,String name)throws Exception{var f=o.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(o);}
    static void set(Object o,String name,Object v)throws Exception{var f=o.getClass().getDeclaredField(name);f.setAccessible(true);f.set(o,v);}
    static boolean flag(Object o,String name)throws Exception{return (boolean)call(o,name,new Class<?>[]{});}
    static Object plan(boolean safe,boolean shieldSafe)throws Exception{
        boolean[] moves=new boolean[18],viable=new boolean[18];Arrays.fill(viable,true);moves[4]=safe;
        return a.make("ArrowDodgePlanner$Result",new Class<?>[]{boolean.class,double.class,double.class,int.class,boolean[].class,boolean[].class,boolean.class,boolean.class,int.class},
            true,3.,0.,4,moves,viable,shieldSafe,false,12);
    }
    public static void main(String[] args)throws Exception{
        a=new RestartCheck.Archive(Path.of(args[0]),null);
        for(int profile=0;profile<2;profile++)for(boolean shield:new boolean[]{false,true})
            for(boolean safe:new boolean[]{false,true})for(int conflict=0;conflict<8;conflict++) {
                var c=new RestartCheck.Controller(a,profile,123);var s=RestartCheck.senses(2.8);var v=RestartCheck.view(100,2.8,shield);
                s.put("ownShieldCooldown",shield?0.:80.);s.put("projectilePlan",plan(safe,false));
                if(conflict==1){s.put("opportunity","ENTRY");s.put("damageAge",0.);}
                if(conflict==2){s.put("opportunity","BREAK_COUNTER");s.put("lastBlockTick",100L);s.put("blockedMeleeAge",0.);}
                if(conflict==3){s.put("targetAirborne",true);s.put("targetY",.3);s.put("targetCritThreat",true);}
                if(conflict==4){set(c.controller,"orbitUntil",110L);set(c.controller,"phase",RestartCheck.enumValue(a.type("InitialCombatController$Phase"),"ORBIT_BURST"));}
                if(conflict==5){set(c.controller,"exitControl",true);s.put("retreatBlocked",true);s.put("damageAge",0.);s.put("targetAttackAge",0.);}
                if(conflict==6){set(c.controller,"exitControl",true);set(c.controller,"landingTradePending",true);call(c.controller,"opponentAttack",new Class<?>[]{long.class,boolean.class},100L,false);}
                if(conflict==7){call(c.controller,"confirmedCounterHop",new Class<?>[]{long.class},99L);s.put("counterAxeHitTick",99L);}
                c.step(v,s);Object frame=get(c.controller,"decision");
                if(shield||safe) {
                    check(c.phase().equals(shield?"ARROW_GUARD":"ARROW_DODGE"),"one defensive branch owns simultaneous conflict "+conflict+" profile="+profile);
                    check(flag(frame,"shield")==shield,"usable shield is never lowered to dodge, and broken shield is never requested");
                    check(!flag(frame,"attack")&&!flag(frame,"jump")&&!flag(frame,"faceAway"),"no counter/jump/escape overlay consumes this frame");
                    check((long)get(c.controller,"orbitUntil")==0,"orbit is interrupted immediately");
                }else check(!c.phase().equals("ARROW_DODGE"),"unavoidable projectile must not manufacture an ineffective dodge");
            }
        System.out.println("ProjectileArbitrationCheck: "+checks+" passed; both profiles, usable shield only guards, broken shield only dodges, eight simultaneous melee/jump/escape/orbit conflicts.");
    }
}

import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import java.util.function.BooleanSupplier;

/** Execute both packaged policies, native-input wrappers and same-call turn restoration. */
public final class HopWeaponCheck {
    static int checks; static RestartCheck.Archive archive;
    static void check(boolean yes,String why) {checks++;if(!yes)throw new AssertionError(why);}
    static Object call(Object o,String name,Class<?>[] types,Object...args)throws Exception {
        var m=o.getClass().getDeclaredMethod(name,types);m.setAccessible(true);return m.invoke(o,args);
    }
    static Object invoke(String type,String method,Class<?>[] types,Object...args)throws Exception {
        var m=archive.type(type).getDeclaredMethod(method,types);m.setAccessible(true);return m.invoke(null,args);
    }
    static Object field(Object o,String name)throws Exception {var f=o.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(o);}
    static boolean flag(Object o,String n)throws Exception{return (boolean)call(o,n,new Class<?>[]{});}
    static Object frame(RestartCheck.Controller c)throws Exception {return field(c.controller,"decision");}
    static String weapon(RestartCheck.Controller c)throws Exception{return call(frame(c),"weapon",new Class<?>[]{}).toString();}
    static Map<String,Object> senses(double reach,boolean ground,double y,boolean crit) {
        var s=RestartCheck.senses(reach);s.put("ownWeapon",1);s.put("escapeSword",false);
        s.put("counterAxeHitTick",100L);s.put("onGround",ground);s.put("ownY",y);
        s.put("ownShieldCooldown",80.);s.put("withdrawing",true);
        s.put("ownCriticalWindow",crit);s.put("ownCriticalReady",false);return s;
    }
    static Map<String,Object> view(long tick,double reach,float charge){var v=RestartCheck.view(tick,reach,false);v.put("ownAttackCharge",charge);return v;}
    static RestartCheck.Controller start(int profile)throws Exception {
        var c=new RestartCheck.Controller(archive,profile,66001);
        call(c.controller,"confirmedCounterHop",new Class<?>[]{long.class},100L);
        c.step(view(101,2.9,.1f),senses(2.9,true,0,false));
        check(weapon(c).equals("SWORD")&&flag(frame(c),"jump"),"confirmed escape starts with sword and sole jump");
        call(c.controller,"jumpInputSubmitted",new Class<?>[]{long.class},101L);return c;
    }
    static void melee(RestartCheck.Controller c,double before,double after,boolean alsoExit)throws Exception {
        call(c.controller,"beforeMelee",new Class<?>[]{double.class},before);
        call(c.controller,"nativeMeleeOutcome",new Class<?>[]{boolean.class,boolean.class},after>before,after>before&&c.phase().equals("HOP_CRIT"));
        call(c.controller,"meleeAttemptFinished",new Class<?>[]{long.class,double.class,boolean.class},104L,after,alsoExit);
    }
    static void flightAndSwitch(int profile)throws Exception {
        var c=start(profile);
        for(int tick=102;tick<=110;tick++) {
            c.step(view(tick,4,1f),senses(4,false,tick<106?.2:-.1,true));
            check(weapon(c).equals("SWORD")&&flag(c.controller,"keepEscapeSword"),"separation midair must never switch to axe");
            check(flag(frame(c),"sprint")&&flag(frame(c),"faceAway")&&!flag(frame(c),"attack")&&!flag(frame(c),"jump"),"outside reach: uninterrupted existing sprint hop, no turns or extra jump");
            Object axe=RestartCheck.enumValue(archive.type("Weapon"),"AXE");
            check(invoke("CombatInputHooks","escapeWeapon",new Class<?>[]{archive.type("Weapon"),archive.type("InitialCombatController")},axe,c.controller).toString().equals("SWORD"),"native weapon gate retains sword despite old restore requests");
            Object seq=archive.make("MeleeSequence",new Class<?>[]{});
            invoke("CombatInputHooks","escapeSword",new Class<?>[]{archive.type("MeleeSequence"),boolean.class,archive.type("InitialCombatController")},seq,false,c.controller);
            check(flag(seq,"escapeSword"),"old memory-clear path must not erase active sword latch");
        }
        c.step(view(111,4,1f),senses(4,true,0,false));
        check(!flag(c.controller,"keepEscapeSword")&&flag(c.controller,"needsAxeSwitch"),"only landed AND separated requests axe");
        check(c.phase().equals("PRESSURE_RECHARGE")&&!flag(frame(c),"attack")&&!flag(frame(c),"jump"),"stale full sword charge cannot turn into immediate axe attack");
        c.step(view(112,4,1f),senses(4,true,0,false));
        check(flag(c.controller,"pressureRecovering"),"must wait until actual axe equip, not stale full sword charge");
        call(c.controller,"axeEquipped",new Class<?>[]{long.class},112L);
        var low=senses(4,true,0,false);low.put("ownWeapon",0);
        c.step(view(113,4,.15f),low);
        check(c.phase().equals("PRESSURE_RECHARGE")&&flag(frame(c),"faceAway"),"new axe first recharges away from a distant opponent");
        c.step(view(114,4,1f),low);
        check(!flag(c.controller,"pressureRecovering")&&c.phase().equals("RANGE_CONTROL"),"actual full axe charge returns ground control");
        var close=start(profile);close.step(view(102,2.8,1f),senses(2.8,false,.2,false));
        close.step(view(103,2.8,1f),senses(2.8,true,0,false));
        check(flag(close.controller,"keepEscapeSword")&&!flag(close.controller,"needsAxeSwitch"),"landing alone cannot release sword while still in reach");
        check(!flag(frame(close),"jump"),"failed separation must not schedule a second fixed hop");
    }
    static void criticalWindows(int profile)throws Exception {
        for(String situation:List.of("VALID","ASCENDING","NATIVE_ONLY","OBSERVED_LAG","UNKNOWN","NOT_NATIVE","LOW_CHARGE","OUTSIDE","STALE","BLOCKED","EFFECTIVE_SHIELD")) {
            var c=start(profile);double reach=situation.equals("OUTSIDE")?3.01:2.9;
            float nativeCharge=situation.equals("UNKNOWN")?Float.NaN:situation.equals("LOW_CHARGE")?.84f:.92f;
            call(c.controller,"hopCriticalObservation",new Class<?>[]{float.class,double.class},nativeCharge,situation.equals("ASCENDING")?.12:-.08);
            var s=senses(reach,false,situation.equals("OBSERVED_LAG")?.04:-.08,!situation.equals("NOT_NATIVE")&&!situation.equals("LOW_CHARGE"));
            if(situation.equals("STALE"))s.put("estimateAge",2.);
            var v=view(104,reach,situation.equals("NATIVE_ONLY")?.88f:situation.equals("LOW_CHARGE")?.8f:.95f);
            if(situation.equals("BLOCKED"))v.put("visible",false);
            if(situation.equals("EFFECTIVE_SHIELD"))call(c.controller,"tradeObservation",new Class<?>[]{archive.type("TradeJump$Plan"),long.class,boolean.class,boolean.class},null,-1000L,false,true);
            c.step(v,s);boolean valid=List.of("VALID","NATIVE_ONLY","OBSERVED_LAG").contains(situation);
            check(c.phase().equals("HOP_CRIT")==valid,"only native early-descending, reachable, fresh, sufficiently charged sword critical: "+situation+"/"+c.phase());
            check(!flag(frame(c),"jump"),"critical fallback must not add a jump");
            if(situation.equals("EFFECTIVE_SHIELD")) {
                call(c.controller,"tradeObservation",new Class<?>[]{archive.type("TradeJump$Plan"),long.class,boolean.class,boolean.class},null,-1000L,false,false);
                c.step(view(105,reach,.95f),s);
                check(c.phase().equals("HOP_CRIT"),"effective shield delays instead of consuming the same flight's critical opportunity");
            }
            if(valid) {
                check(weapon(c).equals("SWORD")&&flag(frame(c),"attack")&&!flag(frame(c),"sprint"),"native critical cancels sprint only for the attack");
                check((boolean)call(c.controller,"hopCriticalCharge",new Class<?>[]{float.class},.95f),"native critical need not wait for artificial full-charge gate");
                melee(c,10,12,false);
                check(!(boolean)field(c.controller,"hopFinishPending"),"close critical is defensive, not automatically a decisive exit");
                c.step(view(105,2.9,1f),s);
                check(!c.phase().equals("HOP_CRIT")&&flag(frame(c),"faceAway"),"one submitted critical then immediately resume original flight");
            }
        }
    }
    static void exitTiming(int profile)throws Exception {
        for(boolean damage:new boolean[]{false,true}) {
            var c=start(profile);var s=senses(2.95,false,-.08,true);s.put("opportunity","EXIT");
            call(c.controller,"hopCriticalObservation",new Class<?>[]{float.class,double.class},.92f,-.08);
            c.step(view(104,2.95,.95f),s);check(c.phase().equals("HOP_CRIT"),"exiting at a valid critical height may combine both actions");
            melee(c,10,damage?12:10,false);
            check((boolean)field(c.controller,"hopFinishPending")==damage,"blocked or missed exit cannot claim successful final damage");
            c.step(view(105,2.95,.1f),senses(2.95,false,-.12,false));
            check(flag(frame(c),"faceAway")&&flag(frame(c),"sprint")&&flag(c.controller,"counterHopActive"),"final blow restores this same flight until physical landing");
            c.step(view(106,4,.1f),senses(4,false,-.17,false));
            check(!flag(frame(c),"attack")&&weapon(c).equals("SWORD"),"after crossing, no extra turn and no midair axe switch");
        }
        for(String opportunity:List.of("EXIT","COUNTER_FOLLOW")) {
            var c=start(profile);var s=senses(2.9,false,-.08,true);s.put("opportunity",opportunity);
            call(c.controller,"hopCriticalObservation",new Class<?>[]{float.class,double.class},.92f,-.08);
            c.step(view(111,2.9,.88f),s);
            Object none=RestartCheck.enumValue(archive.type("OpportunityStrike$Kind"),"NONE");
            Object selected=call(c.controller,"criticalOpportunity",new Class<?>[]{archive.type("OpportunityStrike$Kind")},none);
            check(c.phase().equals("HOP_CRIT")&&selected.toString().equals(opportunity.equals("EXIT")?"EXIT":"NONE"),"critical retains final EXIT claim; obsolete timed follow cannot be scheduled again");
            melee(c,10,12,true);
            check((boolean)field(c.controller,"hopFinishPending"),"a real critical also at departure is accepted as the final blow");
        }
    }
    static void wallReply(int profile)throws Exception {
        var c=start(profile);var s=senses(2.9,false,-.1,false);
        s.put("retreatBlocked",true);s.put("wallEscapeAvailable",false);s.put("damageAge",0.);s.put("targetAttackAge",0.);
        c.step(view(104,2.9,.1f),s);
        check(c.phase().equals("WALL_TRADE")&&flag(frame(c),"attack"),"wall-blocked escape replies to actual close damage without waiting for full charge");
        check(flag(c.controller,"wallDamageReply"),"native low-charge permission remains active until attack submission");
        call(c.controller,"beforeMelee",new Class<?>[]{double.class},10.);
        check(flag(c.controller,"wallDamageReply"),"native pre-attack callback retains wall-reply permission during synchronous attack event");
        call(c.controller,"meleeAttemptFinished",new Class<?>[]{long.class,double.class,boolean.class},104L,10.,false);
        check(!flag(c.controller,"wallDamageReply"),"one actual submission consumes this wound response");
        s.put("damageAge",1.);s.put("targetAttackAge",1.);c.step(view(105,2.9,.1f),s);
        check(!c.phase().equals("WALL_TRADE"),"one hurt event cannot create repeated response clicks");
        s.put("damageAge",0.);s.put("targetAttackAge",0.);c.step(view(106,2.9,.1f),s);
        check(c.phase().equals("WALL_TRADE"),"a second real wound permits a second legal reply");
        c=start(profile);s=senses(3.01,false,-.1,false);s.put("retreatBlocked",true);s.put("damageAge",0.);s.put("targetAttackAge",0.);
        c.step(view(104,3.01,.1f),s);check(!c.phase().equals("WALL_TRADE"),"wall retaliation never fabricates remote melee damage");
    }
    static void closeRecharge(int profile)throws Exception {
        var c=start(profile);c.step(view(102,4,1f),senses(4,false,.2,false));
        c.step(view(103,4,1f),senses(4,true,0,false));call(c.controller,"axeEquipped",new Class<?>[]{long.class},103L);
        var s=senses(3.3,true,0,false);s.put("ownWeapon",0);
        c.step(view(104,3.3,.1f),s);
        check(c.phase().equals("RECHARGE_APPROACH")&&!flag(frame(c),"attack"),"0.3-block outer window allows short approach, never remote damage");
        s=senses(2.95,true,0,false);s.put("ownWeapon",0);
        c.step(view(105,2.95,.1f),s);
        check(c.phase().equals("RECHARGE_REPLY")&&flag(frame(c),"attack"),"too-close opponent permits low-charge reply even without stale ENTRY hint");
        check(flag(c.controller,"closeRechargeReply"),"low-charge permission remains valid through synchronous native attack event");
        melee(c,10,10,false);
        check(!flag(c.controller,"closeRechargeReply"),"one actual submission consumes reply, even a miss");
        c.step(view(106,2.95,.1f),s);
        check(c.phase().equals("PRESSURE_RECHARGE")&&!flag(frame(c),"attack"),"no meaningless repeated low-charge clicks");
        var far=senses(4,true,0,false);far.put("ownWeapon",0);
        c.step(view(107,4,.2f),far);
        c.step(view(108,2.95,.2f),s);
        check(c.phase().equals("RECHARGE_REPLY")&&flag(frame(c),"attack"),"a real separation then new approach re-arms close reply before full charge");
    }
    static void instantRestore()throws Exception {
        Class<?> inputs=archive.type("InstantTurnStrike$Inputs");
        for(boolean critical:new boolean[]{false,true})for(boolean legal:new boolean[]{false,true}) {
            var events=new ArrayList<String>();
            Object proxy=Proxy.newProxyInstance(archive,new Class<?>[]{inputs},(o,m,args)->{
                events.add(m.getName());
                if(m.getName().equals("attackNormally")&&critical)
                    return invoke("VanillaCriticalInput","execute",new Class<?>[]{BooleanSupplier.class,Runnable.class,BooleanSupplier.class,BooleanSupplier.class},
                        (BooleanSupplier)()->true,(Runnable)()->events.add("cancelSprint"),(BooleanSupplier)()->true,(BooleanSupplier)()->{events.add("nativeAttack");return true;});
                return switch(m.getName()){case "readyBeforeTurn","attackNormally"->true;case "legalNow"->legal;default->null;};
            });
            invoke("InstantTurnStrike","execute",new Class<?>[]{inputs},proxy);
            check(events.getLast().equals("resumeEscape"),"same-call finally restores retreat even when legality fails");
            check(Collections.frequency(events,"resumeEscape")==1,"one immediate restore, no queued future frame");
            if(critical&&legal)check(events.indexOf("cancelSprint")<events.indexOf("nativeAttack")&&events.indexOf("nativeAttack")<events.indexOf("resumeEscape"),"critical's native sprint cancel is followed by same-call retreat restore");
        }
        archive.type("PvPArenaAI$1").getDeclaredMethods();check(true,"patched instant-turn class verifies against real Paper API");
    }
    public static void main(String[] args)throws Exception {
        archive=new RestartCheck.Archive(Path.of(args[0]),null);
        for(int p=0;p<2;p++){flightAndSwitch(p);criticalWindows(p);exitTiming(p);wallReply(p);closeRecharge(p);}instantRestore();
        System.out.println("HopWeaponCheck: "+checks+" assertions passed; both policies: sword entire flight, early native descending critical, final-exit distinction, immediate same-call restore, actual axe equip/recharge and 0.3-block close reply. No server/model writes.");
    }
}

import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;

/** Real packaged model selection, mutable instance policy binding and the Paper KB test filter. */
public final class ExtraMechanicsCheck {
    static int checks;
    static void check(boolean b,String why){checks++;if(!b)throw new AssertionError(why);}
    static Object call(Class<?> type,String method,Class<?>[] types,Object...args)throws Exception {
        var m=type.getDeclaredMethod(method,types);m.setAccessible(true);return m.invoke(null,args);
    }
    public static void main(String[] args)throws Exception {
        var archive=new RestartCheck.Archive(Path.of(args[0]),null);Class<?> models=archive.type("DuelModels");
        for(String id:List.of("test1","test2","uhc1","uhc2")) {
            check(call(models,"profile",new Class<?>[]{String.class},id.toUpperCase(Locale.ROOT)).equals(id),"four explicit profiles parse case-insensitively");
        }
        for(String invalid:List.of("","WaveJerry","WaveDog","test3","uhc"))check(call(models,"profile",new Class<?>[]{String.class},invalid)==null,"player/entity/unknown names cannot silently select a model");
        Class<?> brain=archive.loadClass("local.pvpbot.ai.PvPArenaAI$Brain"),policy=archive.type("CombatPolicy");
        var ctor=brain.getDeclaredConstructor(String.class,policy);ctor.setAccessible(true);
        Object first=archive.make("test1",new Class<?>[]{}),second=archive.make("test2",new Class<?>[]{}),instance=ctor.newInstance("WaveDog",first);
        call(models,"write",new Class<?>[]{Object.class,String.class,Object.class},instance,"policy",second);
        var f=brain.getDeclaredField("policy");f.setAccessible(true);check(f.get(instance)==second,"actual Java 21 instance field switches to selected policy");
        var name=brain.getDeclaredField("name");name.setAccessible(true);check(name.get(instance).equals("WaveDog"),"selecting test2 does not rename/spawn WaveDog2");
        var tools=new RestartCheck.Archive(Path.of(args[1]),null);Class<?> plugin=tools.loadClass("local.wavedog.testtools.KnockbackTestPlugin"),vector=Class.forName("org.bukkit.util.Vector");
        var create=vector.getConstructor(double.class,double.class,double.class);var y=vector.getMethod("getY");var x=vector.getMethod("getX");var z=vector.getMethod("getZ");
        for(int i=0;i<64;i++)for(boolean enabled:new boolean[]{false,true})for(boolean groundOnly:new boolean[]{false,true})for(boolean grounded:new boolean[]{false,true}) {
            double vx=(i-32)*.04,vy=(i-16)*.03,vz=(48-i)*.02;Object impulse=create.newInstance(vx,vy,vz);
            Object result=call(plugin,"filtered",new Class<?>[]{vector,boolean.class,boolean.class,boolean.class},impulse,enabled,groundOnly,grounded);
            boolean filtered=enabled&&(!groundOnly||grounded);
            check((double)x.invoke(result)==(filtered?0:vx)&&(double)z.invoke(result)==(filtered?0:vz),"ground/all/off filter matches horizontal stress-test mode");
            check((double)y.invoke(result)==vy,"vertical impulse is always native and unchanged");
            check((double)x.invoke(impulse)==vx&&(double)z.invoke(impulse)==vz,"test filter never mutates input vector or existing velocity");
        }
        plugin.getDeclaredMethod("knockback",Class.forName("io.papermc.paper.event.entity.EntityKnockbackEvent"));check(true,"KB listener resolves actual 1.21.1 Paper delta-impulse event");
        var health=new RestartCheck.Archive(Path.of(args[2]),null);Class<?> heads=health.loadClass("local.wavedog.health.HeadHeartsPlugin");
        Object full=call(heads,"hearts",new Class<?>[]{double.class,double.class,double.class},20.,20.,0.);
        Object half=call(heads,"hearts",new Class<?>[]{double.class,double.class,double.class},19.,20.,0.);
        Object golden=call(heads,"hearts",new Class<?>[]{double.class,double.class,double.class},20.,20.,4.);
        Class<?> component=Class.forName("net.kyori.adventure.text.Component");
        var children=component.getMethod("children");
        check(((List<?>)children.invoke(full)).size()==10,"normal 20-health player has ten head hearts");
        check(!full.equals(half),"real half health remains visibly distinguishable from full health");
        check(((List<?>)children.invoke(golden)).size()==12,"golden-apple absorption adds two separate golden hearts");
        var numbers=Class.forName("io.papermc.paper.scoreboard.numbers.NumberFormat");
        check(numbers.getMethod("fixed",Class.forName("net.kyori.adventure.text.ComponentLike")).invoke(null,half)!=null,"real Paper 1.21.1 nameplate number format accepts the generated heart component");
        Class.forName("org.bukkit.scoreboard.Score").getMethod("numberFormat",numbers);
        Class.forName("org.bukkit.scoreboard.Score").getMethod("resetScore");
        check(true,"installed API has per-entry format and scoped score reset; no scoreboard replacement needed");
        System.out.println("ExtraMechanicsCheck: "+checks+" passed; four profile identifiers, real WaveDog policy field, and ground/all/off horizontal test preserving vertical impulse. No server/model writes.");
    }
}

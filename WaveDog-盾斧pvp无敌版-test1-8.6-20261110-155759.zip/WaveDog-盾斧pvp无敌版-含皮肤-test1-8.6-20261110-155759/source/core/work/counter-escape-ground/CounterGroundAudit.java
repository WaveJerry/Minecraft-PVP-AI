import java.nio.file.*;import java.util.*;import java.util.zip.*;
import org.objectweb.asm.*;import org.objectweb.asm.tree.*;

/** Audit unchanged source-of-truth physics, reach, damage, lifecycle and player commands. */
public final class CounterGroundAudit {
    static final String MAIN="local/pvpbot/ai/PvPArenaAI";
    static ClassNode node(ZipFile z)throws Exception {var n=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(MAIN+".class")).readAllBytes()).accept(n,0);return n;}
    static byte[] method(ClassNode c,MethodNode m) {var w=new ClassWriter(0);w.visit(c.version,c.access,c.name,c.signature,c.superName,null);m.accept(w);w.visitEnd();return w.toByteArray();}
    static void check(boolean ok,String why){if(!ok)throw new AssertionError(why);}
    public static void main(String[] args)throws Exception {
        var allowed=Set.of("local/pvpbot/ai/ConstrainedTactics.class","local/pvpbot/ai/ConstrainedTactics$Sample.class",
            "local/pvpbot/ai/InitialCombatController.class","local/pvpbot/ai/InitialCombatController$Phase.class",
            MAIN+".class",MAIN+"$1.class","local/pvpbot/ai/GroundFootwork.class","local/pvpbot/ai/DuelPlayerCommands.class");
        var hooked=Set.of("meleeInput","executeCombatFrame","precisionFootwork","resumeRetreatInputs","tickBrain","observe","selectWeapon","onAttackInput","restoreLayout","captureLayout","opportunityWindow","ambientArrowDefence");
        int exactClasses=0,exactMethods=0,changed=0;
        try(var old=new ZipFile(args[0]);var revised=new ZipFile(args[1])) {
            for(var es=old.entries();es.hasMoreElements();) {
                var e=es.nextElement();if(!e.getName().endsWith(".class"))continue;
                if(Arrays.equals(old.getInputStream(e).readAllBytes(),revised.getInputStream(revised.getEntry(e.getName())).readAllBytes()))exactClasses++;
                else check(allowed.contains(e.getName()),"Unapproved class mutation: "+e.getName());
            }
            var a=node(old);var b=node(revised);check(a.methods.size()==b.methods.size(),"Main methods added/deleted");
            for(var m:a.methods) {
                var r=b.methods.stream().filter(x->x.name.equals(m.name)&&x.desc.equals(m.desc)).findFirst().orElseThrow();
                if(Arrays.equals(method(a,m),method(b,r)))exactMethods++;
                else {check(hooked.contains(m.name),"Native/unrelated method changed: "+m.name);changed++;}
            }
            check(changed==12,"Twelve input/observation hooks including shared ambient defence expected, got "+changed);
            var ta=new ClassNode();var tb=new ClassNode();
            new ClassReader(old.getInputStream(old.getEntry(MAIN+"$1.class")).readAllBytes()).accept(ta,0);
            new ClassReader(revised.getInputStream(revised.getEntry(MAIN+"$1.class")).readAllBytes()).accept(tb,0);
            for(var m:ta.methods) {
                var r=tb.methods.stream().filter(x->x.name.equals(m.name)&&x.desc.equals(m.desc)).findFirst().orElseThrow();
                check(m.name.equals("readyBeforeTurn")||Arrays.equals(method(ta,m),method(tb,r)),"Unrelated instant-turn method changed: "+m.name);
            }
            for(String file:List.of("MeleeReach","OpportunityStrike","CounterFollow","NeuralLearner","AirborneEnvelope","JumpThreatSpacing"))
                check(Arrays.equals(old.getInputStream(old.getEntry("local/pvpbot/ai/"+file+".class")).readAllBytes(),
                    revised.getInputStream(revised.getEntry("local/pvpbot/ai/"+file+".class")).readAllBytes()),file+" must remain byte-identical");
            var ranged=new ClassNode();new ClassReader(revised.getInputStream(revised.getEntry("local/pvpbot/ai/OffhandRangedSupport.class")).readAllBytes()).accept(ranged,0);
            var shot=ranged.methods.stream().filter(m->m.name.equals("shot")).findFirst().orElseThrow();
            boolean defended=false,ammoChecked=false;
            for(var insn:shot.instructions)if(insn instanceof MethodInsnNode call) {
                if(call.name.equals("defend"))defended=true;
                if(call.name.equals("ammo")){check(defended,"Empty ammunition must never skip projectile defence");ammoChecked=true;}
            }
            check(defended&&ammoChecked,"Shot callback must evaluate defence before reciprocal-shot ammunition");
            var defend=ranged.methods.stream().filter(m->m.name.equals("defend")).findFirst().orElseThrow();
            boolean exactInput=false;
            for(var insn:defend.instructions)if(insn instanceof LdcInsnNode value&&value.cst instanceof String name) {
                check(!name.equals("ambientMove"),"Dodge cannot rotate into an unverified wandering direction");
                if(name.equals("applyMovementInput"))exactInput=true;
            }
            check(exactInput,"Defence must execute the actual simulated movement input");
            var execute=ranged.methods.stream().filter(m->m.name.equals("execute")).findFirst().orElseThrow();
            boolean defenceFirst=false;
            for(var insn:execute.instructions)if(insn instanceof MethodInsnNode call) {
                if(call.name.equals("defend"))defenceFirst=true;
                if(call.owner.equals("local/pvpbot/ai/OffhandRangedSupport")&&(call.name.equals("verifyTargetLoad")||call.name.equals("finishLoad")||call.name.equals("begin")))
                    check(defenceFirst,"Actual defence must arbitrate before load/fire inputs");
            }
        }
        System.out.println("PASS: "+exactClasses+" original classes byte-identical; "+exactMethods+" main methods exact; twelve input/observation hooks; native reach/damage/physics and countdown unchanged; shared duel/ambient projectile arbitration verified");
    }
}

import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

/** Execute the packaged post-hop exchange and real completion state machines. */
public final class ExchangeRepairCheck {
    static RestartCheck.Archive a;static int checks;
    static void check(boolean x,String why){checks++;if(!x)throw new AssertionError(why);}
    static Object call(Object o,String n,Class<?>[] t,Object...v)throws Exception{var m=o.getClass().getDeclaredMethod(n,t);m.setAccessible(true);return m.invoke(o,v);}
    static Object invoke(String type,String n,Class<?>[] t,Object...v)throws Exception{var m=a.type(type).getDeclaredMethod(n,t);m.setAccessible(true);return m.invoke(null,v);}
    static void set(Object o,String n,Object v)throws Exception{var f=o.getClass().getDeclaredField(n);f.setAccessible(true);f.set(o,v);}
    static Object get(Object o,String n)throws Exception{var f=o.getClass().getDeclaredField(n);f.setAccessible(true);return f.get(o);}
    static boolean flag(Object o,String n)throws Exception{return (boolean)call(o,n,new Class<?>[]{});}
    static Object frame(RestartCheck.Controller c)throws Exception{return get(c.controller,"decision");}
    static Map<String,Object> s(double reach,boolean ground,int weapon){var s=RestartCheck.senses(reach);s.put("onGround",ground);s.put("ownWeapon",weapon);s.put("ownShieldCooldown",80.);s.put("counterAxeHitTick",100L);return s;}
    static Map<String,Object> v(long tick,double reach,boolean shield){var v=RestartCheck.view(tick,reach,shield);v.put("ownAttackCharge",1f);return v;}
    static RestartCheck.Controller land(int p,double reach)throws Exception{
        var c=new RestartCheck.Controller(a,p,123);
        call(c.controller,"confirmedCounterHop",new Class<?>[]{long.class},100L);
        c.step(v(101,2.8,false),s(2.8,true,1));
        call(c.controller,"jumpInputSubmitted",new Class<?>[]{long.class},101L);
        c.step(v(102,2.8,false),s(2.8,false,1));
        c.step(v(113,reach,false),s(reach,true,1));return c;
    }
    static void outcome(RestartCheck.Controller c,long tick,boolean damage,boolean crit)throws Exception{
        call(c.controller,"beforeMelee",new Class<?>[]{double.class},0.);
        call(c.controller,"nativeMeleeOutcome",new Class<?>[]{boolean.class,boolean.class},damage,crit);
        call(c.controller,"meleeAttemptFinished",new Class<?>[]{long.class,double.class,boolean.class},tick,damage?1.:0.,false);
    }
    static void gatesAndLoop(int p)throws Exception{
        for(double reach:new double[]{2.5,2.8,3.,3.000001,4.}) {
            var c=land(p,reach);
            check(flag(c.controller,"landingTradePending")== (reach<=3),"only the physically ended hop's live 3-block contact arms exchange: "+reach);
            check(!flag(frame(c),"attack"),"landing without an opponent attack cannot create a swing");
        }
        var ordinary=new RestartCheck.Controller(a,p,12);set(ordinary.controller,"exitControl",true);
        ordinary.step(v(200,2.8,false),s(2.8,true,0));
        check(!flag(ordinary.controller,"landingTradePending"),"unrelated ordinary control never arms this exchange");
        var c=land(p,2.8);
        check(c.phase().equals("TRADE_WAIT"),"close post-hop landing waits in exchange, not shield spam");
        call(c.controller,"opponentAttack",new Class<?>[]{long.class,boolean.class},114L,false);
        c.step(v(114,2.8,false),s(2.8,true,1));
        check(c.phase().equals("CONTACT_REPLY")&&flag(frame(c),"attack")&&flag(frame(c),"sprint"),"plain attack is mirrored by a native sprint knockback input");
        outcome(c,114,true,false);
        check(flag(c.controller,"counterHopActive")&&flag(c.controller,"consumeTradeHopRestart"),"confirmed plain exchange arms the next ordinary counter-style hop");
        call(c.controller,"jumpInputSubmitted",new Class<?>[]{long.class},115L);
        c.step(v(116,2.8,false),s(2.8,false,1));c.step(v(127,2.8,false),s(2.8,true,1));
        check(flag(c.controller,"landingTradePending"),"a jump-reset pursuer still close on the next landing repeats the same exchange loop");
        c.step(v(128,3.01,false),s(3.01,true,1));
        check(!flag(c.controller,"landingTradePending"),"actual separation terminates exchange without another revenge swing");
    }
    static RestartCheck.Controller airborne(int p)throws Exception{
        var c=land(p,2.8);
        Object plan=a.make("TradeJump$Plan",new Class<?>[]{double.class,double.class,int.class,double.class,boolean.class},-1.,0.,7,3.4,true);
        check((boolean)call(c.controller,"synchronizeTrade",new Class<?>[]{a.type("TradeJump$Plan"),long.class},plan,114L),"only the armed close post-hop state starts synchronized jump");
        call(c.controller,"jumpInputSubmitted",new Class<?>[]{long.class},114L);return c;
    }
    static Map<String,Object> fall(){var s=s(2.8,false,1);s.put("ownCriticalWindow",true);s.put("ownY",-.1);s.put("targetAirborne",true);s.put("targetY",-.1);s.put("targetCritThreat",true);return s;}
    static void syncAndCompletion(int p)throws Exception{
        for(boolean blocked:new boolean[]{false,true}) {
            var c=airborne(p);var s=fall();
            call(c.controller,"hopCriticalObservation",new Class<?>[]{float.class,double.class},.95f,-.1);
            call(c.controller,"tradeObservation",new Class<?>[]{a.type("TradeJump$Plan"),long.class,boolean.class,boolean.class},null,-1000L,true,blocked);
            c.step(v(119,2.8,false),s);
            check(!flag(frame(c),"attack"),"own critical window alone never creates an unsynchronized first critical");
            call(c.controller,"opponentAttack",new Class<?>[]{long.class,boolean.class},120L,true);
            c.step(v(120,2.8,false),s);
            check(flag(frame(c),"attack")==!blocked,"mirror critical only through a real opening");
            if(!blocked) {
                check(c.phase().equals("TRADE_CRIT")&&!flag(frame(c),"sprint"),"synchronized critical explicitly cancels sprint");
                outcome(c,120,false,false);
                check(get(c.controller,"activeTrade")!=null,"rejected/missed critical must not end the exchange");
                outcome(c,120,true,false);
                check(get(c.controller,"activeTrade")!=null,"ordinary damage cannot masquerade as confirmed critical");
                outcome(c,120,true,true);
                check(get(c.controller,"activeTrade")==null&&!flag(c.controller,"landingTradePending"),"real native critical ends the single exchange");
            }
        }
        var plain=airborne(p);var s=fall();
        call(plain.controller,"opponentAttack",new Class<?>[]{long.class,boolean.class},120L,false);
        plain.step(v(120,2.8,false),s);
        check(plain.phase().equals("CONTACT_REPLY")&&flag(frame(plain),"sprint"),"airborne plain is mirrored as plain rather than converted to critical");
        var held=airborne(p);call(held.controller,"tradeObservation",new Class<?>[]{a.type("TradeJump$Plan"),long.class,boolean.class,boolean.class},null,-1000L,true,true);
        held.step(v(119,2.8,false),fall());
        var heldS=s(2.8,true,1);heldS.put("targetShieldRaised",true);heldS.put("targetFacingDot",1.);
        var heldV=v(127,2.8,false);heldV.put("targetBlocking",true);held.step(heldV,heldS);
        check(get(held.controller,"activeTrade")==null&&!flag(frame(held),"attack"),"landing behind an effective shield ends exchange without axe spam");
    }
    static void shieldGrace(int p)throws Exception{
        var c=land(p,2.8);
        for(long tick=114;tick<120;tick++) {
            var s=s(2.8,true,1);s.put("ownShieldCooldown",0.);
            c.step(v(tick,2.8,true),s);
            check(flag(c.controller,"exchangeShieldGrace")&&flag(frame(c),"shield"),"shield recovery defaults to guard for exactly six ticks: "+tick);
        }
        var s=s(2.8,true,1);s.put("ownShieldCooldown",0.);c.step(v(120,2.8,true),s);
        check(!flag(c.controller,"exchangeShieldGrace")&&!flag(c.controller,"landingTradePending"),"0.3 seconds expires once and returns to ordinary guarded policy");
    }
    static void criticalState()throws Exception{
        Class<?>[] t={float.class,float.class,double.class,boolean.class,boolean.class,boolean.class,boolean.class,boolean.class,boolean.class,boolean.class};
        for(int bits=0;bits<128;bits++) {
            Object snap=a.make("NativeCriticalState$Snapshot",t,.95f,.2f,-.1,(bits&1)!=0,(bits&2)!=0,(bits&4)!=0,(bits&8)!=0,(bits&16)!=0,(bits&32)!=0,(bits&64)!=0);
            check(flag(snap,"afterSprintRelease")==((bits&~32)==0),"1.21.1 native environment prerequisites: "+bits);
            check(flag(snap,"now")==(bits==0),"current sprint prohibits native critical: "+bits);
        }
        for(float charge:new float[]{.8f,.9f,.90001f,1f,Float.NaN}) {
            Object snap=a.make("NativeCriticalState$Snapshot",t,charge,.2f,-.1,false,false,false,false,false,false,false);
            check(flag(snap,"now")== (Float.isFinite(charge)&&charge>.9f),"strict actual 0.5-tick critical threshold");
        }
    }
    static void loadSession()throws Exception{
        for(boolean loaded:new boolean[]{false,true})for(int held:new int[]{0,24,25}) {
            Object session=a.make("CrossbowLoadSession",new Class<?>[]{});call(session,"start",new Class<?>[]{int.class},3);
            call(session,"released",new Class<?>[]{boolean.class,int.class,int.class,long.class,int.class},loaded,held,25,100L,2);
            check(flag(session,"finishing")==loaded,"only actual target charged metadata finishes target synchronization");
            if(!loaded&&held<25)check(!flag(session,"active"),"actual early unloaded release cancels");
            if(!loaded&&held==25) {
                check(flag(session,"verifying"),"full-duration release waits for metadata instead of declaring loaded");
                call(session,"observe",new Class<?>[]{boolean.class,boolean.class,long.class,int.class},true,false,101L,2);
                check(flag(session,"finishing"),"next-tick true native charged result completes target load");
            }
        }
    }
    static void queuedUse()throws Exception{
        Class<?> ticker=Class.forName("io.github.hello09x.fakeplayer.v1_21.spi.ActionTickerImpl");
        Class<?> base=ticker.getSuperclass(),action=Class.forName("io.github.hello09x.fakeplayer.api.spi.Action");
        Class<?> setting=Class.forName("io.github.hello09x.fakeplayer.api.spi.ActionSetting"),type=Class.forName("io.github.hello09x.fakeplayer.api.spi.ActionType");
        Class<?> unsafe=Class.forName("sun.misc.Unsafe");var uf=unsafe.getDeclaredField("theUnsafe");uf.setAccessible(true);
        Object old=unsafe.getMethod("allocateInstance",Class.class).invoke(uf.get(null),ticker);
        boolean[] using={true};
        Object stopAction=Proxy.newProxyInstance(action.getClassLoader(),new Class<?>[]{action},(o,m,v)->{
            if(m.getName().equals("stop"))using[0]=false;return m.getReturnType()==boolean.class?true:null;
        });
        var af=base.getDeclaredField("action");af.setAccessible(true);af.set(old,stopAction);
        var sf=base.getDeclaredField("setting");sf.setAccessible(true);sf.set(old,setting.getMethod("stop").invoke(null));
        old.getClass().getMethod("tick").invoke(old);
        check(!using[0],"the real fakeplayer STOP ticker reproduces cancellation of a newly started use");
        using[0]=true;UUID id=UUID.randomUUID();Map<Object,Object> inputs=new HashMap<>();
        Object use=type.getField("USE").get(null),jump=type.getField("JUMP").get(null);inputs.put(use,old);inputs.put(jump,new Object());
        Map<UUID,Map<Object,Object>> queues=Map.of(id,inputs);
        invoke("NativeUseSession","detach",new Class<?>[]{Map.class,UUID.class},queues,id);
        check(!inputs.containsKey(use)&&inputs.containsKey(jump)&&using[0],"draining old USE preserves unrelated JUMP and cannot stop the new draw/load");
    }
    public static void main(String[] args)throws Exception{
        a=new RestartCheck.Archive(Path.of(args[0]),null);
        try(var z=new ZipFile(args[0])){check(z.getEntry("local/pvpbot/ai/ShieldStun.class")==null,"double-hit implementation is absent from the artifact");}
        criticalState();loadSession();queuedUse();for(int p=0;p<2;p++){gatesAndLoop(p);syncAndCompletion(p);shieldGrace(p);}
        System.out.println("ExchangeRepairCheck: "+checks+" passed; post-hop-only 3-block loop, mirrored attack type, actual native critical receipt, six-tick shield recovery and true charged metadata.");
    }
}

import java.nio.file.*;import java.util.*;
import org.objectweb.asm.*;import org.objectweb.asm.tree.*;

/** Minimal facade over the already-validated ground.4 archive. */
public final class PerfectEditionPatch {
    static final String P="local/pvpbot/ai/",MAIN=P+"PvPArenaAI",SUPPORT=P+"PerfectEditionSupport";
    public static void main(String[] args)throws Exception {
        var n=new ClassNode();new ClassReader(Files.readAllBytes(Path.of(args[0]))).accept(n,0);
        int owners=0,commands=0;
        for(var m:n.methods) {
            for(var i:m.instructions.toArray())if(i instanceof LdcInsnNode literal && "WaveJerry".equals(literal.cst)) {
                if((m.access&Opcodes.ACC_STATIC)!=0)throw new IllegalStateException("Static owner access requires review: "+m.name);
                m.instructions.insertBefore(i,new VarInsnNode(Opcodes.ALOAD,0));
                m.instructions.set(i,new MethodInsnNode(Opcodes.INVOKESTATIC,SUPPORT,"owner","(Lorg/bukkit/plugin/java/JavaPlugin;)Ljava/lang/String;",false));owners++;
            }
            if(m.name.equals("onCommand")){m.name="editionBaseCommand";commands++;}
        }
        if(owners<1 || commands!=1)throw new IllegalStateException("Unexpected entry layout: "+owners+"/"+commands);
        String desc="(Lorg/bukkit/command/CommandSender;Lorg/bukkit/command/Command;Ljava/lang/String;[Ljava/lang/String;)Z";
        var m=new MethodNode(Opcodes.ACC_PUBLIC,"onCommand",desc,null,null);var label=new LabelNode();
        m.instructions.add(new VarInsnNode(Opcodes.ALOAD,0));m.instructions.add(new VarInsnNode(Opcodes.ALOAD,1));m.instructions.add(new VarInsnNode(Opcodes.ALOAD,4));
        m.instructions.add(new MethodInsnNode(Opcodes.INVOKESTATIC,SUPPORT,"route","(Lorg/bukkit/plugin/java/JavaPlugin;Lorg/bukkit/command/CommandSender;[Ljava/lang/String;)[Ljava/lang/String;",false));
        m.instructions.add(new InsnNode(Opcodes.DUP));m.instructions.add(new JumpInsnNode(Opcodes.IFNONNULL,label));
        m.instructions.add(new InsnNode(Opcodes.POP));m.instructions.add(new InsnNode(Opcodes.ICONST_1));m.instructions.add(new InsnNode(Opcodes.IRETURN));
        m.instructions.add(label);m.instructions.add(new FrameNode(Opcodes.F_SAME1,0,null,1,new Object[]{"[Ljava/lang/String;"}));
        m.instructions.add(new VarInsnNode(Opcodes.ASTORE,4));
        for(int slot=0;slot<=4;slot++)m.instructions.add(new VarInsnNode(Opcodes.ALOAD,slot));
        m.instructions.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL,MAIN,"editionBaseCommand",desc,false));m.instructions.add(new InsnNode(Opcodes.IRETURN));
        m.maxLocals=5;n.methods.add(m);
        var w=new ClassWriter(ClassWriter.COMPUTE_MAXS);n.accept(w);Files.write(Path.of(args[1]),w.toByteArray());
        System.out.println("PASS: test1 edition command facade; configurable owner sites="+owners+"; all combat classes preserved");
    }
}

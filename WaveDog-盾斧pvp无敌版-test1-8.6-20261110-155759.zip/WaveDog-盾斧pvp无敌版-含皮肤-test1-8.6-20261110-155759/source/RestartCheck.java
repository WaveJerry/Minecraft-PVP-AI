import java.io.*;import java.lang.reflect.*;import java.nio.file.*;import java.util.*;import java.util.zip.*;
/** Differential tests execute the actual archived and revised controllers in isolated loaders. */
public final class RestartCheck {
    static int checks,oldPunishments;
    static void check(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}
    static final class Archive extends ClassLoader {
        final Map<String,byte[]> bytes=new HashMap<>();
        Archive(Path jar,Path override)throws Exception{super(RestartCheck.class.getClassLoader());
            try(var in=new ZipInputStream(Files.newInputStream(jar))){for(ZipEntry e;(e=in.getNextEntry())!=null;)if(e.getName().endsWith(".class"))bytes.put(e.getName().substring(0,e.getName().length()-6).replace('/','.'),in.readAllBytes());}
            if(override!=null){for(String n:List.of("InitialCombatController","InitialCombatController$Phase"))bytes.put("local.pvpbot.ai."+n,Files.readAllBytes(override.resolve("local/pvpbot/ai/"+n+".class")));}
        }
        protected Class<?> findClass(String name)throws ClassNotFoundException{byte[] b=bytes.get(name);if(b==null)throw new ClassNotFoundException(name);return defineClass(name,b,0,b.length);}
        Class<?> type(String name)throws Exception{return loadClass("local.pvpbot.ai."+name);}
        Object make(String name,Class<?>[] parameters,Object...args)throws Exception{var c=type(name).getDeclaredConstructor(parameters);c.setAccessible(true);return c.newInstance(args);}
    }
    static final class Controller {
        final Archive archive;final Object controller;final Method decide,name;
        Controller(Archive archive,int profile,long seed)throws Exception{this.archive=archive;
            Object policy=archive.make(profile==0?"test1":"test2",new Class<?>[]{});
            Method create=policy.getClass().getDeclaredMethod("createInitialController",long.class);create.setAccessible(true);controller=create.invoke(policy,seed);
            decide=controller.getClass().getDeclaredMethod("decide",archive.type("CombatView"),archive.type("NeuralLearner$Senses"));decide.setAccessible(true);
            name=controller.getClass().getDeclaredMethod("name");name.setAccessible(true);
        }
        String phase()throws Exception{return (String)name.invoke(controller);}
        String step(Map<String,Object> v,Map<String,Object> s)throws Exception{
            Class<?> view=archive.type("CombatView");var components=view.getRecordComponents();Object[] args=new Object[components.length];Class<?>[] types=new Class<?>[components.length];
            for(int i=0;i<components.length;i++){
                var c=components[i];types[i]=c.getType();Object value=v.get(c.getName());
                args[i]=c.getType().isEnum()?enumValue(c.getType(),(String)value):value;
            }
            Object sensed=archive.make("NeuralLearner$Senses",new Class<?>[]{});
            for(var entry:s.entrySet())try{Field f=sensed.getClass().getDeclaredField(entry.getKey());f.setAccessible(true);
                f.set(sensed,f.getType().isEnum()?enumValue(f.getType(),(String)entry.getValue()):entry.getValue());
            }catch(NoSuchFieldException e){throw new AssertionError("Fixture refers to missing original field: "+entry.getKey(),e);}
            return decide.invoke(controller,archive.make("CombatView",types,args),sensed).toString()+"/"+phase();
        }
    }
    @SuppressWarnings({"unchecked","rawtypes"})static Object enumValue(Class<?> c,String name){return Enum.valueOf((Class)c,name);}
    static Map<String,Object> view(long tick,double distance,boolean shield){
        Map<String,Object> v=new HashMap<>();
        v.put("tick",tick);v.put("distance",distance);v.put("visible",true);v.put("targetBlocking",false);v.put("targetAxe",true);v.put("targetFacing",true);
        v.put("ownShieldAvailable",shield);v.put("ownShieldJustDisabled",false);v.put("targetShieldJustDropped",false);v.put("targetAttackedRecently",false);
        v.put("ownAttackReady",true);v.put("ownWounded",false);v.put("nearWall",false);v.put("targetNearWall",false);v.put("hasArrows",true);
        v.put("targetDrawingRanged",false);v.put("targetHoldingRanged",false);v.put("targetMotion","APPROACH");v.put("targetInReach",distance<=3);
        v.put("ownAttackCharge",1f);v.put("bowDrawTicks",0);v.put("rangedUseTicks",0);v.put("ownCrossbowCharged",false);v.put("ownOffhand","SHIELD");return v;
    }
    static Map<String,Object> senses(double distance){
        Map<String,Object> s=new HashMap<>();
        for(String key:List.of("ownReachDistance","targetReachDistance","meleeRayDistance","estimatedReach","estimatedTargetReach"))s.put(key,distance);
        s.put("estimateAge",0.);s.put("weaponInputReady",true);s.put("ownWeapon",0);s.put("onGround",true);s.put("targetMotionFresh",true);
        s.put("targetFacingDot",1.);s.put("targetAttackAge",1000.);s.put("blockedMeleeAge",1000.);s.put("damageAge",1000.);
        s.put("ownKnockbackAge",1000.);s.put("targetLandAge",1000.);s.put("lastBlockTick",-1000L);s.put("lastMeleeTick",-1000L);
        s.put("targetShieldDisabled",true);s.put("escapeJumpEligible",true);s.put("escapeViable",true);s.put("wallEscapeAvailable",true);
        s.put("opportunity","NONE");s.put("bowPresent",true);s.put("crossbowPresent",true);return s;
    }
    public static void main(String[] args)throws Exception{
        Path b=Path.of(args[0]);var original=new Archive(b.resolve("original-0.10.11.jar"),null);
        var reference=new Archive(b.resolve("original-0.10.11.jar"),b.resolve("reference-classes"));var patched=new Archive(b.resolve("PvPArenaAI.jar"),null);
        if(args.length>1&&args[1].equals("--verify-entry")){
            Class<?> entry=Class.forName("local.pvpbot.ai.PvPArenaAI",false,patched);
            check(entry.getDeclaredMethods().length>100,"patched server entry resolves and verifies under the real API dependencies");
        }
        for(int profile=0;profile<2;profile++){
            var a=new Controller(original,profile,1811);var r=new Controller(reference,profile,1811);var p=new Controller(patched,profile,1811);Random rand=new Random(1561);
            for(int tick=0;tick<12000;tick++){
                double d=.4+rand.nextDouble()*14;boolean shield=rand.nextBoolean();var v=view(tick,d,shield);var s=senses(d);
                s.put("blocking",shield);s.put("holdingShield",shield);s.put("targetFacingDot",rand.nextDouble()*2-1);
                s.put("targetShieldRaised",rand.nextBoolean());v.put("targetBlocking",s.get("targetShieldRaised"));
                s.put("targetShieldDisabled",!(boolean)s.get("targetShieldRaised"));s.put("collisionOverlap",d<.7);s.put("orbitRadius",d);
                boolean air=rand.nextInt(5)==0;s.put("targetAirborne",air);s.put("targetCritThreat",air&&d<5);s.put("targetCriticalPossible",air);
                s.put("targetY",air?(rand.nextBoolean()?.25:-.25):0.);s.put("targetCritEta",air?4.:60.);s.put("retreatBlocked",rand.nextInt(9)==0);
                s.put("withdrawing",rand.nextInt(4)==0);s.put("retreatOpened",rand.nextBoolean());s.put("enteredReach",d<3&&rand.nextBoolean());
                if(tick%83==0){s.put("lastBlockTick",(long)tick);s.put("blockedMeleeAge",0.);}
                String expected=a.step(v,s);check(expected.equals(r.step(v,s)),"reconstructed unchanged source differs from archived 0.10.11 at tick "+tick);
                check(expected.equals(p.step(v,s)),"unrelated combat behavior changed at tick "+tick+": "+expected+" vs "+p.phase());
            }
            for(int i=0;i<120;i++){
                var old=new Controller(original,profile,81+i);var now=new Controller(patched,profile,81+i);var v=view(i,2.6,false);var s=senses(2.6);
                s.put("criticalReplyPending",true);s.put("damageAge",1.);s.put("ownKnockbackAge",1.);s.put("onGround",false);
                s.put("ownCriticalWindow",true);s.put("ownCriticalReady",true);s.put("withdrawing",true);
                old.step(v,s);if(old.phase().equals("PUNISH_CRIT"))oldPunishments++;
                now.step(v,s);check(!Set.of("PUNISH_CRIT","CRIT_REPLY","RECOVER_BREAK","RECOVER_WARMUP").contains(now.phase()),"retired chain still reachable");
            }
            var now=new Controller(patched,profile,551);var v=view(100,2.6,false);var s=senses(2.6);s.put("opportunity","ENTRY");s.put("enteredReach",true);v.put("ownAttackCharge",.1f);
            String entry=now.step(v,s);check(entry.contains("attack=true")&&now.phase().equals("ENTRY_HIT"),"normal low-charge legal entry counter retained");
            Object recovery=patched.make("RecoveryBreak",new Class<?>[]{});Method arm=recovery.getClass().getDeclaredMethod("arm",long.class,String.class);arm.setAccessible(true);arm.invoke(recovery,10L,"target");
            Method pending=recovery.getClass().getDeclaredMethod("pending",long.class);pending.setAccessible(true);check(!(boolean)pending.invoke(recovery,11L),"retired recovery cannot arm");
        }
        check(oldPunishments==240,"regression fixture must actually trigger the old bug, got "+oldPunishments);
        System.out.println("PASS: "+checks+" assertions; 24,000 normal frames unchanged; original revenge reproduced="+oldPunishments+", revised revenge=0; both policies tested");
    }
}

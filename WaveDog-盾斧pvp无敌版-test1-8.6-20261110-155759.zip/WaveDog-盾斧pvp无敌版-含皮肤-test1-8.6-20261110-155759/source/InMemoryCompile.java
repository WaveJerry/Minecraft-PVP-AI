import java.io.*;import java.net.URI;import java.nio.file.*;import java.util.*;import java.util.jar.*;import javax.tools.*;
/** Read archived dependencies without javac's Windows ZIP filesystem finalization bug. */
public final class InMemoryCompile {
    static final class Bytecode extends SimpleJavaFileObject {
        final String name;final byte[] bytes;
        Bytecode(String name,byte[] bytes){super(URI.create("memory:///"+name.replace('.','/')+".class"),Kind.CLASS);this.name=name;this.bytes=bytes;}
        public InputStream openInputStream(){return new ByteArrayInputStream(bytes);}
    }
    public static void main(String[] args)throws Exception{
        Map<String,Bytecode> classes=new HashMap<>();
        int sourcesAt=2;
        List<Path> archives=new ArrayList<>();archives.add(Path.of(args[0]));
        if(args.length>3 && args[2].equals("--dependencies")) {
            for(String path:Files.readAllLines(Path.of(args[3])))if(!path.isBlank())archives.add(Path.of(path));
            sourcesAt=4;
        }
        for(Path archive:archives)try(var in=new JarInputStream(Files.newInputStream(archive))){
            for(JarEntry entry;(entry=in.getNextJarEntry())!=null;)if(entry.getName().endsWith(".class")){
                String name=entry.getName().substring(0,entry.getName().length()-6).replace('/','.');classes.put(name,new Bytecode(name,in.readAllBytes()));
            }
        }
        JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
        try(var standard=compiler.getStandardFileManager(null,Locale.ROOT,java.nio.charset.StandardCharsets.UTF_8)){
            var manager=new ForwardingJavaFileManager<StandardJavaFileManager>(standard){
                public Iterable<JavaFileObject> list(Location location,String pkg,Set<JavaFileObject.Kind> kinds,boolean recurse)throws IOException{
                    if(location==StandardLocation.CLASS_PATH){
                        List<JavaFileObject> result=new ArrayList<>();for(var c:classes.values()){
                            int dot=c.name.lastIndexOf('.');String p=dot<0?"":c.name.substring(0,dot);
                            if(p.equals(pkg)||recurse&&p.startsWith(pkg+"."))result.add(c);
                        }for(var f:super.list(location,pkg,kinds,recurse))result.add(f);return result;
                    }return super.list(location,pkg,kinds,recurse);
                }
                public String inferBinaryName(Location l,JavaFileObject f){return f instanceof Bytecode b?b.name:super.inferBinaryName(l,f);}
                public JavaFileObject getJavaFileForInput(Location l,String name,JavaFileObject.Kind kind)throws IOException{
                    return l==StandardLocation.CLASS_PATH&&classes.containsKey(name)?classes.get(name):super.getJavaFileForInput(l,name,kind);
                }
            };
            var sources=standard.getJavaFileObjectsFromStrings(Arrays.asList(args).subList(sourcesAt,args.length));
            boolean ok=compiler.getTask(null,manager,null,List.of("--release","21","-encoding","UTF-8","-d",args[1]),null,sources).call();
            if(!ok)throw new IllegalStateException("Compilation failed");
        }
    }
}

# WaveDog · 盾斧pvp无敌版（8.6 / test1 / 含皮肤）

服务器端作品包，基于 0.10.11-ground.8.6-duel.1，保存 test1 当前已落盘训练成果，默认冻结推理。原版 Minecraft Java 1.21.1 客户端可玩，无需客户端模组。需要 Java 21 和独立 Paper 1.21.1 服务器；本包不是单人存档数据包，也不包含 Paper、Java 或游戏客户端。

1. 解压后双击“安装到独立服务器.cmd”，输入一个独立、已关闭的 Paper 1.21.1 服务器目录。安装脚本拒绝覆盖已有 AI 或不同依赖。也可将 plugins 内容复制到新服务器的 plugins 目录。
2. 将 plugins/PvPArenaAI/config.yml 中的 owner-name 改成自己的游戏名，默认 WaveJerry。正常启动服务器；本机通过服务器实际端口进入。公开服务器使用正版验证或自行配置登录保护。本机离线连接只允许回环地址；随包没有原服务器的登录数据。
3. 在新世界中执行 `/wavedog setup create`，创建固定竞技场。此命令覆盖 world 中 X/Z=991..1038、Y=220..230 的方块，并给在线的指定玩家装备。不会自动创建或修改主服场地。
4. `/wavedog duel` 或 `/wavedog duel test1` 开始与 WaveDog 循环对战；每局准备五秒。`/wavedog stop` 停止，`/wavedog idle` 暂停全部 AI，`/wavedog status` 查看状态。
5. `/wavedog learn on` 继续学习，`/wavedog learn off` 冻结使用现有成果，`/wavedog review` 保存战后分析。正常关服在服务器控制台输入 `stop`。

本作品固定接入 test1。第二控制器保留为内部兼容结构，未打包 test2 或 UHC 权重；多人可旁观，当前对战玩家由 owner-name 指定。默认关闭日常游走。

包含全部 8.6 累计修复，包括新的疾跑侧跳躲箭和统一弹道判断，特别是让假玩家按真实位移执行原版下落结算的 fakeplayer.jar，和跑跳暴击后同次调用恢复原疾跑方向的修复。删除眩晕破盾；不扩大射程、不制造伤害、不修改原生速度或暴击条件。有效盾才阻止这刀暴击。

导出仅调整作品指令、可配置玩家身份和独立服务器登录衔接；战斗控制器、感知、学习、射程、物理相关核心 class 与已验证的 8.6 包逐字节一致，详见 plugins/edition-preservation.json。包含 CommandAPI、fakeplayer、ArrowSense、PvPBotRespawn 、头顶血量插件和自动皮肤插件 PvPBotAppearance。第三方原始 JAR 的内置许可保留；fakeplayer 的本地修复源码及原包也随源码快照提供。

“盾斧pvp无敌版”是作品名称。验证记录区分核心实服样例、导出包独立启动和真人对局；名称不代表经过证明的所有对局必胜。核心真实暴击、同次恢复跑跳、原生弓弩和弹道防御的验证记录已附带。

没有打包主服世界、玩家存档、登录数据库、密码、RCON 配置、穿透账号或其他个人账号配置。已按要求配套当前 WaveDog 皮肤：skins/WaveDog.png、签名纹理数据及 plugins/PvPBotAppearance.jar；生成或重生时自动应用，无需安装 SkinsRestorer 或登录皮肤服务。原版客户端仍需能从 textures.minecraft.net 加载纹理。导出不改动或重启主服务器，后续训练不覆盖此快照。`python verify.py` 校验文件；manifest.json 记录版本、模型来源时间和 SHA256。

源码在 source.zip，已验证核心为 source/validated-core.jar。作品入口重建：设置 WAVEDOG_BUILD_SERVER 指向具有 Java 21 和 Paper/fakeplayer 依赖的服务器目录，再运行 `python source/build-perfect-edition.py source/validated-core.jar rebuilt-edition.jar`。完整核心构建快照位于 source/core/work/counter-escape-ground，路径依赖沿用导出记录；它只用于重建，安装不需要编译。

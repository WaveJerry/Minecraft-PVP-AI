param([Parameter(Mandatory=$true)][string]$ServerDirectory)
$ErrorActionPreference='Stop'
$sourceRoot=Join-Path $PSScriptRoot 'plugins'
$resolvedTarget=[System.IO.Path]::GetFullPath($ServerDirectory)
if(-not (Test-Path -LiteralPath $resolvedTarget -PathType Container)){throw 'Target server directory does not exist.'}
$pluginTarget=Join-Path $resolvedTarget 'plugins'
if(Test-Path -LiteralPath (Join-Path $pluginTarget 'PvPArenaAI')){throw 'Existing AI data found. Use a separate server directory for this saved edition; nothing changed.'}
if(Test-Path -LiteralPath (Join-Path $pluginTarget 'PvPArenaAI.jar')){throw 'Existing AI plugin found. Use a separate server directory for this saved edition; nothing changed.'}
$entries=Get-ChildItem -LiteralPath $sourceRoot -File
foreach($entry in $entries){
 $destination=Join-Path $pluginTarget $entry.Name
 if(Test-Path -LiteralPath $destination){
  if((Get-FileHash -LiteralPath $destination).Hash -ne (Get-FileHash -LiteralPath $entry.FullName).Hash){throw ('Different dependency already exists: '+$entry.Name+'. Nothing changed.')}
 }
}
New-Item -ItemType Directory -Path $pluginTarget -Force | Out-Null
foreach($entry in $entries){Copy-Item -LiteralPath $entry.FullName -Destination (Join-Path $pluginTarget $entry.Name)}
foreach($name in @('PvPArenaAI','fakeplayer')){
 $from=Join-Path $sourceRoot $name
 $to=Join-Path $pluginTarget $name
 if(-not (Test-Path -LiteralPath $to)){Copy-Item -LiteralPath $from -Destination $to -Recurse}
}
Write-Output 'DONE: WaveDog test1 installed to a separate server. Configure owner-name before starting Paper 1.21.1 / Java 21.'

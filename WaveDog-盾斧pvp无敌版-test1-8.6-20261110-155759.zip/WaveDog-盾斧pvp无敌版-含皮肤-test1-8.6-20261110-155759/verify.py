"""Verify an extracted edition against its frozen manifest; does not start a server."""
from pathlib import Path
import hashlib,json,zipfile
BASE=Path(__file__).resolve().parent
m=json.loads((BASE/'manifest.json').read_text(encoding='utf-8'))
for name,expected in m['files_sha256'].items():
 p=(BASE/name).resolve()
 if not p.is_relative_to(BASE.resolve()) or not p.is_file():raise SystemExit('FAILED missing/outside file: '+name)
 if hashlib.sha256(p.read_bytes()).hexdigest()!=expected:raise SystemExit('FAILED checksum: '+name)
for p in (BASE/'plugins').glob('*.jar'):
 with zipfile.ZipFile(p) as jar:
  if jar.testzip() is not None or 'plugin.yml' not in jar.namelist():raise SystemExit('FAILED plugin archive: '+p.name)
print('VERIFIED:',m['name'],m['edition_version'],';',len(m['files_sha256']),'files; profile='+m['profile'])
print('This verifies files, not gameplay. Live status:',m['independent_live_validation'])

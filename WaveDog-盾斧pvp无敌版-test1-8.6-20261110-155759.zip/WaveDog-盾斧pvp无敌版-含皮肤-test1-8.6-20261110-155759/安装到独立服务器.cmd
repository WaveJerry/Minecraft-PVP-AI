@echo off
setlocal
set /p "wavedog_target=Enter a separate stopped Paper 1.21.1 server folder: "
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-to-server.ps1" -ServerDirectory "%wavedog_target%"
pause

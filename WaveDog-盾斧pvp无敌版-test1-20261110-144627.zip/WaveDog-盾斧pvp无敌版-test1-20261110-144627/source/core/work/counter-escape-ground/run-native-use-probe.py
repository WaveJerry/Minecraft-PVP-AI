from pathlib import Path
import os,shutil,subprocess,zipfile,json,hashlib
b=Path(__file__).resolve().parent;root=b.parents[1];s=Path(r'D:\Walt Disney\Minecraft-1.21.1-Server');j=s/'runtime/java21/bin'
p=b/'native-use-server';p.mkdir(exist_ok=True);(p/'plugins').mkdir(exist_ok=True)
libs=sorted((s/'libraries').rglob('*.jar'));cp=os.pathsep.join(map(str,[s/'versions/1.21.1/paper-1.21.1.jar',*libs]))
c=b/'native-probe-classes';c.mkdir(exist_ok=True)
args=b/'probe-compile.args';args.write_text('\n'.join('"'+x.replace('\\','\\\\').replace('"','\\"')+'"' for x in ['-encoding','UTF-8','--release','21','-cp',cp+os.pathsep+str(b/'fakeplayer.jar'),'-d',str(c),str(b/'NativeUseProbePlugin.java'),str(b/'NativeEscapeProbe.java')]),encoding='utf-8')
subprocess.run([str(j/'javac.exe'),'@'+str(args)],check=True)
with zipfile.ZipFile(p/'plugins/NativeUseProbe.jar','w',zipfile.ZIP_DEFLATED) as z:
 for f in c.rglob('*.class'):z.write(f,f.relative_to(c))
 z.writestr('plugin.yml','name: NativeUseProbe\nversion: 1.0\nmain: local.wavedog.probe.NativeUseProbePlugin\napi-version: "1.21"\ndepend: [fakeplayer, PvPArenaAI]\n')
for name in ['CommandAPI.jar','ArrowSense.jar']:shutil.copy2(s/'plugins'/name,p/'plugins'/name)
shutil.copy2(b/'fakeplayer.jar',p/'plugins/fakeplayer.jar')
shutil.copy2(b/'PvPArenaAI.jar',p/'plugins/PvPArenaAI.jar')
(p/'eula.txt').write_text('eula=true\n')
(p/'server.properties').write_text('server-ip=127.0.0.1\nserver-port=25586\nonline-mode=false\nenable-rcon=false\nview-distance=2\nsimulation-distance=2\nspawn-protection=0\nlevel-type=minecraft:flat\ngenerate-structures=false\nmax-players=4\nspawn-npcs=false\nspawn-monsters=false\nspawn-animals=false\nallow-nether=false\nsync-chunk-writes=false\n',encoding='ascii')
# Use the already installed Paper runtime directly; no dependency downloads or C-drive writes.
launch=b/'probe-server.args';launch.write_text('\n'.join('"'+x.replace('\\','\\\\').replace('"','\\"')+'"' for x in ['-Xms256M','-Xmx512M','-Duser.home='+str(p/'home'),'-Djava.io.tmpdir='+str(p/'tmp'),'-cp',cp,'org.bukkit.craftbukkit.Main','--nogui']),encoding='utf-8')
(p/'tmp').mkdir(exist_ok=True);(p/'home').mkdir(exist_ok=True)
result=p/'native-use-result.txt'
if result.exists():result.unlink()
with (p/'probe-console.log').open('wb') as out:
 process=subprocess.Popen([str(j/'java.exe'),'@'+str(launch)],cwd=p,stdout=out,stderr=subprocess.STDOUT,stdin=subprocess.PIPE)
 try:process.wait(timeout=150)
 except subprocess.TimeoutExpired:
  process.stdin.write(b'stop\n');process.stdin.flush();process.wait(timeout=45)
result=p/'native-use-result.txt'
if result.exists():print(result.read_text(encoding='utf-8'))
else:
 print((p/'probe-console.log').read_text(encoding='utf-8',errors='replace')[-6500:]);raise SystemExit('Native use probe incomplete')
report=result.read_text(encoding='utf-8')
if 'FAILED' in report:raise SystemExit(1)
for required in ['shipped escape controller/instant-turn emitted a real critical damage event',
                 'same-call attack restored sprint and original escape direction',
                 'warmed front-facing shield is effective',
                 'warmed shield facing away does not block the critical opportunity',
                 'normal native bow release emitted exactly one real EntityShootBowEvent',
                 'scenario 4 real arrow caused no health loss']:
 if 'PASS '+required not in report:raise SystemExit('Incomplete native probe: '+required)
(b/'native-validated.json').write_text(json.dumps({'jar_sha256':hashlib.sha256((p/'plugins/PvPArenaAI.jar').read_bytes()).hexdigest(),
 'fakeplayer_sha256':hashlib.sha256((p/'plugins/fakeplayer.jar').read_bytes()).hexdigest(),
 'real_paper_server':True,'bow_native_shot':True,'crossbow_real_charged_ammo':True,
 'native_sprint_jump_critical':True,'effective_shield_delay_and_facing':True,
 'projectile_scenarios':['front shield','rear shield','broken shield straight arrow','broken shield gravity arc','broken shield wall'],
 'live_player_gameplay_validated':False},indent=2),encoding='utf-8')

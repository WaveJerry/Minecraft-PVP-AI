from pathlib import Path
import hashlib,json,os,subprocess,zipfile
b=Path(__file__).resolve().parent;root=b.parents[1]
s=Path(r'D:\Walt Disney\Minecraft-1.21.1-Server');j=s/'runtime/java21/bin'
c=b/'reflection-check-classes';c.mkdir(exist_ok=True);logs=[]
def run(args):
    r=subprocess.run(list(map(str,args)),stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    text=r.stdout.decode('utf-8',errors='replace');print(text,end='');logs.append(text)
    (b/'validation.log').write_text(''.join(logs),encoding='utf-8');r.check_returncode()
run([j/'javac.exe','-encoding','UTF-8','--release','21','-d',c,root/'work/pvp-ai-0.10.11-restart/RestartCheck.java',root/'work/duel-player-command/DuelPlayerLoadCheck.java',b/'CounterShieldCheck.java',b/'PressureControllerCheck.java',b/'HopWeaponCheck.java',b/'RangedIntegrationCheck.java',b/'ExtraMechanicsCheck.java',b/'TradeMechanicsCheck.java',b/'CombatRegressionCheck.java',b/'ExchangeRepairCheck.java',b/'ProjectileArbitrationCheck.java'])
libs=sorted((s/'libraries').rglob('*.jar'))
cp=[c,*libs,s/'versions/1.21.1/paper-1.21.1.jar',s/'plugins/fakeplayer.jar',s/'plugins/ArrowSense.jar',s/'plugins/AuthMe.jar']
def java(name,paths,args=()):
    af=b/(name+'.args');aa=['-Xmx384m','-Xverify:all','-cp',os.pathsep.join(map(str,paths)),name,*map(str,args)]
    af.write_text('\n'.join('"'+a.replace('\\','\\\\').replace('"','\\"')+'"' for a in aa),encoding='utf-8')
    run([j/'java.exe','@'+str(af)])
java('CounterShieldCheck',cp,[b/'PvPArenaAI.jar'])
java('PressureControllerCheck',cp,[b/'PvPArenaAI.jar'])
java('HopWeaponCheck',cp,[b/'PvPArenaAI.jar'])
java('RangedIntegrationCheck',cp,[b/'PvPArenaAI.jar'])
java('ExtraMechanicsCheck',cp,[b/'PvPArenaAI.jar',b/'WaveDogTestTools.jar',b/'WaveDogHeadHearts.jar'])
java('TradeMechanicsCheck',cp,[b/'PvPArenaAI.jar'])
java('CombatRegressionCheck',cp,[b/'PvPArenaAI.jar'])
java('ExchangeRepairCheck',cp,[b/'PvPArenaAI.jar'])
java('ProjectileArbitrationCheck',cp,[b/'PvPArenaAI.jar'])
java('DuelPlayerLoadCheck',cp,[b/'PvPArenaAI.jar'])
run([j/'java.exe','-Xmx512m','-Xverify:all',b/'GroundPressureCheck.java',b,root/'work/pvp-ai-0.10.11-restart/compiler-dependencies.jar'])
pure=b/'pure-check-classes';pure.mkdir(exist_ok=True)
run([j/'javac.exe','--release','21','-d',pure,b/'src/local/pvpbot/ai/PressureRecovery.java',b/'PressureRecoveryCheck.java'])
java('local.pvpbot.ai.PressureRecoveryCheck',[pure])
asm=next((s/'libraries/org/ow2/asm/asm').rglob('*.jar'));tree=next((s/'libraries/org/ow2/asm/asm-tree').rglob('*.jar'))
toolcp=os.pathsep.join(map(str,[c,asm,tree]))
run([j/'javac.exe','--release','21','-cp',toolcp,'-d',c,b/'CounterGroundAudit.java'])
java('CounterGroundAudit',[c,asm,tree],[b/'base.jar',b/'PvPArenaAI.jar'])
(b/'validated.json').write_text(json.dumps({'jar_sha256':hashlib.sha256((b/'PvPArenaAI.jar').read_bytes()).hexdigest(),
    'test_tools_sha256':hashlib.sha256((b/'WaveDogTestTools.jar').read_bytes()).hexdigest(),
    'head_hearts_sha256':hashlib.sha256((b/'WaveDogHeadHearts.jar').read_bytes()).hexdigest(),
    'checks':['CounterShieldCheck','PressureControllerCheck','HopWeaponCheck','RangedIntegrationCheck','ExtraMechanicsCheck','TradeMechanicsCheck','CombatRegressionCheck','ExchangeRepairCheck','ProjectileArbitrationCheck','DuelPlayerLoadCheck','GroundPressureCheck','PressureRecoveryCheck','CounterGroundAudit'],
    'real_api_jvm_verified':True,'live_gameplay_validated':False},indent=2),encoding='utf-8')

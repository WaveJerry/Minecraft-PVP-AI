package local.pvpbot.ai;

import java.lang.reflect.Field;
import java.util.*;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.util.Vector;
import local.pvpbot.sense.ArrowSenseService;

/** One shared trajectory/input plan for tick, shot and movement arbitration. */
final class ProjectileDefence {
    record Plan(ArrowDodgePlanner.Result path, Vector forward, Vector guard, boolean shield, int action) {
        boolean owns() { return path.threat() && (shield || action >= 0); }
    }
    private static Field senseField;
    static boolean hasShield(Player p) {
        if(p.hasCooldown(Material.SHIELD))return false;
        for(var i:p.getInventory().getContents())if(i!=null&&i.getType()==Material.SHIELD)return true;
        return false;
    }
    private static ArrowSenseService sensor(PvPArenaAI plugin) {
        try {
            if(senseField==null){senseField=PvPArenaAI.class.getDeclaredField("arrowSense");senseField.setAccessible(true);}
            return (ArrowSenseService)senseField.get(plugin);
        }catch(ReflectiveOperationException e){throw new IllegalStateException("Projectile perception unavailable",e);}
    }
    static Plan plan(PvPArenaAI plugin,Player p,int intended,AbstractArrow incoming) {
        Vector forward=p.getLocation().getDirection().setY(0);
        if(forward.lengthSquared()<1e-8)forward=new Vector(0,0,1);else forward.normalize();
        var shots=new ArrayList<ArrowDodgePlanner.Shot>();var ids=new HashSet<Integer>();
        for(var a:sensor(plugin).observe(p).arrows()) {
            // The sense service provides swept, gravity/drag-aware paths clipped at blocks.
            if(incoming!=null&&a.id()==incoming.getEntityId())continue;
            ids.add(a.id());
            shots.add(new ArrowDodgePlanner.Shot(a.id(),new ArrowDodgePlanner.Vec(a.x(),a.y(),a.z()),
                new ArrowDodgePlanner.Vec(a.vx(),a.vy(),a.vz()),a.gravity(),a.drag(),a.piercing()==0,
                a.path().stream().map(v->new ArrowDodgePlanner.Vec(v.x(),v.y(),v.z())).toList()));
        }
        // A shoot event can occur after this tick's sensor cache. Include its actual
        // projectile now, rather than waiting for the next tick to see a fast arrow.
        if(incoming!=null&&ids.add(incoming.getEntityId())) {
            var pos=incoming.getLocation().toVector();var vel=incoming.getVelocity();
            shots.add(new ArrowDodgePlanner.Shot(incoming.getEntityId(),vec(pos),vec(vel),incoming.hasGravity(),
                incoming.isInWater()?.6:.99,incoming.getPierceLevel()==0,trajectory(p,incoming)));
        }
        var box=p.getBoundingBox();var feet=p.getLocation().toVector();
        var attribute=p.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED);
        double acceleration=attribute==null?.1:attribute.getValue()/(p.isSprinting()?1.3:1);
        boolean arena=p.getX()>=992&&p.getX()<=1037&&p.getZ()>=992&&p.getZ()<=1037;
        boolean shield=hasShield(p);
        // Shield available => guard only. No shield => cancel item use and evaluate
        // the full-speed input we will actually submit, including current inertia.
        var body=new ArrowDodgePlanner.Body(vec(feet),vec(p.getVelocity()),vec(forward),
            Math.max(box.getWidthX(),box.getWidthZ())/2,box.getHeight(),acceleration,shield?.2:1,
            p.isOnGround(),p.getFoodLevel()>6,arena?992:feet.getX()-32,arena?1037:feet.getX()+32,
            arena?992:feet.getZ()-32,arena?1037:feet.getZ()+32,arena?221:feet.getY());
        int action=intended>=0&&intended<17?intended:0;
        var path=ArrowDodgePlanner.evaluate(body,shots,0,false,shield?0:action);
        if(!path.threat())return new Plan(path,forward,null,false,-1);
        if(shield) {
            Vector guard=forward.clone();
            for(var shot:shots)if(shot.id()==path.primaryId()) {
                guard=new Vector(shot.position().x()-p.getX(),0,shot.position().z()-p.getZ());
                if(guard.lengthSquared()<1e-8)guard=new Vector(-shot.velocity().x(),0,-shot.velocity().z());
                if(guard.lengthSquared()<1e-8)guard=forward.clone();else guard.normalize();
                break;
            }
            return new Plan(path,forward,guard,true,-1);
        }
        int selected=choose(p,path,body,forward);
        if(selected<0)path=new ArrowDodgePlanner.Result(path.threat(),path.eta(),path.miss(),0,
            new boolean[path.safeMoves().length],path.viableMoves(),false,false,path.primaryId());
        else path=new ArrowDodgePlanner.Result(path.threat(),path.eta(),path.miss(),selected,
            path.safeMoves(),path.viableMoves(),false,true,path.primaryId());
        return new Plan(path,forward,null,false,selected);
    }
    private static List<ArrowDodgePlanner.Vec> trajectory(Player p,AbstractArrow a) {
        var path=new ArrayList<ArrowDodgePlanner.Vec>();var pos=a.getLocation().toVector();var vel=a.getVelocity();
        path.add(vec(pos));double drag=a.isInWater()?.6:.99;
        for(int i=0;i<ArrowDodgePlanner.HORIZON;i++) {
            double length=vel.length();if(length<1e-8)break;
            var hit=p.getWorld().rayTraceBlocks(pos.toLocation(p.getWorld()),vel.clone().normalize(),length,FluidCollisionMode.NEVER,true);
            if(hit!=null){path.add(vec(hit.getHitPosition()));break;}
            pos=pos.clone().add(vel);path.add(vec(pos));vel.multiply(drag);if(a.hasGravity())vel.setY(vel.getY()-.05);
        }
        return path;
    }
    static double forward(int action) { return switch(action){case 1,2,6,7,8,9,12->1;case 3,10,11,15->-1;default->0;}; }
    static double side(int action) { return switch(action){case 4,6,8,10,13->-1;case 5,7,9,11,14->1;default->0;}; }
    private static int choose(Player p,ArrowDodgePlanner.Result path,ArrowDodgePlanner.Body body,Vector forward) {
        int preferred=path.preferredMove();
        if(safe(p,path,body,forward,preferred))return preferred;
        for(int i=0;i<path.safeMoves().length;i++)if(safe(p,path,body,forward,i))return i;
        return -1;
    }
    private static boolean safe(Player p,ArrowDodgePlanner.Result path,ArrowDodgePlanner.Body body,Vector forward,int action) {
        if(action<0||action>=17||!path.safeMoves()[action]||!path.viableMoves()[action])return false;
        double slow=action>=12&&action<=16?.3:1;
        double f=forward(action)*.98*slow,s=side(action)*.98*slow,scale=Math.hypot(f,s);
        if(scale>1){f/=scale;s/=scale;}
        double dx=forward.getX()*f-forward.getZ()*s,dz=forward.getZ()*f+forward.getX()*s;
        double vx=body.velocity().x(),vz=body.velocity().z(),x=0,z=0,y=body.feet().y(),vy=body.onGround()?0:body.velocity().y();
        boolean grounded=body.onGround();
        // A theoretical safe direction through a block is not an executable dodge.
        // Validate the swept player box up to the threatening arrow's arrival.
        int ticks=Math.min(ArrowDodgePlanner.HORIZON,Math.max(2,(int)Math.ceil(path.eta())+2));
        var box=p.getBoundingBox();
        for(int t=0;t<ticks;t++) {
            double acceleration=(grounded?body.acceleration():.02)*(GroundFootwork.sprinting(action)?1.3:1);
            vx+=dx*acceleration;vz+=dz*acceleration;
            x+=vx;z+=vz;y+=vy;
            if(!grounded&&y<=body.floorY()&&vy<=0){y=body.floorY();vy=0;grounded=true;}
            var next=box.clone().shift(x,y-body.feet().y(),z);
            for(int bx=(int)Math.floor(next.getMinX());bx<=Math.floor(next.getMaxX());bx++)
                for(int by=(int)Math.floor(next.getMinY()+.001);by<=Math.floor(next.getMaxY()-.001);by++)
                    for(int bz=(int)Math.floor(next.getMinZ());bz<=Math.floor(next.getMaxZ());bz++) {
                        if(!p.getWorld().isChunkLoaded(bx>>4,bz>>4))return false;
                        var block=p.getWorld().getBlockAt(bx,by,bz);
                        if(block.isPassable())continue;
                        for(var part:block.getCollisionShape().getBoundingBoxes())
                            if(next.overlaps(part.clone().shift(bx,by,bz)))return false;
                    }
            vx*=grounded?.546:.91;vz*=grounded?.546:.91;
            if(!grounded)vy=(vy-.08)*.98;
        }
        return true;
    }
    private static ArrowDodgePlanner.Vec vec(Vector v){return new ArrowDodgePlanner.Vec(v.getX(),v.getY(),v.getZ());}
}

from pathlib import Path
import hashlib,json,os,subprocess,zipfile
b=Path(__file__).resolve().parent;root=b.parents[1]
s=Path(r'D:\Walt Disney\Minecraft-1.21.1-Server');j=s/'runtime/java21/bin'
base=b/'base.jar';assert hashlib.sha256(base.read_bytes()).hexdigest()=='0808b3f5f93f448c3c5b7683be4cc6673a835e0ee416071bea93d27dd1cf5869'
c=b/'classes';c.mkdir(exist_ok=True)
asm=next((s/'libraries/org/ow2/asm/asm').rglob('*.jar'));tree=next((s/'libraries/org/ow2/asm/asm-tree').rglob('*.jar'))
cp=os.pathsep.join(map(str,[c,asm,tree]))
def run(args):subprocess.run(list(map(str,args)),check=True)
run([j/'javac.exe','-encoding','UTF-8','--release','21','-cp',os.pathsep.join(map(str,[asm,tree])),'-d',c,root/'work/pvp-ai-0.10.11-restart/InMemoryCompile.java',b/'PatchCounterGround.java'])
sources=sorted((b/'src/local/pvpbot/ai').glob('*.java'))
dependencies=b/'compiler-dependencies.txt'
dependencies.write_text((root/'work/duel-player-command/dependencies.txt').read_text(encoding='utf-8')+'\n'+str(s/'plugins/fakeplayer.jar')+'\n'+str(s/'plugins/ArrowSense.jar')+'\n',encoding='utf-8')
run([j/'java.exe','-Xmx384m','-cp',cp,'InMemoryCompile',base,c,'--dependencies',dependencies,*sources])
with zipfile.ZipFile(base) as z:payload={n:z.read(n) for n in z.namelist() if not n.endswith('/')}
main='local/pvpbot/ai/PvPArenaAI.class';(b/'before.class').write_bytes(payload[main])
turn='local/pvpbot/ai/PvPArenaAI$1.class';(b/'instant-before.class').write_bytes(payload[turn])
run([j/'java.exe','-cp',cp,'PatchCounterGround',b/'before.class',b/'after.class',b/'instant-before.class',b/'instant-after.class'])
payload[main]=(b/'after.class').read_bytes()
payload[turn]=(b/'instant-after.class').read_bytes()
for src in sources:
    for p in (c/'local/pvpbot/ai').glob(src.stem+'*.class'):payload[p.relative_to(c).as_posix()]=p.read_bytes()
version='0.10.11-ground.8.5-duel.1'
payload['plugin.yml']=payload['plugin.yml'].decode().replace('version: 0.10.11-ground.4-duel.1','version: '+version).encode()
out=b/'PvPArenaAI.jar'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    for name,data in payload.items():z.writestr(name,data)
with zipfile.ZipFile(base) as z:
    changed=[n for n in z.namelist() if n.endswith('.class') and payload[n]!=z.read(n)]
    added=[n for n in payload if n.endswith('.class') and n not in z.namelist()]
manifest={'version':version,'base_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'jar_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'modified_classes':changed,'added_classes':added,'deployed':False,'live_gameplay_validated':False}
(b/'preservation.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print('BUILT',version,'modified',changed,'added',added)
toolsrc=b/'tools-src/local/wavedog/testtools/KnockbackTestPlugin.java'
run([j/'java.exe','-Xmx384m','-cp',cp,'InMemoryCompile',base,c,'--dependencies',root/'work/duel-player-command/dependencies.txt',toolsrc])
with zipfile.ZipFile(b/'WaveDogTestTools.jar','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted((c/'local/wavedog/testtools').glob('*.class')):z.write(p,p.relative_to(c))
    z.writestr('plugin.yml','name: WaveDogTestTools\nversion: 1.0.0\nmain: local.wavedog.testtools.KnockbackTestPlugin\napi-version: "1.21"\ncommands:\n  kbtest:\n    permission: wavedog.kbtest\npermissions:\n  wavedog.kbtest:\n    default: op\n')
print('BUILT optional/off-by-default player KB test tools')
healthsrc=b/'tools-src/local/wavedog/health/HeadHeartsPlugin.java'
run([j/'java.exe','-Xmx384m','-cp',cp,'InMemoryCompile',base,c,'--dependencies',root/'work/duel-player-command/dependencies.txt',healthsrc])
with zipfile.ZipFile(b/'WaveDogHeadHearts.jar','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted((c/'local/wavedog/health').glob('*.class')):z.write(p,p.relative_to(c))
    z.writestr('plugin.yml','name: WaveDogHeadHearts\nversion: 1.0.0\nmain: local.wavedog.health.HeadHeartsPlugin\napi-version: "1.21"\n')
print('BUILT head-nameplate red hearts for players and bots')

# Restore the native fall bookkeeping omitted by the installed fakeplayer ticker.
fakebase=b/'fakeplayer-base.jar'
assert hashlib.sha256(fakebase.read_bytes()).hexdigest()=='3b5fa7260206fb47a6f15b30505a4f13c40a71bf6ad1f63b856bc73153df1b50'
run([j/'javac.exe','--release','21','-cp',os.pathsep.join(map(str,[asm,tree])),'-d',c,b/'PatchFakeplayerMovement.java'])
movement_sources=sorted((b/'movement-src').rglob('*.java'))
run([j/'java.exe','-Xmx384m','-cp',cp,'InMemoryCompile',fakebase,c,'--dependencies',dependencies,*movement_sources])
with zipfile.ZipFile(fakebase) as z:fp={n:z.read(n) for n in z.namelist() if not n.endswith('/')}
ticker='io/github/hello09x/fakeplayer/core/entity/FakeplayerTicker.class'
(b/'fake-ticker-before.class').write_bytes(fp[ticker])
run([j/'java.exe','-cp',cp,'PatchFakeplayerMovement',b/'fake-ticker-before.class',b/'fake-ticker-after.class'])
fp[ticker]=(b/'fake-ticker-after.class').read_bytes()
for p in (c/'local/wavedog/fakeplayer').glob('*.class'):fp[p.relative_to(c).as_posix()]=p.read_bytes()
with zipfile.ZipFile(b/'fakeplayer.jar','w',zipfile.ZIP_DEFLATED) as z:
    for name,data in fp.items():z.writestr(name,data)
with zipfile.ZipFile(fakebase) as z:
    assert [n for n in z.namelist() if not n.endswith('/') and fp[n]!=z.read(n)]==[ticker]
(b/'fakeplayer-movement.json').write_text(json.dumps({'base_sha256':hashlib.sha256(fakebase.read_bytes()).hexdigest(),
    'jar_sha256':hashlib.sha256((b/'fakeplayer.jar').read_bytes()).hexdigest(),
    'changed_original_entries':[ticker],'native_fall_settlement':True,'fall_distance_setter':False},indent=2),encoding='utf-8')
print('BUILT native fakeplayer movement bookkeeping; one original class changed')

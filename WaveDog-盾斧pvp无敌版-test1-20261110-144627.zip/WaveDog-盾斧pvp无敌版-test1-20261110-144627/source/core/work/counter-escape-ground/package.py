from pathlib import Path
import ast,hashlib,json,shutil,zipfile
b=Path(__file__).resolve().parent;root=b.parents[1]
version='0.10.11-ground.8.5-duel.1'
out=root/'outputs/MC-Native-Critical-8.5';out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
validated=json.loads((b/'validated.json').read_text(encoding='utf-8'))
native=json.loads((b/'native-validated.json').read_text(encoding='utf-8'))
assert native['jar_sha256']==sha(b/'PvPArenaAI.jar'),'Run the native use/projectile probe on this exact jar first'
assert native['fakeplayer_sha256']==sha(b/'fakeplayer.jar') and native['native_sprint_jump_critical']
assert validated['jar_sha256']==sha(b/'PvPArenaAI.jar'),'Run checks on the current jar first'
assert validated['test_tools_sha256']==sha(b/'WaveDogTestTools.jar')
assert validated['head_hearts_sha256']==sha(b/'WaveDogHeadHearts.jar')
for name in ('PvPArenaAI.jar','fakeplayer.jar','fakeplayer-movement.json','WaveDogTestTools.jar','WaveDogHeadHearts.jar','validation.log','validated.json','preservation.json','native-validated.json'):
    shutil.copy2(b/name,out/name)
shutil.copy2(b/'native-use-server/native-use-result.txt',out/'native-use-result.txt')
(out/'WaveDogTestTools.jar.sha256').write_text(sha(out/'WaveDogTestTools.jar')+'\n',encoding='ascii')
(out/'WaveDogHeadHearts.jar.sha256').write_text(sha(out/'WaveDogHeadHearts.jar')+'\n',encoding='ascii')
(out/'PvPArenaAI.jar.sha256').write_text(sha(out/'PvPArenaAI.jar')+'\n',encoding='ascii')
(out/'fakeplayer.jar.sha256').write_text(sha(out/'fakeplayer.jar')+'\n',encoding='ascii')
installer=(root/'outputs/MC-Duel-Player/install.py').read_text(encoding='utf-8')
installer=installer.replace("VERSION='0.10.11-ground.4-duel.1'","VERSION='"+version+"'")
installer=installer.replace("'DuelPlayerCommands')","'DuelPlayerCommands','CounterEscapeHop','CombatInputHooks','PressureRecovery','WallPositioning','PositioningObservation','RoundCrossbowKit','NativeOffhandUse','OffhandRangedSupport')")
installer=installer.replace('Training and previous plugin backed up; combat unchanged.','Training and previous plugin backed up; cumulative counter/ground update installed.')
installer=installer.replace("'duel_player_command_verified':True}","'duel_player_command_verified':True,'native_physics_preserved':True,'self_jump_reset_added':False}")
installer=installer.replace("    print('No duel has been started automatically.","    print('No duel has been started automatically.")
installer=installer.replace("for name in ('PvPArenaAI.jar','PvPArenaAI','PublicAuthBridge.jar'):","for name in ('PvPArenaAI.jar','PvPArenaAI','PublicAuthBridge.jar','WaveDogTestTools.jar','WaveDogTestTools','WaveDogHeadHearts.jar'):")
installer=installer.replace("    # Verify the real destination", "    tools=BASE/'WaveDogTestTools.jar'\n    if sha(tools)!=(BASE/'WaveDogTestTools.jar.sha256').read_text().strip():raise RuntimeError('Test-tools checksum mismatch')\n    # Verify the real destination")
installer=installer.replace("    shutil.copy2(jar,SERVER/'plugins/PvPArenaAI.jar')", "    shutil.copy2(jar,SERVER/'plugins/PvPArenaAI.jar')\n    shutil.copy2(tools,SERVER/'plugins/WaveDogTestTools.jar')")
installer=installer.replace("    tools=BASE/'WaveDogTestTools.jar'", "    hearts=BASE/'WaveDogHeadHearts.jar'\n    if sha(hearts)!=(BASE/'WaveDogHeadHearts.jar.sha256').read_text().strip():raise RuntimeError('Head-hearts checksum mismatch')\n    tools=BASE/'WaveDogTestTools.jar'")
installer=installer.replace("    shutil.copy2(tools,SERVER/'plugins/WaveDogTestTools.jar')", "    shutil.copy2(tools,SERVER/'plugins/WaveDogTestTools.jar')\n    shutil.copy2(hearts,SERVER/'plugins/WaveDogHeadHearts.jar')")
installer=installer.replace("'WaveDogHeadHearts.jar'):","'WaveDogHeadHearts.jar','fakeplayer.jar'):")
installer=installer.replace("    # Verify the real destination", "    fake=BASE/'fakeplayer.jar'\n    if sha(fake)!=(BASE/'fakeplayer.jar.sha256').read_text().strip():raise RuntimeError('Fakeplayer movement checksum mismatch')\n    movement=json.loads((BASE/'fakeplayer-movement.json').read_text(encoding='utf-8'))\n    if sha(SERVER/'plugins/fakeplayer.jar') not in (movement['base_sha256'],movement['jar_sha256']):raise RuntimeError('Installed fakeplayer differs; preserved it without replacement')\n    # Verify the real destination")
installer=installer.replace("    shutil.copy2(jar,SERVER/'plugins/PvPArenaAI.jar')", "    shutil.copy2(fake,SERVER/'plugins/fakeplayer.jar')\n    shutil.copy2(jar,SERVER/'plugins/PvPArenaAI.jar')")
installer=installer.replace("if '/pvpai duel 玩家名' not in help_text:","if '/pvpai duel <test1|test2|uhc1|uhc2>' not in help_text:")
installer=installer.replace('pvpai duel <online player name>','pvpai duel <test1|test2|uhc1|uhc2> [player]')
installer=installer.replace('Use /pvpai duel PLAYER_NAME; default /pvpai duel fights WaveJerry. Stop: /pvpai stop.','Use /pvpai duel test1 PLAYER_NAME or /pvpai duel test2. Model is mandatory. Stop: /pvpai stop.')
installer=installer.replace("    help_text=command('pvpai help')", "    for addon in ('WaveDogTestTools','WaveDogHeadHearts'):\n        if '1.0.0' not in command('version '+addon):raise RuntimeError(addon+' not loaded; inspect console')\n    help_text=command('pvpai help')")
ast.parse(installer)
(out/'install.py').write_text(installer,encoding='utf-8')
(out/'install.cmd').write_bytes(b'@echo off\r\nsetlocal\r\ncd /d "%~dp0"\r\necho Installing cumulative WaveDog counter and ground-control update...\r\nE:\\python.exe -X utf8 "%~dp0install.py"\r\nset "counter_install_exit=%errorlevel%"\r\npause\r\nexit /b %counter_install_exit%\r\n')
(out/'更新并启动.cmd').write_bytes(b'@echo off\r\ncall "%~dp0install.cmd"\r\n')
source=out/'source';source.mkdir(exist_ok=True)
copyfiles=[]
for name in ('base.jar','baseline.json','build.py','check.py','package.py','PatchCounterGround.java','CounterGroundAudit.java',
             'CounterShieldCheck.java','PressureControllerCheck.java','GroundPressureCheck.java','PressureRecoveryCheck.java','HopWeaponCheck.java','RangedIntegrationCheck.java','ExtraMechanicsCheck.java','TradeMechanicsCheck.java','CombatRegressionCheck.java','ExchangeRepairCheck.java','ProjectileArbitrationCheck.java','NativeUseProbePlugin.java','NativeEscapeProbe.java','PatchFakeplayerMovement.java','fakeplayer-base.jar','fakeplayer-movement.json','run-native-use-probe.py','行为说明.md','整体判断流程.md'):
    copyfiles.append(b/name)
copyfiles+=list((b/'src').rglob('*.java'))+list((b/'tools-src').rglob('*.java'))+list((b/'movement-src').rglob('*.java'))
for name in ('InMemoryCompile.java','RestartCheck.java','compiler-dependencies.jar'):
    copyfiles.append(root/'work/pvp-ai-0.10.11-restart'/name)
for name in ('DuelPlayerLoadCheck.java','dependencies.txt'):
    copyfiles.append(root/'work/duel-player-command'/name)
for name in ('move-to-d.ps1','move-to-d.cmd','move-and-install.cmd','迁移到D并安装.cmd','validation.txt'):
    copyfiles.append(root/'outputs/MC-Migrate'/name)
for p in copyfiles:
    dest=source/p.relative_to(root);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
with zipfile.ZipFile(out/'source.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(source.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(source))
shutil.copy2(b/'行为说明.md',out/'说明.md')
shutil.copy2(b/'整体判断流程.md',out/'整体判断流程.md')
manifest={**json.loads((b/'preservation.json').read_text(encoding='utf-8')),**validated,
          'cumulative':True,'models_reset':False,'self_jump_reset_added':False}
(out/'package-manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
(root/'outputs/PVPBot-AI/install.cmd').write_bytes(b'@echo off\r\ncall "D:\\CodexWorkspace\\ban\\outputs\\MC-Native-Critical-8.5\\install.cmd"\r\n')
print('STAGED',out)
print('JAR SHA256',sha(out/'PvPArenaAI.jar'))
